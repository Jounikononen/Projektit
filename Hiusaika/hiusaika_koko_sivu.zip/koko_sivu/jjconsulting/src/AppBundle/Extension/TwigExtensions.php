<?php
namespace AppBundle\Extension;

use Symfony\Component\DependencyInjection\Container;
use AppBundle\Service\IdHasher;
/**
 * Description of TwigExtensions
 *
 * @author villel
 */
class TwigExtensions extends \Twig_Extension {
    protected $id_hasher;

    public function getFunctions()
    {
        return array(
            new \Twig_SimpleFunction('url_id_hasher_encode', array($this, 'urlIdHasherEncode')),
            new \Twig_SimpleFunction('url_id_hasher_decode', array($this, 'urlIdHasherDecode'))
        );
    }
    
    public function __construct(IdHasher $hasherService)
    {
        $this->id_hasher = $hasherService;
    }

    /**
     * Declare encode function
     *
     * @param $value {Integer || String} Number to convert into hash
     */
    public function urlIdHasherEncode($value){
        return $this->id_hasher->encode($value);
    }

    /**
     * Declare decode function
     *
     * @param $value {Integer || String} NHash to convert into number
     */
    public function urlIdHasherDecode($value){
        return $this->id_hasher->decode($value);
    }
    
    public function getName()
    {
        return 'TwigExtensions';
    }
}
