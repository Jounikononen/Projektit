<?php
namespace AppBundle\Service;

use Symfony\Component\Config\Definition\Exception\Exception;
use Hashids\Hashids;
/**
 * Description of IdHasher
 *
 * @author villel
 */
class IdHasher {
    
    private $HashIdsInstance;
    
    /**
     * The constructor expects the entropy string and the padding for the Hashids class
     * parameters declared as url_hasher_entropy and url_hasher_padding in parameters.yml
     *
     * @param $entropyString {String}
     * @param $hashPadding {Integer}
     */
    public function __construct($entropyString, $hashPadding)
    {
        $this->HashIdsInstance = new Hashids($entropyString, $hashPadding);
    }

    public function encode($number){
        return $this->HashIdsInstance->encode($number);
    }

    public function decode($hash){
        $result = $this->HashIdsInstance->decode($hash);
        
        return empty($result) ? null : $result[0];
    }
}
