function initMap(){
    var address = $("#address").html();
    var town = $("#postcode").html() + " " + $("#city").html();
    var geocoder = new google.maps.Geocoder();
    
    // Create a map object and specify the DOM element for display.
    var map = new google.maps.Map(document.getElementById('company-map'), {
        center: {lat: 61.92410999999999, lng: 25.748151099999973},
        zoom: 5,
        streetViewControl: false,
        mapTypeControl: false
    });
    
    geocoder.geocode({'address': address + " " + town},function(results, status){
        if (status == google.maps.GeocoderStatus.OK) {
                var marker=new google.maps.Marker({
                        map: map,
                        position: results[0].geometry.location
                });
                map.panTo(results[0].geometry.location);
                map.setZoom(14);
        } else {
            // Failed to place marker
        }
    });
};