$(document).ready(function() {
    $(".company-row").click(function() {
        window.location = $(this).data("href");
    });
});