var serviceIndex = 0;
var defaultServiceIndex = 0;

$(document).ready(function() {
    serviceIndex = $('#selected-services-collection tr').length;// Get the new index
    defaultServiceIndex = $('#selected-default-services-collection tr').length;
    
    if ($("#default-service-add-name").val() === null) {
        $("#default-service-add-name").val($("#default-service-add-name option:first").val());
    }
    
    $("#add-service").on('click', function(e) {
        e.preventDefault();
        addService();
    });
    
    $("#add-default-service").on('click', function(e) {
        e.preventDefault();
        addDefaultService();
    });
    
    $(document).on('click', ".service-remove", function(e) {
        e.preventDefault();
        $(this).closest('tr').remove();
    });
    
    $(document).on('click', ".default-service-remove", function(e) {
        e.preventDefault();
        var id = $(this).closest('tr').data("id");
        updateDefaultServiceOption(id, false);
        $(this).closest('tr').remove();
    });
});

function addService() {
    if (!validateAddService()) {
        return;
    }
    
    createNewService(serviceIndex);
    clearAddForm();
    serviceIndex++;
}

function addDefaultService() {
    if (!validateAddDefaultService()) {
        return;
    }
    
    var id = $("#default-service-add-name").val();
    
    createNewDefaultService(defaultServiceIndex);
    updateDefaultServiceOption(id, true);
    clearAddDefaultForm();
    defaultServiceIndex++;
}

function validateAddService() {
    clearErrors();
    var hasErrors = false;
    
    if ($("#service-add-name").val() === "") {
        $("#service-add-error").html("Anna palvelun nimi");
        hasErrors = true;
    } else if ($("#service-add-priceFrom").val() === "") {
        $("#service-add-error").html("Anna vähimmäishinta");
        hasErrors = true;
    }
    
    if (hasErrors) {
        $("#service-add-error").show();
        return false;
    }
    
    return true;
}

function validateAddDefaultService() {
    clearErrors();
    
    var hasErrors = false;
    
    if ($('#default-service-add-name option:not(:disabled)').length === 0) {
        $("#default-service-add-error").html("Kaikki peruspalvelut on jo lisätty");
        hasErrors = true;
    } else if ($("#default-service-add-name option:selected").prop('disabled')) {
        $("#default-service-add-error").html("Virheellinen palvelu");
        hasErrors = true;
    } else if ($("#default-service-add-name").val() === "" || $("#default-service-add-name").val() === null) {
        $("#default-service-add-error").html("Virheellinen palvelu");
        hasErrors = true;
    } else if ($("#default-service-add-priceFrom").val() === "") {
        $("#default-service-add-error").html("Anna vähimmäishinta");
        hasErrors = true;
    }
    
    if (hasErrors) {
        $("#default-service-add-error").show();
        return false;
    }
    
    return true;
}

function createNewService(index) {
    var name = $("#service-add-name").val();
    var priceFrom = $("#service-add-priceFrom").val();
    var priceTo = $("#service-add-priceTo").val();
    
    var html = '<tr>' 
                    + '<td class="col-name">' + name + '<input type="hidden" id="company_services_' + index + '_name" name="company[services][' + index + '][name]" value="' + name + '"></td>'
                    + '<td class="col-price">' + priceFrom + '<input type="hidden" id="company_services_' + index + '_priceFrom" name="company[services][' + index + '][priceFrom]" value="' + priceFrom + '"> - ' + priceTo + ' <input type="hidden" id="company_services_' + index + '_priceTo" name="company[services][' + index + '][priceTo]" value="' + priceTo + '"> €</td>'
                    + '<td class="col-remove"><a class="service-remove" href="#"><i class="fa fa-times" aria-hidden="true"></i></a></td>'
                + '</tr>';
    $('#selected-services-collection').append(html);
}

function createNewDefaultService(index) {
    var name = $("#default-service-add-name option:selected").text();
    var nameId = $("#default-service-add-name").val();
    var priceFrom = $("#default-service-add-priceFrom").val();
    var priceTo = $("#default-service-add-priceTo").val();
    
    var html = '<tr data-id="' + nameId + '">' 
                    + '<td class="col-name">' + name + '<input type="hidden" id="company_defaultServices_' + index + '_name" name="company[defaultServices][' + index + '][name]" value="' + nameId + '"></td>'
                    + '<td class="col-price">' + priceFrom + '<input type="hidden" id="company_defaultServices_' + index + '_priceFrom" name="company[defaultServices][' + index + '][priceFrom]" value="' + priceFrom + '"> - ' + priceTo + ' <input type="hidden" id="company_defaultServices_' + index + '_priceTo" name="company[defaultServices][' + index + '][priceTo]" value="' + priceTo + '"> €</td>'
                    + '<td class="col-remove"><a class="default-service-remove" href="#"><i class="fa fa-times" aria-hidden="true"></i></a></td>'
                + '</tr>';
    $('#selected-default-services-collection').append(html);
}

function clearErrors() {
    $("#service-add-error").hide();
    $("#default-service-add-error").hide();
    $("#service-add-error").html("");
    $("#default-service-add-error").html("");
}

function clearAddForm() {
    $("#service-add-name").val("");
    $("#service-add-priceFrom").val("");
    $("#service-add-priceTo").val("");
}

function updateDefaultServiceOption(id, disabled) {
    $("#default-service-add-name option[value='" + id + "']").prop("disabled", disabled);
    
    if (!disabled && $("#default-service-add-name").val() === null) {
        $("#default-service-add-name").val($("#default-service-add-name option:not([disabled]):first").val());
    }
}

function clearAddDefaultForm() {
    $("#default-service-add-name").val($("#default-service-add-name option:not([disabled]):first").val());
    if ($("#default-service-add-name").val() === null) {
        $("#default-service-add-name").val($("#default-service-add-name option:first").val());
    }
    
    $("#default-service-add-priceFrom").val("");
    $("#default-service-add-priceTo").val("");
}