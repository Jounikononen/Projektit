<?php
namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

use AppBundle\Entity\Company;
use AppBundle\Form\CompanyType;

use AppBundle\Entity\DefaultServiceName;

/**
 * Description of AdminController
 *
 * @author villel
 */
class AdminController extends Controller
{
    /**
     * @Route("/admin", name="adminIndex")
     */
    public function indexAction(Request $request)
    {   
        $this->denyAccessUnlessGranted('ROLE_ADMIN', null, 'Unable to access this page!');
        
        $repository = $this->getDoctrine()->getRepository(Company::class);
        $companies = $repository->findAll();
        $unconfirmedCompanies = $repository->findAllUnconfirmed();
        
        return $this->render('Admin/index.html.twig', array(
            'companies' => $companies,
            'unconfirmed' => $unconfirmedCompanies
        ));
    }
    
    /**
     * @Route("/admin/edit/{id}", name="adminCompanyEdit")
     */
    public function companyEditAction(Request $request, $id) {   
        $this->denyAccessUnlessGranted('ROLE_ADMIN', null, 'Unable to access this page!');
        
        $repository = $this->getDoctrine()->getRepository(Company::class);
        $company = $repository->find($id);
        
        if ($company == null) {
            return $this->redirectToRoute('adminIndex');
        }
        
        $form = $this->createForm(CompanyType::class, $company, array(
            'admin' => true
        ));
        
        $form->handleRequest($request);
        
        if ($form->isSubmitted() &&  $form->isValid()) {
            $company = $form->getData();
            $em = $this->getDoctrine()->getManager();
            $em->persist($company);
            $em->flush();
            
            $this->addFlash(
                'success',
                'Yrityksen tiedot tallennettu'
            );
            
            return $this->redirectToRoute('adminIndex');
        }
        
        $defaultServices = $this->getDoctrine()->getRepository(DefaultServiceName::class)->findAll();
        $selectedDefaultServiceIds = array();
        foreach ($company->getDefaultServices() as $defaultService) {
            array_push($selectedDefaultServiceIds, $defaultService->getName()->getId());
        }
        
        return $this->render('Admin/companyEdit.html.twig', array(
            'company' => $company,
            'form' => $form->createView(),
            'defaultServices' => $defaultServices,
            'selectedDefaultServices' => $selectedDefaultServiceIds
        ));
    }
}