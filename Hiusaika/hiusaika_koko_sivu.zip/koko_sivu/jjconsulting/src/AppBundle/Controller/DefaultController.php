<?php
namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use AppBundle\Entity\Contact;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request) {
        $contact = new Contact;

        # Add contact form fields
        $form = $this->createFormBuilder($contact)
                ->add('name', TextType::class, array('label' => 'Nimi', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
                ->add('email', TextType::class, array('label' => 'Sähköposti', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
                ->add('message', TextareaType::class, array('label' => 'Viesti', 'attr' => array('class' => 'form-control', 'rows' => '5')))
                ->add('submit', SubmitType::class, array('label' => 'Lähetä', 'attr' => array('class' => 'btn btn-default pull-right', 'style' => 'margin-top:15px')))
                ->getForm();

        $form->handleRequest($request);
        
        if ($form->isSubmitted() &&  $form->isValid()) {
            $contact = $form->getData();
            $em = $this->getDoctrine()->getManager();
            $em->persist($contact);
            $em->flush();
                
            $this->addFlash(
                'success',
                'Kiitos palautteestasi! Käsittelemme sen mahdollisimman pian.'
            );
        }

        
        return $this->render('Default/index.html.twig', array(
            'contactForm' => $form->createView()
        ));
    }

    /**
     * @Route("/about/", name="about")
     */
    public function aboutAction(Request $request) {
        $contact = new Contact;

        # Add contact form fields
        $form = $this->createFormBuilder($contact)
                ->add('name', TextType::class, array('label' => 'Nimi', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
                ->add('email', TextType::class, array('label' => 'Sähköposti', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
                ->add('message', TextareaType::class, array('label' => 'Viesti', 'attr' => array('class' => 'form-control', 'rows' => '5')))
                ->add('submit', SubmitType::class, array('label' => 'Lähetä', 'attr' => array('class' => 'btn btn-default pull-right', 'style' => 'margin-top:15px')))
                ->getForm();

        $form->handleRequest($request);
        
        if ($form->isSubmitted() &&  $form->isValid()) {
            $contact = $form->getData();
            $em = $this->getDoctrine()->getManager();
            $em->persist($contact);
            $em->flush();
                
            $this->addFlash(
                'success',
                'Kiitos palautteestasi! Käsittelemme sen mahdollisimman pian.'
            );
        }

        
        return $this->render('Default/about.html.twig', array(
            'contactForm' => $form->createView()
        ));
    }
}
