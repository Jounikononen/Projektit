<?php
namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\SearchType;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Forms;
use AppBundle\Entity\Company;
use AppBundle\Service\IdHasher;

class CompanyController extends Controller
{

    /**
     * @Route("/companies/company/{hashId}", name="viewCompany")
     */
    public function viewAction($hashId)
    {
        $hasherService = $this->get(IdHasher::class);
        // Convert the hash to its integer representation
        $numericId = $hasherService->decode($hashId);
        
        if ($numericId == null) {
            return $this->render('Default/404.html.twig');
        }
        
        $repository = $this->getDoctrine()->getRepository(Company::class);
        $company = $repository->find($numericId);
        
        if ($company == null) {
            return $this->render('Default/404.html.twig');
        }
        
        return $this->render('Company/company.html.twig', array(
            'company' => $company
        ));
    }
    
    /**
     * @Route("/companies/search", name="searchCompany")
     */
    public function searchAction(Request $request) {
        $keyword = $request->query->get('q', null);
        $currentPage = $request->query->getInt('page', 1);
        
        $repository = $this->getDoctrine()->getRepository(Company::class);
        $query = $repository->searchCompany($keyword, $currentPage);

        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate(
            $query,
            $request->query->getInt('page', 1) /*page number*/,
            5 /*limit per page*/
        );
            
        return $this->render('Company/search.html.twig', array(
            'pagination' => $pagination,
            'keyword' => $keyword
        ));
    }
    
    public function searchBarAction($q) {
        $formFactory = Forms::createFormFactory();
        $form = $formFactory->createNamedBuilder('', FormType::class, null)
                ->setMethod('GET')
                ->add('q', SearchType::class, array(
                    'attr' => array(
                        'class' => 'form-control', 
                        'placeholder' => 'Hae yritystä...',
                        'size' => "50"),
                    'required' => false))
                ->getForm();
        
        if ($q != null) {
            $form->get("q")->setData($q);
        }
            
        return $this->render('Layout/searchBar.html.twig', array(
            'form' => $form->createView()
        ));
    }
}
