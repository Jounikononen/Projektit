<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RedirectResponse;
use FOS\UserBundle\Controller\SecurityController as BaseController;

class SecurityController extends BaseController
{

    /**
     * 
     * @param Request $request
     *
     * @return Response
     */
    public function loginAction(Request $request)
    {
        // Check if user is already authenticated
        if ($this->container->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED')) {
            return new RedirectResponse($this->container->get('router')->generate('dashboard'));
        }

        return parent::loginAction($request);
    }
    
    /**
     * @Route("/profile/", name="profileRedirect")
     */
    public function profileRedirectAction(Request $request)
    {
        return $this->redirectToRoute('dashboard');
    }
}