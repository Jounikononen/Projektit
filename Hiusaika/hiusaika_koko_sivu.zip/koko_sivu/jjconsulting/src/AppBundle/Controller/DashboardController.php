<?php
namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

use AppBundle\Form\CompanyType;
use AppBundle\Form\CompanyImageType;

use AppBundle\Entity\DefaultServiceName;

/**
 * Description of DashboardController
 *
 * @author villel
 */
class DashboardController extends Controller {

    /**
     * @Route("/dashboard", name="dashboard")
     */
    public function dashboardAction(Request $request)
    {
        if ($this->get('security.authorization_checker')->isGranted('ROLE_ADMIN')) {
            return $this->redirectToRoute('adminIndex');
        }
        
        $company = $this->getUser()->getCompany();
        
        $form = $this->createForm(CompanyType::class, $company);
        $form->handleRequest($request);
        
        if ($form->isSubmitted() &&  $form->isValid()) {
            $company = $form->getData();
            $em = $this->getDoctrine()->getManager();
            $em->persist($company);
            $em->flush();
            
            $this->addFlash(
                'success',
                'Yrityksen tiedot tallennettu'
            );
            
            return $this->redirectToRoute('dashboard');
        }
        
        $defaultServices = $this->getDoctrine()->getRepository(DefaultServiceName::class)->findAll();
        $selectedDefaultServiceIds = array();
        foreach ($company->getDefaultServices() as $defaultService) {
            array_push($selectedDefaultServiceIds, $defaultService->getName()->getId());
        }
        
        return $this->render('Dashboard/dashboard.html.twig', array(
            'company' => $company,
            'form' => $form->createView(),
            'defaultServices' => $defaultServices,
            'selectedDefaultServices' => $selectedDefaultServiceIds
        ));
    }
    
    /**
     * @Route("/dashboard/changeimage", name="dashboardImageChange")
     */
    public function imageChangeAction(Request $request)
    {
        $company = $this->getUser()->getCompany();
        
        $form = $this->createForm(CompanyImageType::class, $company);
        $form->handleRequest($request);
        
         if ($form->isSubmitted() &&  $form->isValid()) {
            $company = $form->getData();
            $em = $this->getDoctrine()->getManager();
            $em->persist($company);
            $em->flush();
            
            $this->addFlash(
                'success',
                'Kuva tallennettu onnistuneesti'
            );
            
            return $this->redirectToRoute('dashboard');
        }
        
        return $this->render('Dashboard/change_image.html.twig', array(
            'company' => $company,
            'form' => $form->createView()
        ));
    }
}
