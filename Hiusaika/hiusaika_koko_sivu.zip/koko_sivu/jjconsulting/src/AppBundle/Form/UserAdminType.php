<?php
namespace AppBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\OptionsResolver\OptionsResolver;

use AppBundle\Entity\User;

/**
 * Description of UserAdminType
 *
 * @author villel
 */
class UserAdminType extends AbstractType {
    
    public function buildForm(FormBuilderInterface $builder, array $options) {
        $builder->add('confirmed', 
                CheckboxType::class, 
                array(
                    'label' => 'Vahvistettu',
                    'required' => false
                    ));
    }
    
   public function configureOptions(OptionsResolver $resolver) {
        $resolver->setDefaults(array(
            'data_class' => User::class,
        ));
    }
}
