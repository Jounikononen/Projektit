<?php
namespace AppBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Vich\UploaderBundle\Form\Type\VichImageType;

use AppBundle\Entity\Company;

/**
 * Description of CompanyType
 *
 * @author villel
 */
class CompanyImageType extends AbstractType {
    
    public function buildForm(FormBuilderInterface $builder, array $options) {
        $builder
            ->add('imageFile', VichImageType::class, [
                'required' => false,
                'allow_delete' => true,
                'label' => false,
                'attr' => array("hidden" => "hidden")
            ])
            ->add('submit', SubmitType::class, array('label' => 'Tallenna', 'attr' => array('class' => 'btn btn-default')));
    }
    
    public function configureOptions(OptionsResolver $resolver) {
        $resolver->setDefaults(array(
            'data_class' => Company::class,
        ));
    }
}
