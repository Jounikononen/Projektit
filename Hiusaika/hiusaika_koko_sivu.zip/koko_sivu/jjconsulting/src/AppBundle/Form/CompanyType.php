<?php
namespace AppBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\OptionsResolver\OptionsResolver;

use AppBundle\Entity\Company;
use AppBundle\Form\ServiceType;
use AppBundle\Form\DefaultServiceType;
use AppBundle\Form\UserAdminType;

/**
 * Description of CompanyType
 *
 * @author villel
 */
class CompanyType extends AbstractType {
    
    public function buildForm(FormBuilderInterface $builder, array $options) {
        $builder
            ->add('address', TextType::class, array('label' => 'Osoite', 'required' => false, 'attr' => array('class' => 'form-control'))) 
            ->add('city', TextType::class, array('label' => 'Kaupunki', 'required' => false, 'attr' => array('class' => 'form-control')))
            ->add('postcode', TextType::class, array('label' => 'Postinumero', 'required' => false, 'attr' => array('class' => 'form-control')))
            ->add('phone', TextType::class, array('label' => 'Puhelin', 'required' => false, 'attr' => array('class' => 'form-control')))
            ->add('email', TextType::class, array('label' => 'Sähköposti', 'required' => false, 'attr' => array('class' => 'form-control')))
            ->add('openingHoursMonday', TextType::class, array('label' => 'Maanantai', 'required' => false, 'attr' => array('class' => 'form-control')))
            ->add('openingHoursTuesday', TextType::class, array('label' => 'Tiistai', 'required' => false, 'attr' => array('class' => 'form-control')))
            ->add('openingHoursWednesday', TextType::class, array('label' => 'Keskiviikko', 'required' => false, 'attr' => array('class' => 'form-control')))
            ->add('openingHoursThursday', TextType::class, array('label' => 'Torstai', 'required' => false, 'attr' => array('class' => 'form-control')))
            ->add('openingHoursFriday', TextType::class, array('label' => 'Perjantai', 'required' => false, 'attr' => array('class' => 'form-control')))
            ->add('openingHoursSaturday', TextType::class, array('label' => 'Lauantai', 'required' => false, 'attr' => array('class' => 'form-control')))
            ->add('openingHoursSunday', TextType::class, array('label' => 'Sunnuntai', 'required' => false, 'attr' => array('class' => 'form-control')))
            ->add('description', TextareaType::class, array('label' => 'Kuvaus', 'required' => false, 'attr' => array('class' => 'form-control description', 'rows' => '9')))
            ->add('services', CollectionType::class, array(
                'label' => false,
                'required' => false,
                'entry_type' => ServiceType::class, 
                'entry_options' => array('label' => true), 
                'allow_add' => true,
                'allow_delete' => true
            ))
            ->add('defaultServices', CollectionType::class, array(
                'label' => false,
                'required' => false,
                'entry_type' => DefaultServiceType::class, 
                'entry_options' => array('label' => true), 
                'allow_add' => true,
                'allow_delete' => true
            ))
            ->add('submit', SubmitType::class, array('label' => 'Tallenna muutokset', 'attr' => array('class' => 'btn btn-default')));
            
            if ($options['admin']) {
                $builder
                        ->add('name', TextType::class, array('label' => 'Nimi', 'attr' => array('class' => 'form-control'))) 
                        ->add('vatId', TextType::class, array('label' => 'Y-tunnus', 'attr' => array('class' => 'form-control')))
                        ->add('user', UserAdminType::class, array('label' => false, 'required' => false));
            }
    }
    
   public function configureOptions(OptionsResolver $resolver) {
        $resolver->setDefaults(array(
            'data_class' => Company::class,
            'admin' => false
        ));
    }
}
