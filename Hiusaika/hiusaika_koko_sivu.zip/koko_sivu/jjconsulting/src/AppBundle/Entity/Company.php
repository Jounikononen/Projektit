<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\HttpFoundation\File\File;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Company
 *
 * @ORM\Table(name="company")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\CompanyRepository")
 * @Vich\Uploadable
 */
class Company {
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\OneToOne(targetEntity="User", mappedBy="company")
     */
    private $user;
    
    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255)
     */
    private $name;
    
    /**
     * @var string
     *
     * @ORM\Column(name="vat_id", type="string", length=255)
     */
    private $vatId;

    /**
     * @var string
     *
     * @ORM\Column(name="email", type="string", length=255, nullable=true)
     */
    private $email;
    
    /**
     * @var string
     *
     * @ORM\Column(name="address", type="string", length=255, nullable=true)
     */
    private $address;
    
    /**
     * @var string
     *
     * @ORM\Column(name="city", type="string", length=255, nullable=true)
     */
    private $city;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="postcode", type="integer", nullable=true)
     */
    private $postcode;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", length=255, nullable=true)
     */
    private $description;
    
    /**
     * @var string
     *
     * @ORM\Column(name="phone", type="string", length=255, nullable=true)
     */
    private $phone;
    
    /**
     * @var string
     *
     * @ORM\Column(name="opening_hours_monday", type="string", length=255, nullable=true)
     */
    private $openingHoursMonday;
    
    /**
     * @var string
     *
     * @ORM\Column(name="opening_hours_tuesday", type="string", length=255, nullable=true)
     */
    private $openingHoursTuesday;
    
    /**
     * @var string
     *
     * @ORM\Column(name="opening_hours_wednesday", type="string", length=255, nullable=true)
     */
    private $openingHoursWednesday;
    
    /**
     * @var string
     *
     * @ORM\Column(name="opening_hours_thursday", type="string", length=255, nullable=true)
     */
    private $openingHoursThursday;
    
    /**
     * @var string
     *
     * @ORM\Column(name="opening_hours_friday", type="string", length=255, nullable=true)
     */
    private $openingHoursFriday;
    
    /**
     * @var string
     *
     * @ORM\Column(name="opening_hours_saturday", type="string", length=255, nullable=true)
     */
    private $openingHoursSaturday;
    
    /**
     * @var string
     *
     * @ORM\Column(name="opening_hours_sunday", type="string", length=255, nullable=true)
     */
    private $openingHoursSunday;
    
    /**
     * 
     * @ORM\ManyToMany(targetEntity="Service", cascade={"persist", "remove"}, orphanRemoval=true)
     * @ORM\JoinTable(name="company_services",
     *      joinColumns={@ORM\JoinColumn(name="company_id", referencedColumnName="id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="service_id", referencedColumnName="id", unique=true)}
     *      )
     */
    private $services;
    
    /**
     * 
     * @ORM\ManyToMany(targetEntity="DefaultService", cascade={"persist", "remove"}, orphanRemoval=true)
     * @ORM\JoinTable(name="company_default_services",
     *      joinColumns={@ORM\JoinColumn(name="company_id", referencedColumnName="id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="default_service_id", referencedColumnName="id", unique=true)}
     *      )
     */
    private $defaultServices;
    
    /**
     * NOTE: This is not a mapped field of entity metadata, just a simple property.
     * 
     * @var File
     * 
     * @Vich\UploadableField(mapping="company_image", fileNameProperty="imageName", size="imageSize")
     * @Assert\Image(
     *      maxSize = "2048k",
     *      mimeTypes= { "image/png", "image/jpeg" },
     *      mimeTypesMessage= "Vain JPEG ja PNG kuvat on sallittuja"
     * )
     */
    private $imageFile;

    /**
     * @var string
     * 
     * @ORM\Column(name="image_name", type="string", length=255, nullable=true)
     */
    private $imageName;

    /**
     * @var integer
     * 
     * @ORM\Column(name="image_size", type="integer", nullable=true)
     */
    private $imageSize;

    /**
     * @var \DateTime
     * 
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    private $updatedAt;

    public function __construct()
    {
        $this->services = new \Doctrine\Common\Collections\ArrayCollection();
        $this->defaultServices = new \Doctrine\Common\Collections\ArrayCollection();
        $this->updatedAt = new \DateTimeImmutable();
    }
    
    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }
    
    /**
     * Set user
     *
     * @param \AppBundle\Entity\User $user
     * @return User
     */
    public function setUser(\AppBundle\Entity\User $user)
    {
        $this->user = $user;
        return $this;
    }

    /**
     * Get user
     *
     * @return \AppBundle\Entity\User $user
     */
    public function getUser()
    {
        return $this->user;
    }
    
    /**
     * Set name
     *
     * @param string $name
     * @return Company
     */
    public function setName($name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }
    
    /**
     * Set vatId
     *
     * @param string $vatId
     * @return Company
     */
    public function setVatId($vatId)
    {
        $this->vatId = $vatId;
        return $this;
    }

    /**
     * Get vatId
     *
     * @return string 
     */
    public function getVatId()
    {
        return $this->vatId;
    }
    
    /**
     * Set email
     *
     * @param string $email
     * @return Company
     */
    public function setEmail($email)
    {
        $this->email = $email;
        return $this;
    }

    /**
     * Get email
     *
     * @return string 
     */
    public function getEmail()
    {
        return $this->email;
    }
    
    /**
     * Set address
     *
     * @param string $address
     * @return Company
     */
    public function setAddress($address)
    {
        $this->address = $address;
        return $this;
    }

    /**
     * Get address
     *
     * @return string 
     */
    public function getAddress()
    {
        return $this->address;
    }
    
    /**
     * Set city
     *
     * @param string $city
     * @return Company
     */
    public function setCity($city)
    {
        $this->city = $city;
        return $this;
    }

    /**
     * Get city
     *
     * @return string 
     */
    public function getCity()
    {
        return $this->city;
    }
    
    /**
     * Set postcode
     *
     * @param integer $postcode
     * @return Town
     */
    public function setPostcode($postcode)
    {
        $this->postcode = $postcode;

        return $this;
    }

    /**
     * Get postcode
     *
     * @return integer 
     */
    public function getPostcode()
    {
        return $this->postcode;
    }
    
    /**
     * Set description
     *
     * @param string $description
     * @return Company
     */
    public function setDescription($description)
    {
        $this->description = $description;
        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }
    
    /**
     * Set phone
     *
     * @param string $phone
     * @return User
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;
        return $this;
    }

    /**
     * Get phone
     *
     * @return string 
     */
    public function getPhone()
    {
        return $this->phone;
    }
    
    /**
     * Set openingHoursMonday
     *
     * @param string $openingHoursMonday
     * @return User
     */
    public function setOpeningHoursMonday($openingHoursMonday)
    {
        $this->openingHoursMonday = $openingHoursMonday;
        return $this;
    }

    /**
     * Get openingHoursMonday
     *
     * @return string 
     */
    public function getOpeningHoursMonday()
    {
        return $this->openingHoursMonday;
    }
    
    /**
     * Set openingHoursTuesday
     *
     * @param string $openingHoursTuesday
     * @return User
     */
    public function setOpeningHoursTuesday($openingHoursTuesday)
    {
        $this->openingHoursTuesday = $openingHoursTuesday;
        return $this;
    }

    /**
     * Get openingHoursTuesday
     *
     * @return string 
     */
    public function getOpeningHoursTuesday()
    {
        return $this->openingHoursTuesday;
    }
    
    /**
     * Set openingHoursWednesday
     *
     * @param string $openingHoursWednesday
     * @return User
     */
    public function setOpeningHoursWednesday($openingHoursWednesday)
    {
        $this->openingHoursWednesday = $openingHoursWednesday;
        return $this;
    }

    /**
     * Get openingHoursWednesday
     *
     * @return string 
     */
    public function getOpeningHoursWednesday()
    {
        return $this->openingHoursWednesday;
    }
    
    /**
     * Set openingHoursThursday
     *
     * @param string $openingHoursThursday
     * @return User
     */
    public function setOpeningHoursThursday($openingHoursThursday)
    {
        $this->openingHoursThursday = $openingHoursThursday;
        return $this;
    }

    /**
     * Get openingHoursThursday
     *
     * @return string 
     */
    public function getOpeningHoursThursday()
    {
        return $this->openingHoursThursday;
    }
    
    /**
     * Set openingHoursFriday
     *
     * @param string $openingHoursFriday
     * @return User
     */
    public function setOpeningHoursFriday($openingHoursFriday)
    {
        $this->openingHoursFriday = $openingHoursFriday;
        return $this;
    }

    /**
     * Get openingHoursFriday
     *
     * @return string 
     */
    public function getOpeningHoursFriday()
    {
        return $this->openingHoursFriday;
    }
    
    /**
     * Set openingHoursSaturday
     *
     * @param string $openingHoursSaturday
     * @return User
     */
    public function setOpeningHoursSaturday($openingHoursSaturday)
    {
        $this->openingHoursSaturday = $openingHoursSaturday;
        return $this;
    }

    /**
     * Get openingHoursSaturday
     *
     * @return string 
     */
    public function getOpeningHoursSaturday()
    {
        return $this->openingHoursSaturday;
    }
    
    /**
     * Set openingHoursSunday
     *
     * @param string $openingHoursSunday
     * @return User
     */
    public function setOpeningHoursSunday($openingHoursSunday)
    {
        $this->openingHoursSunday = $openingHoursSunday;
        return $this;
    }

    /**
     * Get openingHoursSunday
     *
     * @return string 
     */
    public function getOpeningHoursSunday()
    {
        return $this->openingHoursSunday;
    }
    
    /**
     * Get services
     * 
     * @return \Doctrine\Common\Collections\ArrayCollection
     */
    public function getServices() 
    {
        return $this->services;
    }
    
    /**
     * Get default services
     * 
     * @return \Doctrine\Common\Collections\ArrayCollection
     */
    public function getDefaultServices() 
    {
        return $this->defaultServices;
    }
    
    /**
     * Set updatedAt
     *
     * @param datetime $updatedAt
     * @return User
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;
        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return string 
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }
    
    /**
     * Get the lowest price from the defined services
     *
     * @return string 
     */
    public function getLowestPrice()
    {
        if ($this->defaultServices && isset($this->defaultServices[0])) {
            $price = $this->defaultServices[0]->getPriceFrom();
            if (!empty($this->defaultServices[0]->getPriceTo())) {
              $price .= " - ".$this->defaultServices[0]->getPriceTo();
            }
            
            return $price;
        }
        
        return "-";
    }
    
    public function getCurrentOpeningHours() {
        $currentDate = date('D');
        if ("Mon" == $currentDate) {
            return $this->getOpeningHoursMonday();
        } else if ("Tue" == $currentDate) {
            return $this->getOpeningHoursTuesday();
        } else if ("Wed" == $currentDate) {
            return $this->getOpeningHoursWednesday();
        } else if ("Thu" == $currentDate) {
            return $this->getOpeningHoursThursday();
        } else if ("Fri" == $currentDate) {
            return $this->getOpeningHoursFriday();
        } else if ("Sat" == $currentDate) {
            return $this->getOpeningHoursSaturday();
        } else if ("Sun" == $currentDate) {
            return $this->getOpeningHoursSunday();
        }
    }
    
    /**
     * If manually uploading a file (i.e. not using Symfony Form) ensure an instance
     * of 'UploadedFile' is injected into this setter to trigger the  update. If this
     * bundle's configuration parameter 'inject_on_load' is set to 'true' this setter
     * must be able to accept an instance of 'File' as the bundle will inject one here
     * during Doctrine hydration.
     *
     * @param File|\Symfony\Component\HttpFoundation\File\UploadedFile $image
     *
     * @return Product
     */
    public function setImageFile(File $image = null)
    {
        $this->imageFile = $image;

        if ($image) {
            // It is required that at least one field changes if you are using doctrine
            // otherwise the event listeners won't be called and the file is lost
            $this->updatedAt = new \DateTimeImmutable();
        }
        
        return $this;
    }

    /**
     * @return File|null
     */
    public function getImageFile() {
        return $this->imageFile;
    }

    /**
     * @param string $imageName
     *
     * @return Product
     */
    public function setImageName($imageName) {
        $this->imageName = $imageName;
        
        return $this;
    }

    /**
     * @return string|null
     */
    public function getImageName() {
        return $this->imageName;
    }
    
    /**
     * @param integer $imageSize
     *
     * @return Product
     */
    public function setImageSize($imageSize) {
        $this->imageSize = $imageSize;
        
        return $this;
    }

    /**
     * @return integer|null
     */
    public function getImageSize() {
        return $this->imageSize;
    }
    
    public function removeService(Service $service)
    {
        $this->services->removeElement($service);
    }
    
    public function removeDefaultService(DefaultService $service)
    {
        $this->defaultServices->removeElement($service);
    }
}

