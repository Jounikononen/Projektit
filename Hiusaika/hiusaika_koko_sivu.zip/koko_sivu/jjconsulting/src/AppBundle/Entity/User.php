<?php
namespace AppBundle\Entity;

use FOS\UserBundle\Model\User as BaseUser;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="fos_user")
 */
class User extends BaseUser
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;
    
    /**
     * @ORM\OneToOne(targetEntity="Company", inversedBy="user", cascade={"persist", "remove"})
     * 
     */
    private $company;
    
    /**
     * @var boolean
     * 
     * @ORM\Column(name="confirmed", type="boolean")
     */
    private $confirmed;

    public function __construct()
    {
        parent::__construct();
        $this->company = new Company();
        $this->confirmed = false;
    }
    
    /**
     * Set company
     *
     * @param \AppBundle\Entity\Company $company
     * @return User
     */
    public function setCompany(\AppBundle\Entity\Company $company)
    {
        $this->company = $company;

        return $this;
    }

    /**
     * Get company
     *
     * @return \AppBundle\Entity\Company $company
     */
    public function getCompany() {
        return $this->company;
    }
    
    public function setEmail($email)
    {
        parent::setEmail($email);
        $this->setUsername($email);

        return $this;
    }
    
    /**
     * Set confirmed
     *
     * @param boolean $confirmed
     * @return User
     */
    public function setConfirmed($confirmed) {
        $this->confirmed = $confirmed;
        
        return $this;
    }
    
    /**
     * Get confirmed
     *
     * @return boolean 
     */
    public function isConfirmed() {
        return $this->confirmed;
    } 
}