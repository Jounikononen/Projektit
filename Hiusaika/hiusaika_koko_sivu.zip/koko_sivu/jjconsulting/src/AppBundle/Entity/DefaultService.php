<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * DefaultService
 *
 * @ORM\Table(name="default_service")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\DefaultServiceRepository")
 */
class DefaultService
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="DefaultServiceName", cascade={"persist"}, inversedBy="services")
     * @ORM\JoinColumn(name="name_id", referencedColumnName="id")
     */
    private $name;

    /**
    * @ORM\Column(name="price_from", type="integer", precision=7, scale=2)
    */
    private $priceFrom;
    
    /**
    * @ORM\Column(name="price_to", type="integer", precision=7, scale=2, nullable=true)
    */
    private $priceTo;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    public function setName(DefaultServiceName $name)
    {
        $this->name = $name;

        return $this;
    }

    public function getName()
    {
        return $this->name;
    }
    
    /**
     * Set priceFrom
     *
     * @param decimal $priceFrom
     *
     * @return DefaultService
     */
    public function setPriceFrom($priceFrom)
    {
        $this->priceFrom = $priceFrom;

        return $this;
    }

    /**
     * Get priceFrom
     *
     * @return decimal
     */
    public function getPriceFrom()
    {
        return $this->priceFrom;
    }
    
    /**
     * Set priceTo
     *
     * @param decimal $priceTo
     *
     * @return DefaultService
     */
    public function setPriceTo($priceTo)
    {
        $this->priceTo = $priceTo;

        return $this;
    }

    /**
     * Get priceTo
     *
     * @return decimal
     */
    public function getPriceTo()
    {
        return $this->priceTo;
    }
}

