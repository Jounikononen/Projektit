<?php

/* :default:index.html.twig */
class __TwigTemplate_561acfc1c1b1bd3b48d997bca591f8717613e0d1623836f7125495011f1ed3d3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":default:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    <!--Yläpalkki / navigaatio-->
<nav class=\"navbar navbar-default navbar-fixed-top\" >
  <div class=\"container\">
    <div class=\"navbar-header\">
\t<!--pienet näytöt navigaatiopalkki-->
      <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#myNavbar\">
        <span class=\"icon-bar\"></span>
        <span class=\"icon-bar\"></span>
        <span class=\"icon-bar\"></span>                        
      </button>
      <a class=\"navbar-brand\" href=\"etusivu.html\">Logo</a>
    </div>
    <div class=\"collapse navbar-collapse\" id=\"myNavbar\">
      <ul class=\"nav navbar-nav navbar-right\">
        <li><a href=\"about.html\">About</a></li>
        <li><a href=\"yritykset.html\">Yrityksille</a></li>
      </ul>
    </div>
  </div>
</nav>

<!--TÄRKEIN eli hakupalkki-->
<div class=\"jumbotron text-center\">
  <div id=\"otsikko\">
  <h3>Hae</h3> 
  </div>
 
  <form>
    <div class=\"input-group\">
      <input id=\"paikkakunta\" class=\"form-control\" size=\"50\" placeholder=\"Hae paikkakunnalta...\"/>
      <div class=\"input-group-btn\">
        <button type=\"button\" id=\"haku\" class=\"btn btn-danger\">Hae</button>
      </div>
    </div>
  </form>
  
  <!--Tässä piilotettuna muutamat yritykset, mitkä löytyvät mikkeli tai lappeenranta hakusanoilla-->
  <!--Ei tuloksia div-->
  <div class=\"osumat\">
\t<div id=\"ei_tuloksia\">
\tEi tuloksia hakemallasi kaupungilla :(
\t</div>
\t
\t<!--Mikkelin alueen yrityksien tietoja-->
\t<div class=\"mikkeli\">
\t<a href=\"yritys-1.html\"><div class=\"ekat_1\" onmouseover=\"this.style.background='#d3d3d3'\" onmouseout=\"this.style.background='white';\">
\t<div class=\"kuva\">
\t<img src=\"IMG/yritys_1.png\"></img>
\t</div>
\t<div class=\"tietoja\">
\t<div class=\"yritys-nimi\">
\t<h3>yritys1</h3>
\t</div>
\t<div class=\"yritys-osoite\">
\t<h5>Porrassalmenkatu 100</h5>
\t</div>
\t<div class=\"yritys-puh\">
\t<h5>015-32423432423</h5>
\t</div>
\t<div class=\"yritys-sposti\">
\t<h5>yritys1@posti.fi</h5>
\t</div>
\t<div class=\"yritys-auki\">
\t<h5>Arkisin 8.30- La 8.00-14.00</h5>
\t</div>
\t<div class=\"yritys-hinnat\">
\t<h5>Hinnat alkaen 200€</h5>
\t</div>
\t
\t</div>
\t</div>
\t</a>
    </div>
\t<div class=\"mikkeli\">
\t<a href=\"yritys-2.html\"><div class=\"ekat_1\" onmouseover=\"this.style.background='#d3d3d3'\" onmouseout=\"this.style.background='white';\">
\t<div class=\"kuva\">
\t<img src=\"IMG/yritys_2.png\"></img>
\t</div>
\t<div class=\"tietoja\">
\t<div class=\"yritys-nimi\">
\t<h3>yritys2</h3>
\t</div>
\t<div class=\"yritys-osoite\">
\t<h5>Porrassalmenkatu 100</h5>
\t</div>
\t<div class=\"yritys-puh\">
\t<h5>015-43234324234234</h5>
\t</div>
\t<div class=\"yritys-sposti\">
\t<h5>yritys2@posti.fi</h5>
\t</div>
\t<div class=\"yritys-auki\">
\t<h5>Arkisin 8:30- La 8.30-13:30</h5>
\t</div>
\t<div class=\"yritys-hinnat\">
\t<h5>Hinnat alkaen 200€</h5>
\t</div>
\t</div>
\t</div>
\t</a>
\t</div>
\t
\t<div class=\"mikkeli\">
\t<a href=\"yritys-3.html\"><div class=\"ekat_1\" onmouseover=\"this.style.background='#d3d3d3'\" onmouseout=\"this.style.background='white';\">
\t<div class=\"kuva\">
\t<img src=\"IMG/yritys_3.png\"></img>
\t</div>
\t<div class=\"tietoja\">
\t<div class=\"yritys-nimi\">
\t<h3>yritys3</h3>
\t</div>
\t<div class=\"yritys-osoite\">
\t<h5>Maaherrankatu 100</h5>
\t</div>
\t<div class=\"yritys-puh\">
\t<h5>010 43423423423</h5>
\t</div>
\t<div class=\"yritys-sposti\">
\t<h5>yritys3@posti.fi</h5>
\t</div>
\t<div class=\"yritys-auki\">
\t<h5>Arkisin 9.00-19.00 La 9.00-16.00</h5>
\t</div>
\t<div class=\"yritys-hinnat\">
\t<h5>Hinnat alkaen 310€</h5>
\t</div>
\t</div>
\t</div>
\t</a>
\t</div>
\t
\t<!--Lappeenranta div-->
\t<div class=\"lappeenranta\">
\t<a href=\"yritys-4.html\"><div class=\"ekat_2\" onmouseover=\"this.style.background='#d3d3d3'\" onmouseout=\"this.style.background='white';\">
\t<div class=\"kuva\">
\t<img src=\"IMG/yritys_4.jpg\"></img>
\t</div>
\t<div class=\"tietoja\">
\t<div class=\"yritys-nimi\">
\t<h3>yritys4</h3>
\t</div>
\t<div class=\"yritys-osoite\">
\t<h5>Valtakatu 200</h5>
\t</div>
\t<div class=\"yritys-puh\">
\t<h5>044-3423424234</h5>
\t</div>
\t<div class=\"yritys-sposti\">
\t<h5>yritys4@posti.fi</h5>
\t</div>
\t<div class=\"yritys-auki\">
\t<h5>Arkisin 9.00-18.00 La 9.00-17.00</h5>
\t</div>
\t<div class=\"yritys-hinnat\">
\t<h5>Hinnat alkaen 250€</h5>
\t</div>
\t</div>
\t</div>
\t</a>
  </div>
  
  <div class=\"lappeenranta\">
\t<a href=\"yritys-5.html\"><div class=\"ekat_2\" onmouseover=\"this.style.background='#d3d3d3'\" onmouseout=\"this.style.background='white';\">
\t<div class=\"kuva\">
\t<img src=\"IMG/yritys_5.png\"></img>
\t</div>
\t<div class=\"tietoja\">
\t<div class=\"yritys-nimi\">
\t<h3>yritys5</h3>
\t</div>
\t<div class=\"yritys-osoite\">
\t<h5>Puhakankatu 100</h5>
\t</div>
\t<div class=\"yritys-puh\">
\t<h5>050-324342423</h5>
\t</div>
\t<div class=\"yritys-sposti\">
\t<h5>yritys5@posti.fi</h5>
\t</div>
\t<div class=\"yritys-auki\">
\t<h5>Arkisin 9.00-18.00 La 8.30-13.30</h5>
\t</div>
\t<div class=\"yritys-hinnat\">
\t<h5>Hinnat alkaen 260€</h5>
\t</div>
\t</div>
\t</div>
\t</a>
  </div>
  </div>
  
</div>

<!--nama_piiloon divin sisällä olevat piilotetaan kun painetaan hakunappia-->
<div id=\"nama_piiloon\">
<!--Tietoa meistä ja tavoitteet-->
<div id=\"about\" class=\"container-fluid\">
  <div class=\"row\">
    <div class=\"col-sm-8\">
      <h2>Tietoa meistä</h2><br>
      <h4>tekstiä</h4><br>
      <p>Lisää tekstiä</p>
      <br><a href=\"about.html\"><button class=\"btn btn-default btn-lg\">Lue lisää</button></a>
    </div>
    <div class=\"col-sm-4\">
      <span class=\"glyphicon glyphicon-flag logo\"></span>
    </div>
  </div>
</div>

<!--asiakkaiden Kommentit-->
<div class=\"container-fluid text-center bg-grey\">
  
  <h2>Asiakkaittemme kommentteja</h2>
  <div id=\"myCarousel\" class=\"carousel slide text-center\" data-ride=\"carousel\">
    <!-- Indikaattorit -->
    <ol class=\"carousel-indicators\">
      <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>
      <li data-target=\"#myCarousel\" data-slide-to=\"1\"></li>
      <li data-target=\"#myCarousel\" data-slide-to=\"2\"></li>
    </ol>

    <!-- Kommentit karusellissa -->
    <div class=\"carousel-inner\" role=\"listbox\">
      <div class=\"item active\">
        <h4>\"Ihan loistavat sivut!\"<br><span>Jaana, Mikkeli</span></h4>
      </div>
      <div class=\"item\">
        <h4>\"Tälläistä nettisivua on kaivattu!\"<br><span>Joona, Lappeenranta</span></h4>
      </div>
      <div class=\"item\">
        <h4>\"Hyvät sivut!\"<br><span>Jouni, Lappeenranta</span></h4>
      </div>
    </div>

    <!-- Nuolet vasen oikea -->
    <a class=\"left carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"prev\">
      <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span>
      <span class=\"sr-only\">takaisin</span>
    </a>
    <a class=\"right carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"next\">
      <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden=\"true\"></span>
      <span class=\"sr-only\">Seuraava</span>
    </a>
  </div>
</div>


<!--Ota yhteyttä- lomake-->
<div id=\"contact\" class=\"container-fluid\">
  <h2 class=\"text-center\">Lähetä palautetta</h2>
  <div class=\"row\">
    <div class=\"col-sm-5\">
      <p>Vastaamme palautteisiin 24 tunnin kuluessa</p>
      <p><span class=\"glyphicon glyphicon-phone\"></span> 040 778 4649</p>
      <p><span class=\"glyphicon glyphicon-envelope\"></span> jouni.kononen@gmail.com</p>
    </div>
    <div class=\"col-sm-7 slideanim\">
      <div class=\"row\">
        <div class=\"col-sm-6 form-group\">
          <input class=\"form-control\" id=\"name\" name=\"name\" placeholder=\"Nimi\" type=\"text\" required>
        </div>
        <div class=\"col-sm-6 form-group\">
          <input class=\"form-control\" id=\"email\" name=\"email\" placeholder=\"Sposti\" type=\"email\" required>
        </div>
      </div>
      <textarea class=\"form-control\" id=\"comments\" name=\"comments\" placeholder=\"Viesti\" rows=\"5\"></textarea><br>
      <div class=\"row\">
        <div class=\"col-sm-12 form-group\">
          <button id=\"laheta\" class=\"btn btn-default pull-right\" type=\"submit\">Lähetä</button>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
";
    }

    // line 282
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 283
        echo "    <link rel=\"stylesheet\" href=\"CSS/etusivu.tyylit.css\" />
";
    }

    // line 286
    public function block_javascripts($context, array $blocks = array())
    {
        // line 287
        echo "    <script src=\"JS/etusivu.js\"></script>
    <script src=\"JS/java.js\"></script>
";
    }

    public function getTemplateName()
    {
        return ":default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  324 => 287,  321 => 286,  316 => 283,  313 => 282,  33 => 4,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":default:index.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/default/index.html.twig");
    }
}
