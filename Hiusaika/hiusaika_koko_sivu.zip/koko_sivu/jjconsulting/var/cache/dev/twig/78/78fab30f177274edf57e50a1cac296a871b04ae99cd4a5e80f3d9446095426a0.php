<?php

/* FOSUserBundle:Resetting:email.txt.twig */
class __TwigTemplate_db5d20ee775952907f138fdc34b1b4963d6981cfa5bdadf2b2f16aa188337307 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3f19d9f70f25d7f14b74fac5f715fecc437747d98ede47e9c0ed75d4492c6719 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3f19d9f70f25d7f14b74fac5f715fecc437747d98ede47e9c0ed75d4492c6719->enter($__internal_3f19d9f70f25d7f14b74fac5f715fecc437747d98ede47e9c0ed75d4492c6719_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        $__internal_9aa743c8f3bcd645ea1831a53e7a6b81c0f0d29f02aa3cc342d566b37e539e85 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9aa743c8f3bcd645ea1831a53e7a6b81c0f0d29f02aa3cc342d566b37e539e85->enter($__internal_9aa743c8f3bcd645ea1831a53e7a6b81c0f0d29f02aa3cc342d566b37e539e85_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        echo "
";
        // line 8
        $this->displayBlock('body_text', $context, $blocks);
        // line 13
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_3f19d9f70f25d7f14b74fac5f715fecc437747d98ede47e9c0ed75d4492c6719->leave($__internal_3f19d9f70f25d7f14b74fac5f715fecc437747d98ede47e9c0ed75d4492c6719_prof);

        
        $__internal_9aa743c8f3bcd645ea1831a53e7a6b81c0f0d29f02aa3cc342d566b37e539e85->leave($__internal_9aa743c8f3bcd645ea1831a53e7a6b81c0f0d29f02aa3cc342d566b37e539e85_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_4684c39c305dd5b40eb4d24be6a38bdbd5cf7fa75b23be651407c0cf5ead3957 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4684c39c305dd5b40eb4d24be6a38bdbd5cf7fa75b23be651407c0cf5ead3957->enter($__internal_4684c39c305dd5b40eb4d24be6a38bdbd5cf7fa75b23be651407c0cf5ead3957_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        $__internal_509d0a1ab203ea699d35eaabba100ef22a6b2d42e99797f6096bfeb462080252 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_509d0a1ab203ea699d35eaabba100ef22a6b2d42e99797f6096bfeb462080252->enter($__internal_509d0a1ab203ea699d35eaabba100ef22a6b2d42e99797f6096bfeb462080252_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.email.subject", array("%username%" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "username", array())), "FOSUserBundle");
        
        $__internal_509d0a1ab203ea699d35eaabba100ef22a6b2d42e99797f6096bfeb462080252->leave($__internal_509d0a1ab203ea699d35eaabba100ef22a6b2d42e99797f6096bfeb462080252_prof);

        
        $__internal_4684c39c305dd5b40eb4d24be6a38bdbd5cf7fa75b23be651407c0cf5ead3957->leave($__internal_4684c39c305dd5b40eb4d24be6a38bdbd5cf7fa75b23be651407c0cf5ead3957_prof);

    }

    // line 8
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_ca6049d02a4a3272c35214125e4075070ee2bf54812d629bf7ae88537be3a896 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ca6049d02a4a3272c35214125e4075070ee2bf54812d629bf7ae88537be3a896->enter($__internal_ca6049d02a4a3272c35214125e4075070ee2bf54812d629bf7ae88537be3a896_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        $__internal_475406712a31c453bdc915d134dffe38e3908ea5b981c0a3adcb5664aec27f3a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_475406712a31c453bdc915d134dffe38e3908ea5b981c0a3adcb5664aec27f3a->enter($__internal_475406712a31c453bdc915d134dffe38e3908ea5b981c0a3adcb5664aec27f3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.email.message", array("%username%" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => ($context["confirmationUrl"] ?? $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_475406712a31c453bdc915d134dffe38e3908ea5b981c0a3adcb5664aec27f3a->leave($__internal_475406712a31c453bdc915d134dffe38e3908ea5b981c0a3adcb5664aec27f3a_prof);

        
        $__internal_ca6049d02a4a3272c35214125e4075070ee2bf54812d629bf7ae88537be3a896->leave($__internal_ca6049d02a4a3272c35214125e4075070ee2bf54812d629bf7ae88537be3a896_prof);

    }

    // line 13
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_fc9512b7452e2d8a6198a248ef8599d901d1c0921dab7d35cb02a021159ab509 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fc9512b7452e2d8a6198a248ef8599d901d1c0921dab7d35cb02a021159ab509->enter($__internal_fc9512b7452e2d8a6198a248ef8599d901d1c0921dab7d35cb02a021159ab509_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        $__internal_26d6a50b80248d8a4ca3622afb36847d0f1addd8ad1dbbafd8cea756d1ea7932 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_26d6a50b80248d8a4ca3622afb36847d0f1addd8ad1dbbafd8cea756d1ea7932->enter($__internal_26d6a50b80248d8a4ca3622afb36847d0f1addd8ad1dbbafd8cea756d1ea7932_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_26d6a50b80248d8a4ca3622afb36847d0f1addd8ad1dbbafd8cea756d1ea7932->leave($__internal_26d6a50b80248d8a4ca3622afb36847d0f1addd8ad1dbbafd8cea756d1ea7932_prof);

        
        $__internal_fc9512b7452e2d8a6198a248ef8599d901d1c0921dab7d35cb02a021159ab509->leave($__internal_fc9512b7452e2d8a6198a248ef8599d901d1c0921dab7d35cb02a021159ab509_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  85 => 13,  73 => 10,  64 => 8,  54 => 4,  45 => 2,  35 => 13,  33 => 8,  30 => 7,  28 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}
{% block subject %}
{%- autoescape false -%}
{{ 'resetting.email.subject'|trans({'%username%': user.username}) }}
{%- endautoescape -%}
{% endblock %}

{% block body_text %}
{% autoescape false %}
{{ 'resetting.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{% endautoescape %}
{% endblock %}
{% block body_html %}{% endblock %}
", "FOSUserBundle:Resetting:email.txt.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Resetting/email.txt.twig");
    }
}
