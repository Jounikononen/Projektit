<?php

/* VichUploaderBundle:Form:fields.html.twig */
class __TwigTemplate_5fcd346c4c90bce27559d4447463c60809d9352fb96ee83fc97bab4206b1481f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'vich_file_row' => array($this, 'block_vich_file_row'),
            'vich_file_widget' => array($this, 'block_vich_file_widget'),
            'vich_image_row' => array($this, 'block_vich_image_row'),
            'vich_image_widget' => array($this, 'block_vich_image_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_52d224a0f674d72860f69bf2f13fc5290fd32843b3958c16ddf910b0bfe0745c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_52d224a0f674d72860f69bf2f13fc5290fd32843b3958c16ddf910b0bfe0745c->enter($__internal_52d224a0f674d72860f69bf2f13fc5290fd32843b3958c16ddf910b0bfe0745c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "VichUploaderBundle:Form:fields.html.twig"));

        $__internal_4667775f62e9b4f599c5e8f5bdd9854b0e23491e03aa97dac3465142dfb6f222 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4667775f62e9b4f599c5e8f5bdd9854b0e23491e03aa97dac3465142dfb6f222->enter($__internal_4667775f62e9b4f599c5e8f5bdd9854b0e23491e03aa97dac3465142dfb6f222_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "VichUploaderBundle:Form:fields.html.twig"));

        // line 1
        $this->displayBlock('vich_file_row', $context, $blocks);
        // line 5
        echo "
";
        // line 6
        $this->displayBlock('vich_file_widget', $context, $blocks);
        // line 20
        echo "
";
        // line 21
        $this->displayBlock('vich_image_row', $context, $blocks);
        // line 25
        echo "
";
        // line 26
        $this->displayBlock('vich_image_widget', $context, $blocks);
        
        $__internal_52d224a0f674d72860f69bf2f13fc5290fd32843b3958c16ddf910b0bfe0745c->leave($__internal_52d224a0f674d72860f69bf2f13fc5290fd32843b3958c16ddf910b0bfe0745c_prof);

        
        $__internal_4667775f62e9b4f599c5e8f5bdd9854b0e23491e03aa97dac3465142dfb6f222->leave($__internal_4667775f62e9b4f599c5e8f5bdd9854b0e23491e03aa97dac3465142dfb6f222_prof);

    }

    // line 1
    public function block_vich_file_row($context, array $blocks = array())
    {
        $__internal_89dca41c7f4f90e102867644e7fd8605966ebe1143931079d3f3cec75f343b85 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_89dca41c7f4f90e102867644e7fd8605966ebe1143931079d3f3cec75f343b85->enter($__internal_89dca41c7f4f90e102867644e7fd8605966ebe1143931079d3f3cec75f343b85_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "vich_file_row"));

        $__internal_eee91883da9b874d64e2c4a7a0d86f928e065f6a32d4d7d91e80bfe3fd9fe883 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eee91883da9b874d64e2c4a7a0d86f928e065f6a32d4d7d91e80bfe3fd9fe883->enter($__internal_eee91883da9b874d64e2c4a7a0d86f928e065f6a32d4d7d91e80bfe3fd9fe883_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "vich_file_row"));

        // line 2
        $context["force_error"] = true;
        // line 3
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_eee91883da9b874d64e2c4a7a0d86f928e065f6a32d4d7d91e80bfe3fd9fe883->leave($__internal_eee91883da9b874d64e2c4a7a0d86f928e065f6a32d4d7d91e80bfe3fd9fe883_prof);

        
        $__internal_89dca41c7f4f90e102867644e7fd8605966ebe1143931079d3f3cec75f343b85->leave($__internal_89dca41c7f4f90e102867644e7fd8605966ebe1143931079d3f3cec75f343b85_prof);

    }

    // line 6
    public function block_vich_file_widget($context, array $blocks = array())
    {
        $__internal_ba78fd9340275c2d3ca17ecb6351d1cf198ea90d5c89aa573b0459f8cd4a90b3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba78fd9340275c2d3ca17ecb6351d1cf198ea90d5c89aa573b0459f8cd4a90b3->enter($__internal_ba78fd9340275c2d3ca17ecb6351d1cf198ea90d5c89aa573b0459f8cd4a90b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "vich_file_widget"));

        $__internal_08d85bcb3a0d3aed3d9c59d9db774b593b347a5427ba6e737c69359dee314939 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_08d85bcb3a0d3aed3d9c59d9db774b593b347a5427ba6e737c69359dee314939->enter($__internal_08d85bcb3a0d3aed3d9c59d9db774b593b347a5427ba6e737c69359dee314939_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "vich_file_widget"));

        // line 7
        ob_start();
        // line 8
        echo "    <div class=\"vich-file\">
        ";
        // line 9
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "file", array()), 'widget');
        echo "
        ";
        // line 10
        if ($this->getAttribute(($context["form"] ?? null), "delete", array(), "any", true, true)) {
            // line 11
            echo "        ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "delete", array()), 'row');
            echo "
        ";
        }
        // line 13
        echo "
        ";
        // line 14
        if ((array_key_exists("download_uri", $context) && ($context["download_uri"] ?? $this->getContext($context, "download_uri")))) {
            // line 15
            echo "        <a href=\"";
            echo twig_escape_filter($this->env, ($context["download_uri"] ?? $this->getContext($context, "download_uri")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("download", array(), "VichUploaderBundle"), "html", null, true);
            echo "</a>
        ";
        }
        // line 17
        echo "    </div>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_08d85bcb3a0d3aed3d9c59d9db774b593b347a5427ba6e737c69359dee314939->leave($__internal_08d85bcb3a0d3aed3d9c59d9db774b593b347a5427ba6e737c69359dee314939_prof);

        
        $__internal_ba78fd9340275c2d3ca17ecb6351d1cf198ea90d5c89aa573b0459f8cd4a90b3->leave($__internal_ba78fd9340275c2d3ca17ecb6351d1cf198ea90d5c89aa573b0459f8cd4a90b3_prof);

    }

    // line 21
    public function block_vich_image_row($context, array $blocks = array())
    {
        $__internal_e93551a7ca9c48d7763345b7b1641706ad114b5f571ca2eabaac94ba24cd8c23 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e93551a7ca9c48d7763345b7b1641706ad114b5f571ca2eabaac94ba24cd8c23->enter($__internal_e93551a7ca9c48d7763345b7b1641706ad114b5f571ca2eabaac94ba24cd8c23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "vich_image_row"));

        $__internal_20bdd69c9e2832361286c697f23bbbc03741f7ed39fbee00d20c7a66dcc8e5fd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_20bdd69c9e2832361286c697f23bbbc03741f7ed39fbee00d20c7a66dcc8e5fd->enter($__internal_20bdd69c9e2832361286c697f23bbbc03741f7ed39fbee00d20c7a66dcc8e5fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "vich_image_row"));

        // line 22
        $context["force_error"] = true;
        // line 23
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_20bdd69c9e2832361286c697f23bbbc03741f7ed39fbee00d20c7a66dcc8e5fd->leave($__internal_20bdd69c9e2832361286c697f23bbbc03741f7ed39fbee00d20c7a66dcc8e5fd_prof);

        
        $__internal_e93551a7ca9c48d7763345b7b1641706ad114b5f571ca2eabaac94ba24cd8c23->leave($__internal_e93551a7ca9c48d7763345b7b1641706ad114b5f571ca2eabaac94ba24cd8c23_prof);

    }

    // line 26
    public function block_vich_image_widget($context, array $blocks = array())
    {
        $__internal_e574bf42a84727ad5c7aaf086b2d27b30f209e51f6b131edeb9a1e9b7421a73f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e574bf42a84727ad5c7aaf086b2d27b30f209e51f6b131edeb9a1e9b7421a73f->enter($__internal_e574bf42a84727ad5c7aaf086b2d27b30f209e51f6b131edeb9a1e9b7421a73f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "vich_image_widget"));

        $__internal_50f478b52aaaddd59d6219b52819507927552ea0b2f2db4171498d45072d9ced = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50f478b52aaaddd59d6219b52819507927552ea0b2f2db4171498d45072d9ced->enter($__internal_50f478b52aaaddd59d6219b52819507927552ea0b2f2db4171498d45072d9ced_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "vich_image_widget"));

        // line 27
        ob_start();
        // line 28
        echo "    <div class=\"vich-image\">
        ";
        // line 29
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "file", array()), 'widget');
        echo "
        ";
        // line 30
        if ($this->getAttribute(($context["form"] ?? null), "delete", array(), "any", true, true)) {
            // line 31
            echo "        ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "delete", array()), 'row');
            echo "
        ";
        }
        // line 33
        echo "
        ";
        // line 34
        if ((array_key_exists("download_uri", $context) && ($context["download_uri"] ?? $this->getContext($context, "download_uri")))) {
            // line 35
            echo "         <a href=\"";
            echo twig_escape_filter($this->env, ($context["download_uri"] ?? $this->getContext($context, "download_uri")), "html", null, true);
            echo "\"><img src=\"";
            echo twig_escape_filter($this->env, ($context["download_uri"] ?? $this->getContext($context, "download_uri")), "html", null, true);
            echo "\" alt=\"\" /></a>
        ";
        }
        // line 37
        echo "        ";
        if (((($context["show_download_link"] ?? $this->getContext($context, "show_download_link")) && array_key_exists("download_uri", $context)) && ($context["download_uri"] ?? $this->getContext($context, "download_uri")))) {
            // line 38
            echo "        <a href=\"";
            echo twig_escape_filter($this->env, ($context["download_uri"] ?? $this->getContext($context, "download_uri")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("download", array(), "VichUploaderBundle"), "html", null, true);
            echo "</a>
        ";
        }
        // line 40
        echo "    </div>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_50f478b52aaaddd59d6219b52819507927552ea0b2f2db4171498d45072d9ced->leave($__internal_50f478b52aaaddd59d6219b52819507927552ea0b2f2db4171498d45072d9ced_prof);

        
        $__internal_e574bf42a84727ad5c7aaf086b2d27b30f209e51f6b131edeb9a1e9b7421a73f->leave($__internal_e574bf42a84727ad5c7aaf086b2d27b30f209e51f6b131edeb9a1e9b7421a73f_prof);

    }

    public function getTemplateName()
    {
        return "VichUploaderBundle:Form:fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  197 => 40,  189 => 38,  186 => 37,  178 => 35,  176 => 34,  173 => 33,  167 => 31,  165 => 30,  161 => 29,  158 => 28,  156 => 27,  147 => 26,  137 => 23,  135 => 22,  126 => 21,  114 => 17,  106 => 15,  104 => 14,  101 => 13,  95 => 11,  93 => 10,  89 => 9,  86 => 8,  84 => 7,  75 => 6,  65 => 3,  63 => 2,  54 => 1,  44 => 26,  41 => 25,  39 => 21,  36 => 20,  34 => 6,  31 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block vich_file_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock %}

{% block vich_file_widget %}
{% spaceless %}
    <div class=\"vich-file\">
        {{ form_widget(form.file) }}
        {% if form.delete is defined %}
        {{ form_row(form.delete) }}
        {% endif %}

        {% if download_uri is defined and download_uri %}
        <a href=\"{{ download_uri }}\">{{ 'download'|trans({}, 'VichUploaderBundle') }}</a>
        {% endif %}
    </div>
{% endspaceless %}
{% endblock %}

{% block vich_image_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock %}

{% block vich_image_widget %}
{% spaceless %}
    <div class=\"vich-image\">
        {{ form_widget(form.file) }}
        {% if form.delete is defined %}
        {{ form_row(form.delete) }}
        {% endif %}

        {% if download_uri is defined and download_uri %}
         <a href=\"{{ download_uri }}\"><img src=\"{{ download_uri }}\" alt=\"\" /></a>
        {% endif %}
        {% if show_download_link and download_uri is defined and download_uri%}
        <a href=\"{{ download_uri }}\">{{ 'download'|trans({}, 'VichUploaderBundle') }}</a>
        {% endif %}
    </div>
{% endspaceless %}
{% endblock %}
", "VichUploaderBundle:Form:fields.html.twig", "/Users/villel/Sites/jjconsulting/vendor/vich/uploader-bundle/Resources/views/Form/fields.html.twig");
    }
}
