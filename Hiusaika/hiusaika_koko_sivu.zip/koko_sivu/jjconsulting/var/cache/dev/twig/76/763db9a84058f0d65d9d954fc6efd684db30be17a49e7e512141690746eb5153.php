<?php

/* FOSUserBundle:Registration:email.txt.twig */
class __TwigTemplate_e01a73e6884b00a46a0b6010ae0f197065af32c7d4beff75239579ca8d02697d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8c95aca82dd90642f50693e1f867dc46e87ce088d109bf676e480ad847f57714 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8c95aca82dd90642f50693e1f867dc46e87ce088d109bf676e480ad847f57714->enter($__internal_8c95aca82dd90642f50693e1f867dc46e87ce088d109bf676e480ad847f57714_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:email.txt.twig"));

        $__internal_18e1b2a47aa41f602689acbba962444ccf669b727ad6d3353dc2218d3267a6a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_18e1b2a47aa41f602689acbba962444ccf669b727ad6d3353dc2218d3267a6a6->enter($__internal_18e1b2a47aa41f602689acbba962444ccf669b727ad6d3353dc2218d3267a6a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        echo "
";
        // line 8
        $this->displayBlock('body_text', $context, $blocks);
        // line 13
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_8c95aca82dd90642f50693e1f867dc46e87ce088d109bf676e480ad847f57714->leave($__internal_8c95aca82dd90642f50693e1f867dc46e87ce088d109bf676e480ad847f57714_prof);

        
        $__internal_18e1b2a47aa41f602689acbba962444ccf669b727ad6d3353dc2218d3267a6a6->leave($__internal_18e1b2a47aa41f602689acbba962444ccf669b727ad6d3353dc2218d3267a6a6_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_e7ea5035d246ddda5bae070fca7554a57a611b2f38bc50174003330977fd6dab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e7ea5035d246ddda5bae070fca7554a57a611b2f38bc50174003330977fd6dab->enter($__internal_e7ea5035d246ddda5bae070fca7554a57a611b2f38bc50174003330977fd6dab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        $__internal_81fdce069449100b7c3c2220090014b6f4604fd821e99151ab32b850cfad79cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81fdce069449100b7c3c2220090014b6f4604fd821e99151ab32b850cfad79cc->enter($__internal_81fdce069449100b7c3c2220090014b6f4604fd821e99151ab32b850cfad79cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.email.subject", array("%username%" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => ($context["confirmationUrl"] ?? $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        
        $__internal_81fdce069449100b7c3c2220090014b6f4604fd821e99151ab32b850cfad79cc->leave($__internal_81fdce069449100b7c3c2220090014b6f4604fd821e99151ab32b850cfad79cc_prof);

        
        $__internal_e7ea5035d246ddda5bae070fca7554a57a611b2f38bc50174003330977fd6dab->leave($__internal_e7ea5035d246ddda5bae070fca7554a57a611b2f38bc50174003330977fd6dab_prof);

    }

    // line 8
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_151da580f56e023eba4b20dac68b315a1156376c9589178c4e3c32f94ebd3fbe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_151da580f56e023eba4b20dac68b315a1156376c9589178c4e3c32f94ebd3fbe->enter($__internal_151da580f56e023eba4b20dac68b315a1156376c9589178c4e3c32f94ebd3fbe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        $__internal_e4c85cbbf78a07d7f2bc9da22841d91cf3328d58606e517c9562189a1e77f444 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e4c85cbbf78a07d7f2bc9da22841d91cf3328d58606e517c9562189a1e77f444->enter($__internal_e4c85cbbf78a07d7f2bc9da22841d91cf3328d58606e517c9562189a1e77f444_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.email.message", array("%username%" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => ($context["confirmationUrl"] ?? $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_e4c85cbbf78a07d7f2bc9da22841d91cf3328d58606e517c9562189a1e77f444->leave($__internal_e4c85cbbf78a07d7f2bc9da22841d91cf3328d58606e517c9562189a1e77f444_prof);

        
        $__internal_151da580f56e023eba4b20dac68b315a1156376c9589178c4e3c32f94ebd3fbe->leave($__internal_151da580f56e023eba4b20dac68b315a1156376c9589178c4e3c32f94ebd3fbe_prof);

    }

    // line 13
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_de9be4da13602e37653843562f6ab7e355260a62377e687d841f4477da8e23ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_de9be4da13602e37653843562f6ab7e355260a62377e687d841f4477da8e23ff->enter($__internal_de9be4da13602e37653843562f6ab7e355260a62377e687d841f4477da8e23ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        $__internal_6c0bff0efbd5f1c4e10d062703f4ea5593a59bcd659d94ca135cfb20a92d7c55 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c0bff0efbd5f1c4e10d062703f4ea5593a59bcd659d94ca135cfb20a92d7c55->enter($__internal_6c0bff0efbd5f1c4e10d062703f4ea5593a59bcd659d94ca135cfb20a92d7c55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_6c0bff0efbd5f1c4e10d062703f4ea5593a59bcd659d94ca135cfb20a92d7c55->leave($__internal_6c0bff0efbd5f1c4e10d062703f4ea5593a59bcd659d94ca135cfb20a92d7c55_prof);

        
        $__internal_de9be4da13602e37653843562f6ab7e355260a62377e687d841f4477da8e23ff->leave($__internal_de9be4da13602e37653843562f6ab7e355260a62377e687d841f4477da8e23ff_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  85 => 13,  73 => 10,  64 => 8,  54 => 4,  45 => 2,  35 => 13,  33 => 8,  30 => 7,  28 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}
{% block subject %}
{%- autoescape false -%}
{{ 'registration.email.subject'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{%- endautoescape -%}
{% endblock %}

{% block body_text %}
{% autoescape false %}
{{ 'registration.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{% endautoescape %}
{% endblock %}
{% block body_html %}{% endblock %}
", "FOSUserBundle:Registration:email.txt.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Registration/email.txt.twig");
    }
}
