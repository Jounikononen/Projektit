<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_9a797a7fe177c9b13bf2b2c31e78c92f9c6985f8fc193b56a41099bd98921558 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4aaa1fc111b74c38a7c00b7706ee08a255b148596ec69774e9d9c92ba0449b45 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4aaa1fc111b74c38a7c00b7706ee08a255b148596ec69774e9d9c92ba0449b45->enter($__internal_4aaa1fc111b74c38a7c00b7706ee08a255b148596ec69774e9d9c92ba0449b45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_6324e9a10487f8a3c9de9a4341f56736e9c1f5d39af62a1c5783f103409d0040 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6324e9a10487f8a3c9de9a4341f56736e9c1f5d39af62a1c5783f103409d0040->enter($__internal_6324e9a10487f8a3c9de9a4341f56736e9c1f5d39af62a1c5783f103409d0040_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_4aaa1fc111b74c38a7c00b7706ee08a255b148596ec69774e9d9c92ba0449b45->leave($__internal_4aaa1fc111b74c38a7c00b7706ee08a255b148596ec69774e9d9c92ba0449b45_prof);

        
        $__internal_6324e9a10487f8a3c9de9a4341f56736e9c1f5d39af62a1c5783f103409d0040->leave($__internal_6324e9a10487f8a3c9de9a4341f56736e9c1f5d39af62a1c5783f103409d0040_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.atom.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
