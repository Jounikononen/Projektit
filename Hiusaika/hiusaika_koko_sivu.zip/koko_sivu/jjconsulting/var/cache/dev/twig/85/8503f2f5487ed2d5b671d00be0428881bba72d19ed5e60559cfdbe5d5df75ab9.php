<?php

/* FOSUserBundle:Resetting:request_content.html.twig */
class __TwigTemplate_823d7165db492f06269b9065ecfee5dffdb74d15ca35c358ee440544617bc376 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9098448a45e6ed905f970f871ecc1e00e021471e981ae6bb7ed5f6b7dd6d0bae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9098448a45e6ed905f970f871ecc1e00e021471e981ae6bb7ed5f6b7dd6d0bae->enter($__internal_9098448a45e6ed905f970f871ecc1e00e021471e981ae6bb7ed5f6b7dd6d0bae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request_content.html.twig"));

        $__internal_6c8dc72f740b5b5377cf201f512bd3cfc3525c2c3086a061a275569d12875952 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c8dc72f740b5b5377cf201f512bd3cfc3525c2c3086a061a275569d12875952->enter($__internal_6c8dc72f740b5b5377cf201f512bd3cfc3525c2c3086a061a275569d12875952_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request_content.html.twig"));

        // line 2
        echo "
<div class=\"container-fluid\" id=\"register-container\">
    <div class=\"container\">
        <h2 class=\"text-center\">Unohtuiko salasana?</h2>
        <h4 class=\"text-center\">Ei hätää. Ole hyvä, ja kirjoita sähköpostiosoitteesi, niin lähetämme sinulle ohjeet salasanan vaihtamiseksi.</h4>
        <form action=\"";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_resetting_send_email");
        echo "\" method=\"POST\" class=\"fos_user_resetting_request\">
            <div class=\"row\">
                <div class=\"col-md-6 col-md-offset-3\">
                    <div class=\"input-group margin-bottom-sm\">
                        <span class=\"input-group-addon\"><i class=\"fa fa-envelope-o fa-fw\"></i></span>
                        <input class=\"form-control\" type=\"text\" id=\"username\" name=\"username\" placeholder=\"Sähköposti\" required=\"required\">
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12 text-center\"> 
                    <input type=\"submit\" class=\"btn btn-default login-button\" id=\"_submit\" name=\"_submit\" value=\"Alusta salasana\" />
                </div>
            </div>
        </form>
        
        <div class=\"row\">
            <div class=\"col-sm-12 text-center\"> 
                <p>Ei tunnusta?</p>
                <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_registration_register");
        echo "\" class=\"btn btn-default login-button\">Rekisteröidy</a>
            </div>
        </div>
    </div>
</div>

";
        // line 32
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 35
        echo "
";
        // line 36
        $this->displayBlock('javascripts', $context, $blocks);
        
        $__internal_9098448a45e6ed905f970f871ecc1e00e021471e981ae6bb7ed5f6b7dd6d0bae->leave($__internal_9098448a45e6ed905f970f871ecc1e00e021471e981ae6bb7ed5f6b7dd6d0bae_prof);

        
        $__internal_6c8dc72f740b5b5377cf201f512bd3cfc3525c2c3086a061a275569d12875952->leave($__internal_6c8dc72f740b5b5377cf201f512bd3cfc3525c2c3086a061a275569d12875952_prof);

    }

    // line 32
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_f2b59141cc83621a5b9d0979c6a728e7557157d1e595fbc055196080a4ca0f85 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f2b59141cc83621a5b9d0979c6a728e7557157d1e595fbc055196080a4ca0f85->enter($__internal_f2b59141cc83621a5b9d0979c6a728e7557157d1e595fbc055196080a4ca0f85_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_ed637c178bc393268a76ffeae933f60ecb0ce82e46fda8cb4b89f060368c1474 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed637c178bc393268a76ffeae933f60ecb0ce82e46fda8cb4b89f060368c1474->enter($__internal_ed637c178bc393268a76ffeae933f60ecb0ce82e46fda8cb4b89f060368c1474_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 33
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/security.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
";
        
        $__internal_ed637c178bc393268a76ffeae933f60ecb0ce82e46fda8cb4b89f060368c1474->leave($__internal_ed637c178bc393268a76ffeae933f60ecb0ce82e46fda8cb4b89f060368c1474_prof);

        
        $__internal_f2b59141cc83621a5b9d0979c6a728e7557157d1e595fbc055196080a4ca0f85->leave($__internal_f2b59141cc83621a5b9d0979c6a728e7557157d1e595fbc055196080a4ca0f85_prof);

    }

    // line 36
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_2e00cce88540e3f2c7fa94a6ec22e92047233c66239086529aa570473c5b4c1b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2e00cce88540e3f2c7fa94a6ec22e92047233c66239086529aa570473c5b4c1b->enter($__internal_2e00cce88540e3f2c7fa94a6ec22e92047233c66239086529aa570473c5b4c1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_4bdd2cf0c72fabdd888b71ac6966c65d21faf58ca519cd2ba41147236d386e8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4bdd2cf0c72fabdd888b71ac6966c65d21faf58ca519cd2ba41147236d386e8d->enter($__internal_4bdd2cf0c72fabdd888b71ac6966c65d21faf58ca519cd2ba41147236d386e8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 37
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_4bdd2cf0c72fabdd888b71ac6966c65d21faf58ca519cd2ba41147236d386e8d->leave($__internal_4bdd2cf0c72fabdd888b71ac6966c65d21faf58ca519cd2ba41147236d386e8d_prof);

        
        $__internal_2e00cce88540e3f2c7fa94a6ec22e92047233c66239086529aa570473c5b4c1b->leave($__internal_2e00cce88540e3f2c7fa94a6ec22e92047233c66239086529aa570473c5b4c1b_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:request_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 37,  102 => 36,  89 => 33,  80 => 32,  70 => 36,  67 => 35,  65 => 32,  56 => 26,  34 => 7,  27 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

<div class=\"container-fluid\" id=\"register-container\">
    <div class=\"container\">
        <h2 class=\"text-center\">Unohtuiko salasana?</h2>
        <h4 class=\"text-center\">Ei hätää. Ole hyvä, ja kirjoita sähköpostiosoitteesi, niin lähetämme sinulle ohjeet salasanan vaihtamiseksi.</h4>
        <form action=\"{{ path('fos_user_resetting_send_email') }}\" method=\"POST\" class=\"fos_user_resetting_request\">
            <div class=\"row\">
                <div class=\"col-md-6 col-md-offset-3\">
                    <div class=\"input-group margin-bottom-sm\">
                        <span class=\"input-group-addon\"><i class=\"fa fa-envelope-o fa-fw\"></i></span>
                        <input class=\"form-control\" type=\"text\" id=\"username\" name=\"username\" placeholder=\"Sähköposti\" required=\"required\">
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12 text-center\"> 
                    <input type=\"submit\" class=\"btn btn-default login-button\" id=\"_submit\" name=\"_submit\" value=\"Alusta salasana\" />
                </div>
            </div>
        </form>
        
        <div class=\"row\">
            <div class=\"col-sm-12 text-center\"> 
                <p>Ei tunnusta?</p>
                <a href=\"{{ path('fos_user_registration_register') }}\" class=\"btn btn-default login-button\">Rekisteröidy</a>
            </div>
        </div>
    </div>
</div>

{% block stylesheets %}
    <link href=\"{{ asset('bundles/app/css/security.css') }}\" rel=\"stylesheet\" />
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
{% endblock %}
", "FOSUserBundle:Resetting:request_content.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/FOSUserBundle/views/Resetting/request_content.html.twig");
    }
}
