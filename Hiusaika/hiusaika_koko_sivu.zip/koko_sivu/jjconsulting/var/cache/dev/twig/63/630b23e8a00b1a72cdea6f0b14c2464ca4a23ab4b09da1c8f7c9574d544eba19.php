<?php

/* :Layout:searchBar.html.twig */
class __TwigTemplate_78d64059427f5ec85e1d3ceeec00c65b9a1f08b60caf233d8ce11b169e61fcf8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7e78b9028bdca2c564e701744f79700901270b20979fc90cbf44e75a5dff2f02 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7e78b9028bdca2c564e701744f79700901270b20979fc90cbf44e75a5dff2f02->enter($__internal_7e78b9028bdca2c564e701744f79700901270b20979fc90cbf44e75a5dff2f02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Layout:searchBar.html.twig"));

        $__internal_a46640eade566e3b16e7ec1181c639b68bae64470661086c734a34a8a7890ac0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a46640eade566e3b16e7ec1181c639b68bae64470661086c734a34a8a7890ac0->enter($__internal_a46640eade566e3b16e7ec1181c639b68bae64470661086c734a34a8a7890ac0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Layout:searchBar.html.twig"));

        // line 1
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("attr" => array("action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("searchCompany"))));
        // line 3
        echo "
    <div class=\"input-group\">
        ";
        // line 5
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "q", array()), 'widget');
        echo "
        ";
        // line 7
        echo "        <div class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-danger\">Hae</button>
        </div>
    </div>
";
        // line 11
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        
        $__internal_7e78b9028bdca2c564e701744f79700901270b20979fc90cbf44e75a5dff2f02->leave($__internal_7e78b9028bdca2c564e701744f79700901270b20979fc90cbf44e75a5dff2f02_prof);

        
        $__internal_a46640eade566e3b16e7ec1181c639b68bae64470661086c734a34a8a7890ac0->leave($__internal_a46640eade566e3b16e7ec1181c639b68bae64470661086c734a34a8a7890ac0_prof);

    }

    public function getTemplateName()
    {
        return ":Layout:searchBar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 11,  35 => 7,  31 => 5,  27 => 3,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{form_start(form, {
    'attr': {'action': path('searchCompany')}
}) }}
    <div class=\"input-group\">
        {{ form_widget(form.q) }}
        {#{{ form_widget(form.q, { 'value' : keyword }) }}#}
        <div class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-danger\">Hae</button>
        </div>
    </div>
{{form_end(form)}}", ":Layout:searchBar.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Layout/searchBar.html.twig");
    }
}
