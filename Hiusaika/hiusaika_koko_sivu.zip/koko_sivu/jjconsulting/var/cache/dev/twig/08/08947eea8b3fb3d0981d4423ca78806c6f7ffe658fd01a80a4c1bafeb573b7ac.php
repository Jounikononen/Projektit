<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_1df590e854ac6d101eba144a1d9fe03b507cab7ee778dcdb1281454bfa25d002 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_06fc58b0ce83c1d9a58f48cd84e41243577a8f16fe39f855673f0aca21ce111e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_06fc58b0ce83c1d9a58f48cd84e41243577a8f16fe39f855673f0aca21ce111e->enter($__internal_06fc58b0ce83c1d9a58f48cd84e41243577a8f16fe39f855673f0aca21ce111e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_ecd7aa5c08407402253f612b52584a41fa8e85aa84b6c8408e72e9c60e9d8848 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ecd7aa5c08407402253f612b52584a41fa8e85aa84b6c8408e72e9c60e9d8848->enter($__internal_ecd7aa5c08407402253f612b52584a41fa8e85aa84b6c8408e72e9c60e9d8848_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_06fc58b0ce83c1d9a58f48cd84e41243577a8f16fe39f855673f0aca21ce111e->leave($__internal_06fc58b0ce83c1d9a58f48cd84e41243577a8f16fe39f855673f0aca21ce111e_prof);

        
        $__internal_ecd7aa5c08407402253f612b52584a41fa8e85aa84b6c8408e72e9c60e9d8848->leave($__internal_ecd7aa5c08407402253f612b52584a41fa8e85aa84b6c8408e72e9c60e9d8848_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/collection_widget.html.php");
    }
}
