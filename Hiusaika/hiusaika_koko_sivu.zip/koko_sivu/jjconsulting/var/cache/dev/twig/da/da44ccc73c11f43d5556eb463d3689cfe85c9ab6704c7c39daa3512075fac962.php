<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_38824510a6c7ba4d4c8f43353acbed7f9fd03c0f2f015781d5d0bd71f8546eb7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b67e7c3e44d29bbe6cfac06115d1be693b9c55dd3e52bd60b2b9970c10bdf822 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b67e7c3e44d29bbe6cfac06115d1be693b9c55dd3e52bd60b2b9970c10bdf822->enter($__internal_b67e7c3e44d29bbe6cfac06115d1be693b9c55dd3e52bd60b2b9970c10bdf822_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_58fff295ee2f9d07fe95b6c552833c5da59d11cfefa3833f60b6023d29f2baf4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_58fff295ee2f9d07fe95b6c552833c5da59d11cfefa3833f60b6023d29f2baf4->enter($__internal_58fff295ee2f9d07fe95b6c552833c5da59d11cfefa3833f60b6023d29f2baf4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_b67e7c3e44d29bbe6cfac06115d1be693b9c55dd3e52bd60b2b9970c10bdf822->leave($__internal_b67e7c3e44d29bbe6cfac06115d1be693b9c55dd3e52bd60b2b9970c10bdf822_prof);

        
        $__internal_58fff295ee2f9d07fe95b6c552833c5da59d11cfefa3833f60b6023d29f2baf4->leave($__internal_58fff295ee2f9d07fe95b6c552833c5da59d11cfefa3833f60b6023d29f2baf4_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.rdf.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
