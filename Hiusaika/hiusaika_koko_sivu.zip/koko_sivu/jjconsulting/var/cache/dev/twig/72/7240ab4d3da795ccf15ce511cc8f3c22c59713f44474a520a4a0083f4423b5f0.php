<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_9cafa4d0c734af999042f6f8765600a6287e1a8fc0e7832e0695a068f8b82614 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c65eb7b1f92137e1a5d4913e44ff8e5512c9323b2b90c1128112a96f902085e8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c65eb7b1f92137e1a5d4913e44ff8e5512c9323b2b90c1128112a96f902085e8->enter($__internal_c65eb7b1f92137e1a5d4913e44ff8e5512c9323b2b90c1128112a96f902085e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_5a763b623e3c4712305557caad69f060d576667ce9efef02e9791149d586c081 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a763b623e3c4712305557caad69f060d576667ce9efef02e9791149d586c081->enter($__internal_5a763b623e3c4712305557caad69f060d576667ce9efef02e9791149d586c081_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_c65eb7b1f92137e1a5d4913e44ff8e5512c9323b2b90c1128112a96f902085e8->leave($__internal_c65eb7b1f92137e1a5d4913e44ff8e5512c9323b2b90c1128112a96f902085e8_prof);

        
        $__internal_5a763b623e3c4712305557caad69f060d576667ce9efef02e9791149d586c081->leave($__internal_5a763b623e3c4712305557caad69f060d576667ce9efef02e9791149d586c081_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_errors.html.php");
    }
}
