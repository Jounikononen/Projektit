<?php

/* base.html.twig */
class __TwigTemplate_37dcf2eaafd3b636d3cd4d407949385724509b4c11e934edab7592106fbef407 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5bad3207ecec728b74e69427af954d3b0bfb1aeabe0e6be123bc3609b27c84df = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5bad3207ecec728b74e69427af954d3b0bfb1aeabe0e6be123bc3609b27c84df->enter($__internal_5bad3207ecec728b74e69427af954d3b0bfb1aeabe0e6be123bc3609b27c84df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_e6d67fe8af1a18959f4ac9593f76be8863bd749ee9e7561f30b7fad95212d8a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e6d67fe8af1a18959f4ac9593f76be8863bd749ee9e7561f30b7fad95212d8a8->enter($__internal_e6d67fe8af1a18959f4ac9593f76be8863bd749ee9e7561f30b7fad95212d8a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\" />
    <title>J&J Consulting Ky - ";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    <link href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
    <link href=\"https://fonts.googleapis.com/css?family=Montserrat\" rel=\"stylesheet\" type=\"text/css\">
    <link href=\"https://fonts.googleapis.com/css?family=Lato\" rel=\"stylesheet\" type=\"text/css\">
    <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
    <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/main.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
    <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/toastr.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
    ";
        // line 13
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 14
        echo "
    <script src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/jquery-3.2.1.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/toastr.min.js"), "html", null, true);
        echo "\"></script>
    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
</head>
<body>
    <!-- Navigation -->
    <nav class=\"navbar navbar-default navbar-fixed-top\" >
        <div class=\"container\">
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#myNavbar\">
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>                        
                </button>
                <a class=\"navbar-brand\" href=\"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">Logo</a>
            </div>
            <div class=\"collapse navbar-collapse\" id=\"myNavbar\">
                <ul class=\"nav navbar-nav navbar-right\">
                    <li><a href=\"";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("searchCompany");
        echo "\">Yritykset</a></li>
                    <li><a href=\"";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("about");
        echo "\">Tietoa meistä</a></li>
                        ";
        // line 36
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 37
            echo "                            ";
            if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
                // line 38
                echo "                                <li><a href=\"";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("adminIndex");
                echo "\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> Hallintapaneeli</a></li>
                            ";
            } else {
                // line 40
                echo "                                <li><a href=\"";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("dashboard");
                echo "\"><i class=\"fa fa-user\" aria-hidden=\"true\"></i> Oma tili</a></li>
                            ";
            }
            // line 42
            echo "                            <li><a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Kirjaudu ulos</a></li>
                        ";
        }
        // line 44
        echo "                </ul>
            </div>
        </div>
    </nav>
    <div class=\"main-container\">
        ";
        // line 49
        $this->displayBlock('body', $context, $blocks);
        // line 50
        echo "    </div>

    <footer>
        <div class=\"text-center bg-grey\">
            <a href=\"#top\" title=\"To Top\">
                <span class=\"glyphicon glyphicon-chevron-up\"></span>
            </a>
            <p>
                Copyright &copy; J&J Consulting Ky - 2017<br/>
                ";
        // line 59
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 60
            echo "                    <a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Kirjaudu ulos</a>
                ";
        } else {
            // line 62
            echo "                   <a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
            echo "\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Kirjaudu sisään</a>
                ";
        }
        // line 63
        echo "    
            </p>
        </div>
    </footer>
            
    <script>
        \$(document).ready(function() {
            toastr.options = {
                \"closeButton\": true,
                \"debug\": false,
                \"newestOnTop\": false,
                \"progressBar\": true,
                \"positionClass\": \"toast-top-right\",
                \"preventDuplicates\": false,
                \"onclick\": null,
                \"showDuration\": \"300\",
                \"hideDuration\": \"1000\",
                \"timeOut\": \"5000\",
                \"extendedTimeOut\": \"1000\",
                \"showEasing\": \"swing\",
                \"hideEasing\": \"linear\",
                \"showMethod\": \"fadeIn\",
                \"hideMethod\": \"fadeOut\"
            };
            
            ";
        // line 88
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "flashes", array(0 => "success"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 89
            echo "                toastr.success('";
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "');
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 91
        echo "
            ";
        // line 92
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "flashes", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 93
            echo "                toastr.error('";
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "');
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 95
        echo "
            ";
        // line 96
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "flashes", array(0 => "info"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 97
            echo "                toastr.info('";
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "');
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 99
        echo "        });
    </script>
    ";
        // line 101
        $this->displayBlock('javascripts', $context, $blocks);
        // line 102
        echo "</body>
</html>
";
        
        $__internal_5bad3207ecec728b74e69427af954d3b0bfb1aeabe0e6be123bc3609b27c84df->leave($__internal_5bad3207ecec728b74e69427af954d3b0bfb1aeabe0e6be123bc3609b27c84df_prof);

        
        $__internal_e6d67fe8af1a18959f4ac9593f76be8863bd749ee9e7561f30b7fad95212d8a8->leave($__internal_e6d67fe8af1a18959f4ac9593f76be8863bd749ee9e7561f30b7fad95212d8a8_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_6fa02e8a8c8247c01c903f6e9543920e0b4055a0bf257e68af7d44b80385ff30 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6fa02e8a8c8247c01c903f6e9543920e0b4055a0bf257e68af7d44b80385ff30->enter($__internal_6fa02e8a8c8247c01c903f6e9543920e0b4055a0bf257e68af7d44b80385ff30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_d24fac777b44f7554f375c5b7631a66e4c074d86502ad11f081f93db7b3e69a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d24fac777b44f7554f375c5b7631a66e4c074d86502ad11f081f93db7b3e69a6->enter($__internal_d24fac777b44f7554f375c5b7631a66e4c074d86502ad11f081f93db7b3e69a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_d24fac777b44f7554f375c5b7631a66e4c074d86502ad11f081f93db7b3e69a6->leave($__internal_d24fac777b44f7554f375c5b7631a66e4c074d86502ad11f081f93db7b3e69a6_prof);

        
        $__internal_6fa02e8a8c8247c01c903f6e9543920e0b4055a0bf257e68af7d44b80385ff30->leave($__internal_6fa02e8a8c8247c01c903f6e9543920e0b4055a0bf257e68af7d44b80385ff30_prof);

    }

    // line 13
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_75acf16556bf2e3efb9950d52f4ccc8e71539efe35bcf09ff065e422b3b524c0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_75acf16556bf2e3efb9950d52f4ccc8e71539efe35bcf09ff065e422b3b524c0->enter($__internal_75acf16556bf2e3efb9950d52f4ccc8e71539efe35bcf09ff065e422b3b524c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_a7508d53179faabed9c5e1df17d557d9c7e9516227628515f60f27749d6dd945 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a7508d53179faabed9c5e1df17d557d9c7e9516227628515f60f27749d6dd945->enter($__internal_a7508d53179faabed9c5e1df17d557d9c7e9516227628515f60f27749d6dd945_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_a7508d53179faabed9c5e1df17d557d9c7e9516227628515f60f27749d6dd945->leave($__internal_a7508d53179faabed9c5e1df17d557d9c7e9516227628515f60f27749d6dd945_prof);

        
        $__internal_75acf16556bf2e3efb9950d52f4ccc8e71539efe35bcf09ff065e422b3b524c0->leave($__internal_75acf16556bf2e3efb9950d52f4ccc8e71539efe35bcf09ff065e422b3b524c0_prof);

    }

    // line 49
    public function block_body($context, array $blocks = array())
    {
        $__internal_6fcfdaf15a44d6322f68574d87dd453433c0a12ec8904a6d5e8cdb1622adc7e3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6fcfdaf15a44d6322f68574d87dd453433c0a12ec8904a6d5e8cdb1622adc7e3->enter($__internal_6fcfdaf15a44d6322f68574d87dd453433c0a12ec8904a6d5e8cdb1622adc7e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d08fc6c91faeb6a80c239176b27991ff6d4e76ebce0f3c3918e1c2fb0704819e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d08fc6c91faeb6a80c239176b27991ff6d4e76ebce0f3c3918e1c2fb0704819e->enter($__internal_d08fc6c91faeb6a80c239176b27991ff6d4e76ebce0f3c3918e1c2fb0704819e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_d08fc6c91faeb6a80c239176b27991ff6d4e76ebce0f3c3918e1c2fb0704819e->leave($__internal_d08fc6c91faeb6a80c239176b27991ff6d4e76ebce0f3c3918e1c2fb0704819e_prof);

        
        $__internal_6fcfdaf15a44d6322f68574d87dd453433c0a12ec8904a6d5e8cdb1622adc7e3->leave($__internal_6fcfdaf15a44d6322f68574d87dd453433c0a12ec8904a6d5e8cdb1622adc7e3_prof);

    }

    // line 101
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_356a305d0f9909c50c98c05ba57178ade32a19a57f40ac764328b0328b8b4887 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_356a305d0f9909c50c98c05ba57178ade32a19a57f40ac764328b0328b8b4887->enter($__internal_356a305d0f9909c50c98c05ba57178ade32a19a57f40ac764328b0328b8b4887_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_3196214b141488555972e5b3f65d0e49c43ef3906d32f3ca8caa5fa48d45d8ab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3196214b141488555972e5b3f65d0e49c43ef3906d32f3ca8caa5fa48d45d8ab->enter($__internal_3196214b141488555972e5b3f65d0e49c43ef3906d32f3ca8caa5fa48d45d8ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_3196214b141488555972e5b3f65d0e49c43ef3906d32f3ca8caa5fa48d45d8ab->leave($__internal_3196214b141488555972e5b3f65d0e49c43ef3906d32f3ca8caa5fa48d45d8ab_prof);

        
        $__internal_356a305d0f9909c50c98c05ba57178ade32a19a57f40ac764328b0328b8b4887->leave($__internal_356a305d0f9909c50c98c05ba57178ade32a19a57f40ac764328b0328b8b4887_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  303 => 101,  286 => 49,  269 => 13,  252 => 5,  240 => 102,  238 => 101,  234 => 99,  225 => 97,  221 => 96,  218 => 95,  209 => 93,  205 => 92,  202 => 91,  193 => 89,  189 => 88,  162 => 63,  156 => 62,  150 => 60,  148 => 59,  137 => 50,  135 => 49,  128 => 44,  122 => 42,  116 => 40,  110 => 38,  107 => 37,  105 => 36,  101 => 35,  97 => 34,  90 => 30,  75 => 18,  71 => 17,  67 => 16,  63 => 15,  60 => 14,  58 => 13,  54 => 12,  50 => 11,  46 => 10,  40 => 7,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\" />
    <title>J&J Consulting Ky - {% block title %}{% endblock %}</title>

    <link href=\"{{ asset('bundles/app/css/bootstrap.min.css') }}\" rel=\"stylesheet\" />
    <link href=\"https://fonts.googleapis.com/css?family=Montserrat\" rel=\"stylesheet\" type=\"text/css\">
    <link href=\"https://fonts.googleapis.com/css?family=Lato\" rel=\"stylesheet\" type=\"text/css\">
    <link href=\"{{ asset('bundles/app/css/font-awesome.min.css') }}\" rel=\"stylesheet\" />
    <link href=\"{{ asset('bundles/app/css/main.css') }}\" rel=\"stylesheet\" />
    <link href=\"{{ asset('bundles/app/css/toastr.min.css') }}\" rel=\"stylesheet\" />
    {% block stylesheets %}{% endblock %}

    <script src=\"{{ asset('bundles/app/js/jquery-3.2.1.min.js') }}\"></script>
    <script src=\"{{ asset('bundles/app/js/bootstrap.min.js') }}\"></script>
    <script src=\"{{ asset('bundles/app/js/toastr.min.js') }}\"></script>
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
</head>
<body>
    <!-- Navigation -->
    <nav class=\"navbar navbar-default navbar-fixed-top\" >
        <div class=\"container\">
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#myNavbar\">
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>                        
                </button>
                <a class=\"navbar-brand\" href=\"{{ path('homepage') }}\">Logo</a>
            </div>
            <div class=\"collapse navbar-collapse\" id=\"myNavbar\">
                <ul class=\"nav navbar-nav navbar-right\">
                    <li><a href=\"{{ path('searchCompany') }}\">Yritykset</a></li>
                    <li><a href=\"{{ path('about') }}\">Tietoa meistä</a></li>
                        {% if is_granted('IS_AUTHENTICATED_FULLY') %}
                            {% if is_granted('ROLE_ADMIN') %}
                                <li><a href=\"{{ path('adminIndex') }}\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> Hallintapaneeli</a></li>
                            {% else %}
                                <li><a href=\"{{ path('dashboard') }}\"><i class=\"fa fa-user\" aria-hidden=\"true\"></i> Oma tili</a></li>
                            {% endif %}
                            <li><a href=\"{{ path('fos_user_security_logout') }}\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Kirjaudu ulos</a></li>
                        {% endif %}
                </ul>
            </div>
        </div>
    </nav>
    <div class=\"main-container\">
        {% block body %}{% endblock %}
    </div>

    <footer>
        <div class=\"text-center bg-grey\">
            <a href=\"#top\" title=\"To Top\">
                <span class=\"glyphicon glyphicon-chevron-up\"></span>
            </a>
            <p>
                Copyright &copy; J&J Consulting Ky - 2017<br/>
                {% if is_granted('IS_AUTHENTICATED_FULLY') %}
                    <a href=\"{{ path('fos_user_security_logout') }}\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Kirjaudu ulos</a>
                {% else %}
                   <a href=\"{{ path('fos_user_security_login') }}\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Kirjaudu sisään</a>
                {% endif %}    
            </p>
        </div>
    </footer>
            
    <script>
        \$(document).ready(function() {
            toastr.options = {
                \"closeButton\": true,
                \"debug\": false,
                \"newestOnTop\": false,
                \"progressBar\": true,
                \"positionClass\": \"toast-top-right\",
                \"preventDuplicates\": false,
                \"onclick\": null,
                \"showDuration\": \"300\",
                \"hideDuration\": \"1000\",
                \"timeOut\": \"5000\",
                \"extendedTimeOut\": \"1000\",
                \"showEasing\": \"swing\",
                \"hideEasing\": \"linear\",
                \"showMethod\": \"fadeIn\",
                \"hideMethod\": \"fadeOut\"
            };
            
            {% for flashMessage in app.flashes('success') %}
                toastr.success('{{ flashMessage }}');
            {% endfor %}

            {% for flashMessage in app.flashes('error') %}
                toastr.error('{{ flashMessage }}');
            {% endfor %}

            {% for flashMessage in app.flashes('info') %}
                toastr.info('{{ flashMessage }}');
            {% endfor %}
        });
    </script>
    {% block javascripts %}{% endblock %}
</body>
</html>
", "base.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/base.html.twig");
    }
}
