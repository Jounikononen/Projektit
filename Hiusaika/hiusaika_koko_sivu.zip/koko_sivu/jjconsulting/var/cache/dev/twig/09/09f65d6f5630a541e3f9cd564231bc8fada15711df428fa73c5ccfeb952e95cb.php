<?php

/* :Emails:registrationConfirmation.html.twig */
class __TwigTemplate_07b6fc453cb4240795348bb60d71b7ae9950b426c426cc701fea9366aaa7920b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_562b2806d132f3ae63686561b91772cc39ac94ce286179e7eaa6be70c09fee2b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_562b2806d132f3ae63686561b91772cc39ac94ce286179e7eaa6be70c09fee2b->enter($__internal_562b2806d132f3ae63686561b91772cc39ac94ce286179e7eaa6be70c09fee2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Emails:registrationConfirmation.html.twig"));

        $__internal_a8ee358e094ef6398c0f2d108a328855fb8615b9589d6725e1ad06d15bcb7c6c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8ee358e094ef6398c0f2d108a328855fb8615b9589d6725e1ad06d15bcb7c6c->enter($__internal_a8ee358e094ef6398c0f2d108a328855fb8615b9589d6725e1ad06d15bcb7c6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Emails:registrationConfirmation.html.twig"));

        // line 1
        echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
    <title>Kiitos rekisteröitymisestä</title>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"/>
</head>
<body>
    <p>Kiitos rekisteröitymisestästi.</p>
    <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque non orci eros. Nunc et augue ut lectus ultrices ullamcorper. Quisque suscipit risus nisi, vel ultrices lectus facilisis id. Aenean rhoncus justo a magna auctor suscipit. Vestibulum a metus egestas dolor scelerisque sodales. Praesent ligula lacus, euismod tincidunt elit eu, ullamcorper fringilla ipsum. Etiam malesuada venenatis molestie. Suspendisse turpis velit, euismod malesuada tempor suscipit, malesuada id tortor. Proin justo nisl, rutrum ac semper vitae, tincidunt auctor nisi. Nulla ac interdum lorem. Ut gravida sodales elit in commodo. Suspendisse lobortis elit non tortor venenatis, suscipit congue augue sodales. Proin mollis, est in interdum facilisis, libero erat pretium mauris, fringilla lacinia mauris nunc et nibh. Sed in diam at est pretium lobortis. Nam rutrum elit ut imperdiet scelerisque.
    </p>
    <p>
        Aliquam viverra libero et metus euismod, eget feugiat justo tempus. Donec aliquet tellus ac lectus posuere luctus. Donec congue rhoncus dictum. Sed sit amet blandit lorem. Praesent sit amet diam nec tellus pulvinar maximus. Aliquam sed varius nunc. Aliquam ullamcorper dui lorem, eget iaculis diam bibendum eu. Mauris interdum bibendum turpis quis tempus. Suspendisse at dolor dui. Nullam consequat imperdiet urna at vulputate.
    </p>
</body>
</html>";
        
        $__internal_562b2806d132f3ae63686561b91772cc39ac94ce286179e7eaa6be70c09fee2b->leave($__internal_562b2806d132f3ae63686561b91772cc39ac94ce286179e7eaa6be70c09fee2b_prof);

        
        $__internal_a8ee358e094ef6398c0f2d108a328855fb8615b9589d6725e1ad06d15bcb7c6c->leave($__internal_a8ee358e094ef6398c0f2d108a328855fb8615b9589d6725e1ad06d15bcb7c6c_prof);

    }

    public function getTemplateName()
    {
        return ":Emails:registrationConfirmation.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
    <title>Kiitos rekisteröitymisestä</title>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"/>
</head>
<body>
    <p>Kiitos rekisteröitymisestästi.</p>
    <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque non orci eros. Nunc et augue ut lectus ultrices ullamcorper. Quisque suscipit risus nisi, vel ultrices lectus facilisis id. Aenean rhoncus justo a magna auctor suscipit. Vestibulum a metus egestas dolor scelerisque sodales. Praesent ligula lacus, euismod tincidunt elit eu, ullamcorper fringilla ipsum. Etiam malesuada venenatis molestie. Suspendisse turpis velit, euismod malesuada tempor suscipit, malesuada id tortor. Proin justo nisl, rutrum ac semper vitae, tincidunt auctor nisi. Nulla ac interdum lorem. Ut gravida sodales elit in commodo. Suspendisse lobortis elit non tortor venenatis, suscipit congue augue sodales. Proin mollis, est in interdum facilisis, libero erat pretium mauris, fringilla lacinia mauris nunc et nibh. Sed in diam at est pretium lobortis. Nam rutrum elit ut imperdiet scelerisque.
    </p>
    <p>
        Aliquam viverra libero et metus euismod, eget feugiat justo tempus. Donec aliquet tellus ac lectus posuere luctus. Donec congue rhoncus dictum. Sed sit amet blandit lorem. Praesent sit amet diam nec tellus pulvinar maximus. Aliquam sed varius nunc. Aliquam ullamcorper dui lorem, eget iaculis diam bibendum eu. Mauris interdum bibendum turpis quis tempus. Suspendisse at dolor dui. Nullam consequat imperdiet urna at vulputate.
    </p>
</body>
</html>", ":Emails:registrationConfirmation.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Emails/registrationConfirmation.html.twig");
    }
}
