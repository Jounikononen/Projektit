<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_b00d2ff28be4ef16cbd76e1fb7b5493776d6db8d0ad1fc95299015f18ecff949 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_076d83c9e78949c292e47a3c8a1cab813121a5d8c2227e4d444fbbb8f61f244c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_076d83c9e78949c292e47a3c8a1cab813121a5d8c2227e4d444fbbb8f61f244c->enter($__internal_076d83c9e78949c292e47a3c8a1cab813121a5d8c2227e4d444fbbb8f61f244c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        $__internal_436f1cd9e6b2e9d24f89e8b8ef53d6a39788f70e214f212dc49d1a6a2c06e252 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_436f1cd9e6b2e9d24f89e8b8ef53d6a39788f70e214f212dc49d1a6a2c06e252->enter($__internal_436f1cd9e6b2e9d24f89e8b8ef53d6a39788f70e214f212dc49d1a6a2c06e252_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_076d83c9e78949c292e47a3c8a1cab813121a5d8c2227e4d444fbbb8f61f244c->leave($__internal_076d83c9e78949c292e47a3c8a1cab813121a5d8c2227e4d444fbbb8f61f244c_prof);

        
        $__internal_436f1cd9e6b2e9d24f89e8b8ef53d6a39788f70e214f212dc49d1a6a2c06e252->leave($__internal_436f1cd9e6b2e9d24f89e8b8ef53d6a39788f70e214f212dc49d1a6a2c06e252_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/checkbox_widget.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/checkbox_widget.html.php");
    }
}
