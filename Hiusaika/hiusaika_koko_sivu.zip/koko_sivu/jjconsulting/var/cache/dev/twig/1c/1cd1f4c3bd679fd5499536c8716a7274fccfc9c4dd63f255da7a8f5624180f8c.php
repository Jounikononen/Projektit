<?php

/* @Framework/Form/choice_attributes.html.php */
class __TwigTemplate_5b80cd7b67c46cd8a9ce3884c92f77103e32098a4fedd384341a8906d892f1d8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a334b2a444cdab7f3facdb0e769ec40a35f79c76d4d842d3de6a5fed8fa3c78d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a334b2a444cdab7f3facdb0e769ec40a35f79c76d4d842d3de6a5fed8fa3c78d->enter($__internal_a334b2a444cdab7f3facdb0e769ec40a35f79c76d4d842d3de6a5fed8fa3c78d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        $__internal_426f7004f2cb8bbd9afe83a8e15257533dfb6562c36862cf501328a1d12650ab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_426f7004f2cb8bbd9afe83a8e15257533dfb6562c36862cf501328a1d12650ab->enter($__internal_426f7004f2cb8bbd9afe83a8e15257533dfb6562c36862cf501328a1d12650ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        // line 1
        echo "<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_a334b2a444cdab7f3facdb0e769ec40a35f79c76d4d842d3de6a5fed8fa3c78d->leave($__internal_a334b2a444cdab7f3facdb0e769ec40a35f79c76d4d842d3de6a5fed8fa3c78d_prof);

        
        $__internal_426f7004f2cb8bbd9afe83a8e15257533dfb6562c36862cf501328a1d12650ab->leave($__internal_426f7004f2cb8bbd9afe83a8e15257533dfb6562c36862cf501328a1d12650ab_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/choice_attributes.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_attributes.html.php");
    }
}
