<?php

/* WebProfilerBundle:Collector:exception.css.twig */
class __TwigTemplate_29b4ad30621c03f4437be08842f6ca872dbddcb922a4d710284e528370cb62eb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c937c57ffdf8905613d29475ff49365d5b5541cc4b33b59fdb352aa891f06d5f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c937c57ffdf8905613d29475ff49365d5b5541cc4b33b59fdb352aa891f06d5f->enter($__internal_c937c57ffdf8905613d29475ff49365d5b5541cc4b33b59fdb352aa891f06d5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.css.twig"));

        $__internal_cae0a9f2cef602f129088a22b5de1142aa19c7e84456bbc06c071cb9661ee059 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cae0a9f2cef602f129088a22b5de1142aa19c7e84456bbc06c071cb9661ee059->enter($__internal_cae0a9f2cef602f129088a22b5de1142aa19c7e84456bbc06c071cb9661ee059_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.css.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}
.exception-summary.exception-without-message {
    display: none;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper .container {
    min-height: auto;
}
";
        
        $__internal_c937c57ffdf8905613d29475ff49365d5b5541cc4b33b59fdb352aa891f06d5f->leave($__internal_c937c57ffdf8905613d29475ff49365d5b5541cc4b33b59fdb352aa891f06d5f_prof);

        
        $__internal_cae0a9f2cef602f129088a22b5de1142aa19c7e84456bbc06c071cb9661ee059->leave($__internal_cae0a9f2cef602f129088a22b5de1142aa19c7e84456bbc06c071cb9661ee059_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/exception.css.twig') }}

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}
.exception-summary.exception-without-message {
    display: none;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper .container {
    min-height: auto;
}
", "WebProfilerBundle:Collector:exception.css.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.css.twig");
    }
}
