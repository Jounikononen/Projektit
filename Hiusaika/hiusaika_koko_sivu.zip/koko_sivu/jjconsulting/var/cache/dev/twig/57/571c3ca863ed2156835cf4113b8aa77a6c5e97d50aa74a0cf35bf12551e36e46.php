<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_6823b672ec2ab86f532e01b156eb29e9d680ca76c1130596b690ae366b98add0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e5e12c4b41bfde4638e0fc05421278db208b87423a42487ac318c79433c238f7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e5e12c4b41bfde4638e0fc05421278db208b87423a42487ac318c79433c238f7->enter($__internal_e5e12c4b41bfde4638e0fc05421278db208b87423a42487ac318c79433c238f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        $__internal_bf1241a79db2fe6e4acb047d8edc107a1a7da1e87b2ee5015494273435452c0d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf1241a79db2fe6e4acb047d8edc107a1a7da1e87b2ee5015494273435452c0d->enter($__internal_bf1241a79db2fe6e4acb047d8edc107a1a7da1e87b2ee5015494273435452c0d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_e5e12c4b41bfde4638e0fc05421278db208b87423a42487ac318c79433c238f7->leave($__internal_e5e12c4b41bfde4638e0fc05421278db208b87423a42487ac318c79433c238f7_prof);

        
        $__internal_bf1241a79db2fe6e4acb047d8edc107a1a7da1e87b2ee5015494273435452c0d->leave($__internal_bf1241a79db2fe6e4acb047d8edc107a1a7da1e87b2ee5015494273435452c0d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
", "@Framework/Form/url_widget.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/url_widget.html.php");
    }
}
