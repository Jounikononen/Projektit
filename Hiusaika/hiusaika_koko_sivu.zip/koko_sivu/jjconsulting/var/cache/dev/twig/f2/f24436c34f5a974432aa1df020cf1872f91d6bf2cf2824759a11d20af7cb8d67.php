<?php

/* :Emails:passwordReset.html.twig */
class __TwigTemplate_328681a6ac3080837311af240ad6b130603504d08045af5ab5f3c29f5f03838c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f232e47ffffbcc96c139eed808596a78c57fea49107c34070203bc6ceca3e942 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f232e47ffffbcc96c139eed808596a78c57fea49107c34070203bc6ceca3e942->enter($__internal_f232e47ffffbcc96c139eed808596a78c57fea49107c34070203bc6ceca3e942_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Emails:passwordReset.html.twig"));

        $__internal_124d1729355138b815971c32f6b50f23cb189d65462ca8dedcb499bb65b284a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_124d1729355138b815971c32f6b50f23cb189d65462ca8dedcb499bb65b284a6->enter($__internal_124d1729355138b815971c32f6b50f23cb189d65462ca8dedcb499bb65b284a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Emails:passwordReset.html.twig"));

        // line 1
        $this->displayBlock('subject', $context, $blocks);
        // line 2
        echo "
";
        // line 3
        $this->displayBlock('body_text', $context, $blocks);
        // line 18
        echo "
";
        // line 19
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_f232e47ffffbcc96c139eed808596a78c57fea49107c34070203bc6ceca3e942->leave($__internal_f232e47ffffbcc96c139eed808596a78c57fea49107c34070203bc6ceca3e942_prof);

        
        $__internal_124d1729355138b815971c32f6b50f23cb189d65462ca8dedcb499bb65b284a6->leave($__internal_124d1729355138b815971c32f6b50f23cb189d65462ca8dedcb499bb65b284a6_prof);

    }

    // line 1
    public function block_subject($context, array $blocks = array())
    {
        $__internal_3ec48171ee0a3e94768f3df48f5648109bffc879de91895555ecc2c6c236d947 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3ec48171ee0a3e94768f3df48f5648109bffc879de91895555ecc2c6c236d947->enter($__internal_3ec48171ee0a3e94768f3df48f5648109bffc879de91895555ecc2c6c236d947_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        $__internal_7fd92d8cd1e6a3f34031650bf3a8ac4fa9e43b4e85e6f8b1305aaea2fce58fa8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7fd92d8cd1e6a3f34031650bf3a8ac4fa9e43b4e85e6f8b1305aaea2fce58fa8->enter($__internal_7fd92d8cd1e6a3f34031650bf3a8ac4fa9e43b4e85e6f8b1305aaea2fce58fa8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        echo "Salasanan palauttaminen";
        
        $__internal_7fd92d8cd1e6a3f34031650bf3a8ac4fa9e43b4e85e6f8b1305aaea2fce58fa8->leave($__internal_7fd92d8cd1e6a3f34031650bf3a8ac4fa9e43b4e85e6f8b1305aaea2fce58fa8_prof);

        
        $__internal_3ec48171ee0a3e94768f3df48f5648109bffc879de91895555ecc2c6c236d947->leave($__internal_3ec48171ee0a3e94768f3df48f5648109bffc879de91895555ecc2c6c236d947_prof);

    }

    // line 3
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_ea1d2cb68cd429a103261d91ab97c58ebf293c63747c73ad0dfe992e4d52c5ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ea1d2cb68cd429a103261d91ab97c58ebf293c63747c73ad0dfe992e4d52c5ff->enter($__internal_ea1d2cb68cd429a103261d91ab97c58ebf293c63747c73ad0dfe992e4d52c5ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        $__internal_c3344dbee2731ea752c0e4d05da334a75dbd26b6b9427b011c2d61e3fc052b31 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c3344dbee2731ea752c0e4d05da334a75dbd26b6b9427b011c2d61e3fc052b31->enter($__internal_c3344dbee2731ea752c0e4d05da334a75dbd26b6b9427b011c2d61e3fc052b31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 5
        echo "Tervehdys ";
        echo $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "username", array());
        echo " !

<p>
    Voit palauttaa salasanan alla olevassa osoitteessa:<br/>
    ";
        // line 9
        echo ($context["confirmationUrl"] ?? $this->getContext($context, "confirmationUrl"));
        echo "
</p>



Terveisin,
JJ Consulting Ky
";
        
        $__internal_c3344dbee2731ea752c0e4d05da334a75dbd26b6b9427b011c2d61e3fc052b31->leave($__internal_c3344dbee2731ea752c0e4d05da334a75dbd26b6b9427b011c2d61e3fc052b31_prof);

        
        $__internal_ea1d2cb68cd429a103261d91ab97c58ebf293c63747c73ad0dfe992e4d52c5ff->leave($__internal_ea1d2cb68cd429a103261d91ab97c58ebf293c63747c73ad0dfe992e4d52c5ff_prof);

    }

    // line 19
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_24d25b91a7314b1fdf7b16defa3a1e2cc7e29e3f76ef6fba39b1e391374729f8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_24d25b91a7314b1fdf7b16defa3a1e2cc7e29e3f76ef6fba39b1e391374729f8->enter($__internal_24d25b91a7314b1fdf7b16defa3a1e2cc7e29e3f76ef6fba39b1e391374729f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        $__internal_5e501c908707148aa0073330e217de09d85b39ec7783146190863dd9832d52b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e501c908707148aa0073330e217de09d85b39ec7783146190863dd9832d52b0->enter($__internal_5e501c908707148aa0073330e217de09d85b39ec7783146190863dd9832d52b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_5e501c908707148aa0073330e217de09d85b39ec7783146190863dd9832d52b0->leave($__internal_5e501c908707148aa0073330e217de09d85b39ec7783146190863dd9832d52b0_prof);

        
        $__internal_24d25b91a7314b1fdf7b16defa3a1e2cc7e29e3f76ef6fba39b1e391374729f8->leave($__internal_24d25b91a7314b1fdf7b16defa3a1e2cc7e29e3f76ef6fba39b1e391374729f8_prof);

    }

    public function getTemplateName()
    {
        return ":Emails:passwordReset.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  101 => 19,  83 => 9,  75 => 5,  66 => 3,  48 => 1,  38 => 19,  35 => 18,  33 => 3,  30 => 2,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block subject %}Salasanan palauttaminen{% endblock %}

{% block body_text %}
{% autoescape false %}
Tervehdys {{ user.username }} !

<p>
    Voit palauttaa salasanan alla olevassa osoitteessa:<br/>
    {{ confirmationUrl }}
</p>



Terveisin,
JJ Consulting Ky
{% endautoescape %}
{% endblock %}

{% block body_html %}
{#
    You can of course render the html directly here.
    Including a template as done here allows keeping things DRY by using
    the template inheritance in it
#}
{% endblock %}", ":Emails:passwordReset.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Emails/passwordReset.html.twig");
    }
}
