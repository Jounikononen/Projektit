<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_01a4686878f247b5bca59e9c299eca12235a2894eac86e87413313aa931df973 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5e9468ee95cbeecd2cbac8cc2d848feca1ab658625190a50c694bdd01864d810 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5e9468ee95cbeecd2cbac8cc2d848feca1ab658625190a50c694bdd01864d810->enter($__internal_5e9468ee95cbeecd2cbac8cc2d848feca1ab658625190a50c694bdd01864d810_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_7b7ee33db1b66b03d885d769d24f4169ba8b2ea7fdb1f88750ec799ac5c5f6da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7b7ee33db1b66b03d885d769d24f4169ba8b2ea7fdb1f88750ec799ac5c5f6da->enter($__internal_7b7ee33db1b66b03d885d769d24f4169ba8b2ea7fdb1f88750ec799ac5c5f6da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_5e9468ee95cbeecd2cbac8cc2d848feca1ab658625190a50c694bdd01864d810->leave($__internal_5e9468ee95cbeecd2cbac8cc2d848feca1ab658625190a50c694bdd01864d810_prof);

        
        $__internal_7b7ee33db1b66b03d885d769d24f4169ba8b2ea7fdb1f88750ec799ac5c5f6da->leave($__internal_7b7ee33db1b66b03d885d769d24f4169ba8b2ea7fdb1f88750ec799ac5c5f6da_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/reset_widget.html.php");
    }
}
