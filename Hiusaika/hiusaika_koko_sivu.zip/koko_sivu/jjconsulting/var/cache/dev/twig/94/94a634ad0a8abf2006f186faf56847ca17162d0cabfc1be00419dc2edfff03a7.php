<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_55c14e6ed156bf6479ff23fc3d27d79283662b9d75fcd340b79497322205206f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2dcec02bc39957c37f83e3dcf17539cfc6970c3496f54a30832597db062fb869 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2dcec02bc39957c37f83e3dcf17539cfc6970c3496f54a30832597db062fb869->enter($__internal_2dcec02bc39957c37f83e3dcf17539cfc6970c3496f54a30832597db062fb869_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_33824bace0911e5f1c6828fe6ffcd2424fcdeea529baea44dae39a9ca85baaa8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_33824bace0911e5f1c6828fe6ffcd2424fcdeea529baea44dae39a9ca85baaa8->enter($__internal_33824bace0911e5f1c6828fe6ffcd2424fcdeea529baea44dae39a9ca85baaa8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2dcec02bc39957c37f83e3dcf17539cfc6970c3496f54a30832597db062fb869->leave($__internal_2dcec02bc39957c37f83e3dcf17539cfc6970c3496f54a30832597db062fb869_prof);

        
        $__internal_33824bace0911e5f1c6828fe6ffcd2424fcdeea529baea44dae39a9ca85baaa8->leave($__internal_33824bace0911e5f1c6828fe6ffcd2424fcdeea529baea44dae39a9ca85baaa8_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_72dccd786ff31ea6788f11cefd1d8355b23f9f7c249eb6c93c44518e5cc6446f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_72dccd786ff31ea6788f11cefd1d8355b23f9f7c249eb6c93c44518e5cc6446f->enter($__internal_72dccd786ff31ea6788f11cefd1d8355b23f9f7c249eb6c93c44518e5cc6446f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_97142caad19c47e5cdfe8929e4661802a16757ab0f2f3f06a0d2cdc825224730 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_97142caad19c47e5cdfe8929e4661802a16757ab0f2f3f06a0d2cdc825224730->enter($__internal_97142caad19c47e5cdfe8929e4661802a16757ab0f2f3f06a0d2cdc825224730_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_97142caad19c47e5cdfe8929e4661802a16757ab0f2f3f06a0d2cdc825224730->leave($__internal_97142caad19c47e5cdfe8929e4661802a16757ab0f2f3f06a0d2cdc825224730_prof);

        
        $__internal_72dccd786ff31ea6788f11cefd1d8355b23f9f7c249eb6c93c44518e5cc6446f->leave($__internal_72dccd786ff31ea6788f11cefd1d8355b23f9f7c249eb6c93c44518e5cc6446f_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_611d448db0231960682b8c5a87a96abd2fd2c0d28a359b699f9f14ca7c90c12e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_611d448db0231960682b8c5a87a96abd2fd2c0d28a359b699f9f14ca7c90c12e->enter($__internal_611d448db0231960682b8c5a87a96abd2fd2c0d28a359b699f9f14ca7c90c12e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_1a1171259eb44f689d757313a00c3b2c1ab83d41d7eb0efafbc7d829469d27f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a1171259eb44f689d757313a00c3b2c1ab83d41d7eb0efafbc7d829469d27f1->enter($__internal_1a1171259eb44f689d757313a00c3b2c1ab83d41d7eb0efafbc7d829469d27f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_1a1171259eb44f689d757313a00c3b2c1ab83d41d7eb0efafbc7d829469d27f1->leave($__internal_1a1171259eb44f689d757313a00c3b2c1ab83d41d7eb0efafbc7d829469d27f1_prof);

        
        $__internal_611d448db0231960682b8c5a87a96abd2fd2c0d28a359b699f9f14ca7c90c12e->leave($__internal_611d448db0231960682b8c5a87a96abd2fd2c0d28a359b699f9f14ca7c90c12e_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_ffad751d2e97a3ddf1d05ebdbd32430a3f430bdc63aaf8b442a165ff18a5dddc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ffad751d2e97a3ddf1d05ebdbd32430a3f430bdc63aaf8b442a165ff18a5dddc->enter($__internal_ffad751d2e97a3ddf1d05ebdbd32430a3f430bdc63aaf8b442a165ff18a5dddc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_81fc0e0241381c6eaac7382761e662e254c94e847c2b53d16286cc5177db4b8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81fc0e0241381c6eaac7382761e662e254c94e847c2b53d16286cc5177db4b8d->enter($__internal_81fc0e0241381c6eaac7382761e662e254c94e847c2b53d16286cc5177db4b8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_81fc0e0241381c6eaac7382761e662e254c94e847c2b53d16286cc5177db4b8d->leave($__internal_81fc0e0241381c6eaac7382761e662e254c94e847c2b53d16286cc5177db4b8d_prof);

        
        $__internal_ffad751d2e97a3ddf1d05ebdbd32430a3f430bdc63aaf8b442a165ff18a5dddc->leave($__internal_ffad751d2e97a3ddf1d05ebdbd32430a3f430bdc63aaf8b442a165ff18a5dddc_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
