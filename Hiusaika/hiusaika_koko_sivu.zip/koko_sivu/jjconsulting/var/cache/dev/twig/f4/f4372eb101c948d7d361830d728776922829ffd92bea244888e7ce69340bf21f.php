<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_4f7421180dab52fc78eaac024727fa94fedb27206d34fe8a686651e916b8dc67 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_88913c8183aec3e3967e6077d7eb7ec96038c5db543de0c9289442c13ad33b4e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_88913c8183aec3e3967e6077d7eb7ec96038c5db543de0c9289442c13ad33b4e->enter($__internal_88913c8183aec3e3967e6077d7eb7ec96038c5db543de0c9289442c13ad33b4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        $__internal_90f0d0adcb61cfe1a005e9525aa38578dada5e989ff330c4a8b3559d24a22018 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90f0d0adcb61cfe1a005e9525aa38578dada5e989ff330c4a8b3559d24a22018->enter($__internal_90f0d0adcb61cfe1a005e9525aa38578dada5e989ff330c4a8b3559d24a22018_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_88913c8183aec3e3967e6077d7eb7ec96038c5db543de0c9289442c13ad33b4e->leave($__internal_88913c8183aec3e3967e6077d7eb7ec96038c5db543de0c9289442c13ad33b4e_prof);

        
        $__internal_90f0d0adcb61cfe1a005e9525aa38578dada5e989ff330c4a8b3559d24a22018->leave($__internal_90f0d0adcb61cfe1a005e9525aa38578dada5e989ff330c4a8b3559d24a22018_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
", "@Framework/Form/choice_widget.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_widget.html.php");
    }
}
