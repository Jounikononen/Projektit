<?php

/* FOSUserBundle:Registration:register_content.html.twig */
class __TwigTemplate_9df361c2885f676980d4c131b70ea01208ad12811fa964079a56d9d280927388 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a2fa593e4e9fc4f661f68cff513d5cfc8b6bc5e4da21eb2cdc5316bd1905dc04 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a2fa593e4e9fc4f661f68cff513d5cfc8b6bc5e4da21eb2cdc5316bd1905dc04->enter($__internal_a2fa593e4e9fc4f661f68cff513d5cfc8b6bc5e4da21eb2cdc5316bd1905dc04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register_content.html.twig"));

        $__internal_f860c23df6d46539955c73c1c0ce402e5e29f43f314988db9eb55df7b0e2b02d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f860c23df6d46539955c73c1c0ce402e5e29f43f314988db9eb55df7b0e2b02d->enter($__internal_f860c23df6d46539955c73c1c0ce402e5e29f43f314988db9eb55df7b0e2b02d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register_content.html.twig"));

        // line 2
        echo "
<div class=\"container-fluid bg-grey\" id=\"register-container\">
    <div class=\"container\">
        <h2 class=\"text-center\">Rekisteröityminen</h2>
        <h4 class=\"text-center\">Rekisteröityminen ei maksa sinulle mitään. Voit syöttää yrityksesi tiedot rekisteröitymisen jälkeen.</h4>
        ";
        // line 7
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("method" => "post", "action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_registration_register"), "attr" => array("class" => "fos_user_registration_register")));
        echo "
        <div class=\"row\">
            <div class=\"col-md-6 col-md-offset-3\">
                <div class=\"form-group\">
                    ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "company", array()), "name", array()), 'label', array("label" => "Yrityksen nimi"));
        echo "
                    ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "company", array()), "name", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                    ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "company", array()), "name", array()), 'errors');
        echo "
                </div>
                <div class=\"form-group\">
                    ";
        // line 16
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "company", array()), "vatId", array()), 'label', array("label" => "Y-tunnus"));
        echo "
                    ";
        // line 17
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "company", array()), "vatId", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                    ";
        // line 18
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "company", array()), "vatId", array()), 'errors');
        echo "
                </div>
                <div class=\"form-group\">
                    ";
        // line 21
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "email", array()), 'label', array("label" => "Sähköposti"));
        echo "
                    ";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "email", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                    ";
        // line 23
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "email", array()), 'errors');
        echo "
                </div>
                <div class=\"form-group\">
                    ";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "first", array()), 'label', array("label" => "Salasana"));
        echo "
                    ";
        // line 27
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "first", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                    ";
        // line 28
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "first", array()), 'errors');
        echo "
                </div>
                <div class=\"form-group\">
                    ";
        // line 31
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "second", array()), 'label', array("label" => "Salasana uudelleen"));
        echo "
                    ";
        // line 32
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "second", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                    ";
        // line 33
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "second", array()), 'errors');
        echo "
                </div>
            </div>
        </div>

        <div class=\"row\">
            <div class=\"col-sm-12 text-center\"> 
                <input type=\"submit\" value=\"Rekisteröidy\" class=\"btn btn-default login-button\" />
            </div>
        </div>
        ";
        // line 43
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
        
        <div class=\"row\">
            <div class=\"col-sm-12 text-center\"> 
                <p>Oletko jo rekisteröitynyt?</p>
                <a href=\"";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
        echo "\" class=\"btn btn-default login-button\">Kirjaudu sisään</a>
            </div>
        </div>
    </div>

</div>

";
        // line 55
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 58
        echo "
";
        // line 59
        $this->displayBlock('javascripts', $context, $blocks);
        
        $__internal_a2fa593e4e9fc4f661f68cff513d5cfc8b6bc5e4da21eb2cdc5316bd1905dc04->leave($__internal_a2fa593e4e9fc4f661f68cff513d5cfc8b6bc5e4da21eb2cdc5316bd1905dc04_prof);

        
        $__internal_f860c23df6d46539955c73c1c0ce402e5e29f43f314988db9eb55df7b0e2b02d->leave($__internal_f860c23df6d46539955c73c1c0ce402e5e29f43f314988db9eb55df7b0e2b02d_prof);

    }

    // line 55
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_3d9deb145882dcbd82c67728c17bbf12a217c72f545527d42ff9e09e3df70895 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3d9deb145882dcbd82c67728c17bbf12a217c72f545527d42ff9e09e3df70895->enter($__internal_3d9deb145882dcbd82c67728c17bbf12a217c72f545527d42ff9e09e3df70895_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_ef754177ff4db5646ee93a8a4675f8ab9b954ed3ffe2306d7ac86e7baab430e9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef754177ff4db5646ee93a8a4675f8ab9b954ed3ffe2306d7ac86e7baab430e9->enter($__internal_ef754177ff4db5646ee93a8a4675f8ab9b954ed3ffe2306d7ac86e7baab430e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 56
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/security.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
";
        
        $__internal_ef754177ff4db5646ee93a8a4675f8ab9b954ed3ffe2306d7ac86e7baab430e9->leave($__internal_ef754177ff4db5646ee93a8a4675f8ab9b954ed3ffe2306d7ac86e7baab430e9_prof);

        
        $__internal_3d9deb145882dcbd82c67728c17bbf12a217c72f545527d42ff9e09e3df70895->leave($__internal_3d9deb145882dcbd82c67728c17bbf12a217c72f545527d42ff9e09e3df70895_prof);

    }

    // line 59
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_afe83b3fb1bbdf513c5b31f6bd5eb12ca29d64440c86a19f5a3bc529fd0e1a06 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_afe83b3fb1bbdf513c5b31f6bd5eb12ca29d64440c86a19f5a3bc529fd0e1a06->enter($__internal_afe83b3fb1bbdf513c5b31f6bd5eb12ca29d64440c86a19f5a3bc529fd0e1a06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_9e856eb83fa772983b3d592c8182d912cfe75ef92fd365b6581181abb1d470b5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e856eb83fa772983b3d592c8182d912cfe75ef92fd365b6581181abb1d470b5->enter($__internal_9e856eb83fa772983b3d592c8182d912cfe75ef92fd365b6581181abb1d470b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 60
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_9e856eb83fa772983b3d592c8182d912cfe75ef92fd365b6581181abb1d470b5->leave($__internal_9e856eb83fa772983b3d592c8182d912cfe75ef92fd365b6581181abb1d470b5_prof);

        
        $__internal_afe83b3fb1bbdf513c5b31f6bd5eb12ca29d64440c86a19f5a3bc529fd0e1a06->leave($__internal_afe83b3fb1bbdf513c5b31f6bd5eb12ca29d64440c86a19f5a3bc529fd0e1a06_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  182 => 60,  173 => 59,  160 => 56,  151 => 55,  141 => 59,  138 => 58,  136 => 55,  126 => 48,  118 => 43,  105 => 33,  101 => 32,  97 => 31,  91 => 28,  87 => 27,  83 => 26,  77 => 23,  73 => 22,  69 => 21,  63 => 18,  59 => 17,  55 => 16,  49 => 13,  45 => 12,  41 => 11,  34 => 7,  27 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

<div class=\"container-fluid bg-grey\" id=\"register-container\">
    <div class=\"container\">
        <h2 class=\"text-center\">Rekisteröityminen</h2>
        <h4 class=\"text-center\">Rekisteröityminen ei maksa sinulle mitään. Voit syöttää yrityksesi tiedot rekisteröitymisen jälkeen.</h4>
        {{ form_start(form, {'method': 'post', 'action': path('fos_user_registration_register'), 'attr': {'class': 'fos_user_registration_register'}}) }}
        <div class=\"row\">
            <div class=\"col-md-6 col-md-offset-3\">
                <div class=\"form-group\">
                    {{ form_label(form.company.name, 'Yrityksen nimi') }}
                    {{ form_widget(form.company.name, {'attr': {'class': 'form-control'}}) }}
                    {{ form_errors(form.company.name) }}
                </div>
                <div class=\"form-group\">
                    {{ form_label(form.company.vatId, 'Y-tunnus') }}
                    {{ form_widget(form.company.vatId, {'attr': {'class': 'form-control'}}) }}
                    {{ form_errors(form.company.vatId) }}
                </div>
                <div class=\"form-group\">
                    {{ form_label(form.email, 'Sähköposti') }}
                    {{ form_widget(form.email, {'attr': {'class': 'form-control'}}) }}
                    {{ form_errors(form.email) }}
                </div>
                <div class=\"form-group\">
                    {{ form_label(form.plainPassword.first, 'Salasana') }}
                    {{ form_widget(form.plainPassword.first, {'attr': {'class': 'form-control'}}) }}
                    {{ form_errors(form.plainPassword.first) }}
                </div>
                <div class=\"form-group\">
                    {{ form_label(form.plainPassword.second, 'Salasana uudelleen') }}
                    {{ form_widget(form.plainPassword.second, {'attr': {'class': 'form-control'}}) }}
                    {{ form_errors(form.plainPassword.second) }}
                </div>
            </div>
        </div>

        <div class=\"row\">
            <div class=\"col-sm-12 text-center\"> 
                <input type=\"submit\" value=\"Rekisteröidy\" class=\"btn btn-default login-button\" />
            </div>
        </div>
        {{ form_end(form) }}
        
        <div class=\"row\">
            <div class=\"col-sm-12 text-center\"> 
                <p>Oletko jo rekisteröitynyt?</p>
                <a href=\"{{ path('fos_user_security_login') }}\" class=\"btn btn-default login-button\">Kirjaudu sisään</a>
            </div>
        </div>
    </div>

</div>

{% block stylesheets %}
    <link href=\"{{ asset('bundles/app/css/security.css') }}\" rel=\"stylesheet\" />
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
{% endblock %}", "FOSUserBundle:Registration:register_content.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/FOSUserBundle/views/Registration/register_content.html.twig");
    }
}
