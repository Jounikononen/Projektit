<?php

/* FOSUserBundle:Group:show_content.html.twig */
class __TwigTemplate_ee5e0c7d5c665fa11ebd30d0e022d8fac53e9e303680c8d898c76458366a6f53 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dc8dc05840fcccaa3b7aec9adced54d7cc624a4fe2e8dec8beda2771bec6bd73 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dc8dc05840fcccaa3b7aec9adced54d7cc624a4fe2e8dec8beda2771bec6bd73->enter($__internal_dc8dc05840fcccaa3b7aec9adced54d7cc624a4fe2e8dec8beda2771bec6bd73_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show_content.html.twig"));

        $__internal_83476fbe30a9b9f23b264e26e9b867269db10af89215061528539cc4855e8a33 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_83476fbe30a9b9f23b264e26e9b867269db10af89215061528539cc4855e8a33->enter($__internal_83476fbe30a9b9f23b264e26e9b867269db10af89215061528539cc4855e8a33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show_content.html.twig"));

        // line 2
        echo "
<div class=\"fos_user_group_show\">
    <p>";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("group.show.name", array(), "FOSUserBundle"), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["group"] ?? $this->getContext($context, "group")), "getName", array(), "method"), "html", null, true);
        echo "</p>
</div>
";
        
        $__internal_dc8dc05840fcccaa3b7aec9adced54d7cc624a4fe2e8dec8beda2771bec6bd73->leave($__internal_dc8dc05840fcccaa3b7aec9adced54d7cc624a4fe2e8dec8beda2771bec6bd73_prof);

        
        $__internal_83476fbe30a9b9f23b264e26e9b867269db10af89215061528539cc4855e8a33->leave($__internal_83476fbe30a9b9f23b264e26e9b867269db10af89215061528539cc4855e8a33_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:show_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 4,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

<div class=\"fos_user_group_show\">
    <p>{{ 'group.show.name'|trans }}: {{ group.getName() }}</p>
</div>
", "FOSUserBundle:Group:show_content.html.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Group/show_content.html.twig");
    }
}
