<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_aa3d4720bf3f7a5b75b082e2af9439ebad024fcc1fda5a73933ec9b4f6e9395d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_026676d01283ea123f1a4ce90c57d908f678b0f80ba33bf09458ada1ef6ce068 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_026676d01283ea123f1a4ce90c57d908f678b0f80ba33bf09458ada1ef6ce068->enter($__internal_026676d01283ea123f1a4ce90c57d908f678b0f80ba33bf09458ada1ef6ce068_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $__internal_53ee6dd3795003bd2bae6b553240bc7bf38823af22dd01fde3e12c78e5019ad5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53ee6dd3795003bd2bae6b553240bc7bf38823af22dd01fde3e12c78e5019ad5->enter($__internal_53ee6dd3795003bd2bae6b553240bc7bf38823af22dd01fde3e12c78e5019ad5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_026676d01283ea123f1a4ce90c57d908f678b0f80ba33bf09458ada1ef6ce068->leave($__internal_026676d01283ea123f1a4ce90c57d908f678b0f80ba33bf09458ada1ef6ce068_prof);

        
        $__internal_53ee6dd3795003bd2bae6b553240bc7bf38823af22dd01fde3e12c78e5019ad5->leave($__internal_53ee6dd3795003bd2bae6b553240bc7bf38823af22dd01fde3e12c78e5019ad5_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_10a715182db7b53c79e0489a0272e08590c5170e8dfe0d91905f03fa6584161e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_10a715182db7b53c79e0489a0272e08590c5170e8dfe0d91905f03fa6584161e->enter($__internal_10a715182db7b53c79e0489a0272e08590c5170e8dfe0d91905f03fa6584161e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_b481f1d6fda78f1746dab9e39e1d321c70335c568370063d6c59a6152157dd4e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b481f1d6fda78f1746dab9e39e1d321c70335c568370063d6c59a6152157dd4e->enter($__internal_b481f1d6fda78f1746dab9e39e1d321c70335c568370063d6c59a6152157dd4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_b481f1d6fda78f1746dab9e39e1d321c70335c568370063d6c59a6152157dd4e->leave($__internal_b481f1d6fda78f1746dab9e39e1d321c70335c568370063d6c59a6152157dd4e_prof);

        
        $__internal_10a715182db7b53c79e0489a0272e08590c5170e8dfe0d91905f03fa6584161e->leave($__internal_10a715182db7b53c79e0489a0272e08590c5170e8dfe0d91905f03fa6584161e_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_5ac2da33e6ad24d6861da1efcefc1f4b20a926727f5d6f5c899eb46ac31a73c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5ac2da33e6ad24d6861da1efcefc1f4b20a926727f5d6f5c899eb46ac31a73c9->enter($__internal_5ac2da33e6ad24d6861da1efcefc1f4b20a926727f5d6f5c899eb46ac31a73c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_23dbb00bc481dc7c393e391ac82894c7f415b6ca74cf6452fa3d83f2c26adc92 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_23dbb00bc481dc7c393e391ac82894c7f415b6ca74cf6452fa3d83f2c26adc92->enter($__internal_23dbb00bc481dc7c393e391ac82894c7f415b6ca74cf6452fa3d83f2c26adc92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_23dbb00bc481dc7c393e391ac82894c7f415b6ca74cf6452fa3d83f2c26adc92->leave($__internal_23dbb00bc481dc7c393e391ac82894c7f415b6ca74cf6452fa3d83f2c26adc92_prof);

        
        $__internal_5ac2da33e6ad24d6861da1efcefc1f4b20a926727f5d6f5c899eb46ac31a73c9->leave($__internal_5ac2da33e6ad24d6861da1efcefc1f4b20a926727f5d6f5c899eb46ac31a73c9_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_98bee98e792fbd8ec5e7e32542949e072e65081867e361b63fe250781a2650e4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_98bee98e792fbd8ec5e7e32542949e072e65081867e361b63fe250781a2650e4->enter($__internal_98bee98e792fbd8ec5e7e32542949e072e65081867e361b63fe250781a2650e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_70b0cb7bbb05d99a782515823110c0579daec919a47522d891679edbf96d8f6c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_70b0cb7bbb05d99a782515823110c0579daec919a47522d891679edbf96d8f6c->enter($__internal_70b0cb7bbb05d99a782515823110c0579daec919a47522d891679edbf96d8f6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_70b0cb7bbb05d99a782515823110c0579daec919a47522d891679edbf96d8f6c->leave($__internal_70b0cb7bbb05d99a782515823110c0579daec919a47522d891679edbf96d8f6c_prof);

        
        $__internal_98bee98e792fbd8ec5e7e32542949e072e65081867e361b63fe250781a2650e4->leave($__internal_98bee98e792fbd8ec5e7e32542949e072e65081867e361b63fe250781a2650e4_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
