<?php

/* FOSUserBundle:Security:login_content.html.twig */
class __TwigTemplate_514950be34d62d380b69e76890fc635b87798f160da575d654b3b4db5ce15be9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9e0c962bb7bf0927ee3d260daba01ba048f64e747f05a640d907528b242f6290 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9e0c962bb7bf0927ee3d260daba01ba048f64e747f05a640d907528b242f6290->enter($__internal_9e0c962bb7bf0927ee3d260daba01ba048f64e747f05a640d907528b242f6290_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Security:login_content.html.twig"));

        $__internal_3699d15cb052c640fd40e9cf9c8a0ab005e6f1df5d59c6e3f22c1e8e458d2086 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3699d15cb052c640fd40e9cf9c8a0ab005e6f1df5d59c6e3f22c1e8e458d2086->enter($__internal_3699d15cb052c640fd40e9cf9c8a0ab005e6f1df5d59c6e3f22c1e8e458d2086_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Security:login_content.html.twig"));

        // line 2
        echo "
<div class=\"container-fluid\" id=\"register-container\">
    <div class=\"container text-center\">
        <h2>Kirjaudu palveluumme</h2>
        <div class=\"row\">
            <div class=\"col-md-6 col-md-offset-3\">
                ";
        // line 8
        if (($context["error"] ?? $this->getContext($context, "error"))) {
            // line 9
            echo "                    <div class=\"login-error\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</div>
                ";
        }
        // line 11
        echo "
                <form action=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_check");
        echo "\" method=\"post\">
                    ";
        // line 13
        if (($context["csrf_token"] ?? $this->getContext($context, "csrf_token"))) {
            // line 14
            echo "                        <input type=\"hidden\" name=\"_csrf_token\" value=\"";
            echo twig_escape_filter($this->env, ($context["csrf_token"] ?? $this->getContext($context, "csrf_token")), "html", null, true);
            echo "\" />
                    ";
        }
        // line 16
        echo "
                    <div class=\"input-group margin-bottom-sm\">
                        <span class=\"input-group-addon\"><i class=\"fa fa-envelope-o fa-fw\"></i></span>
                        <input class=\"form-control\" type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 19
        echo twig_escape_filter($this->env, ($context["last_username"] ?? $this->getContext($context, "last_username")), "html", null, true);
        echo "\" placeholder=\"Sähköposti\">
                    </div>
                    <div class=\"input-group\">
                        <span class=\"input-group-addon\"><i class=\"fa fa-key fa-fw\"></i></span>
                        <input class=\"form-control\" type=\"password\" id=\"password\" name=\"_password\" required=\"required\" placeholder=\"Salasana\">
                    </div>

                    <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\" />
                    <label for=\"remember_me\">Muista minut</label><br/>
                    <input type=\"submit\" class=\"btn btn-default login-button\" id=\"_submit\" name=\"_submit\" value=\"Kirjaudu sisään\" />
                    <p>
                        <a href=\"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_resetting_request");
        echo "\">Unohtuiko salasana?</a><br/>
                        <a href=\"";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_registration_register");
        echo "\">Rekisteröidy</a>
                    </p>
                </form>
            </div>
        </div>
    </div>
</div>

";
        // line 39
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 42
        echo "
";
        // line 43
        $this->displayBlock('javascripts', $context, $blocks);
        
        $__internal_9e0c962bb7bf0927ee3d260daba01ba048f64e747f05a640d907528b242f6290->leave($__internal_9e0c962bb7bf0927ee3d260daba01ba048f64e747f05a640d907528b242f6290_prof);

        
        $__internal_3699d15cb052c640fd40e9cf9c8a0ab005e6f1df5d59c6e3f22c1e8e458d2086->leave($__internal_3699d15cb052c640fd40e9cf9c8a0ab005e6f1df5d59c6e3f22c1e8e458d2086_prof);

    }

    // line 39
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_f0a17ce129f116b521a7a970b3c2e45c08bbcbd2ceab6c58a693f764f302663d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f0a17ce129f116b521a7a970b3c2e45c08bbcbd2ceab6c58a693f764f302663d->enter($__internal_f0a17ce129f116b521a7a970b3c2e45c08bbcbd2ceab6c58a693f764f302663d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_b8ab624d186ecaa2f5a35e8297306f07e5b8d98f83842ae13c5191fe54e45098 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8ab624d186ecaa2f5a35e8297306f07e5b8d98f83842ae13c5191fe54e45098->enter($__internal_b8ab624d186ecaa2f5a35e8297306f07e5b8d98f83842ae13c5191fe54e45098_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 40
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/security.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
";
        
        $__internal_b8ab624d186ecaa2f5a35e8297306f07e5b8d98f83842ae13c5191fe54e45098->leave($__internal_b8ab624d186ecaa2f5a35e8297306f07e5b8d98f83842ae13c5191fe54e45098_prof);

        
        $__internal_f0a17ce129f116b521a7a970b3c2e45c08bbcbd2ceab6c58a693f764f302663d->leave($__internal_f0a17ce129f116b521a7a970b3c2e45c08bbcbd2ceab6c58a693f764f302663d_prof);

    }

    // line 43
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_e0d15a898f2c9e4b0ba691987500ae533162f4247170739b97ec73cbb3a6a1a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e0d15a898f2c9e4b0ba691987500ae533162f4247170739b97ec73cbb3a6a1a9->enter($__internal_e0d15a898f2c9e4b0ba691987500ae533162f4247170739b97ec73cbb3a6a1a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_38d6268b0f5e455f5aa6628b5713219a9f830c11480a6701f164554d4a4b5e51 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_38d6268b0f5e455f5aa6628b5713219a9f830c11480a6701f164554d4a4b5e51->enter($__internal_38d6268b0f5e455f5aa6628b5713219a9f830c11480a6701f164554d4a4b5e51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 44
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_38d6268b0f5e455f5aa6628b5713219a9f830c11480a6701f164554d4a4b5e51->leave($__internal_38d6268b0f5e455f5aa6628b5713219a9f830c11480a6701f164554d4a4b5e51_prof);

        
        $__internal_e0d15a898f2c9e4b0ba691987500ae533162f4247170739b97ec73cbb3a6a1a9->leave($__internal_e0d15a898f2c9e4b0ba691987500ae533162f4247170739b97ec73cbb3a6a1a9_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Security:login_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 44,  129 => 43,  116 => 40,  107 => 39,  97 => 43,  94 => 42,  92 => 39,  81 => 31,  77 => 30,  63 => 19,  58 => 16,  52 => 14,  50 => 13,  46 => 12,  43 => 11,  37 => 9,  35 => 8,  27 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

<div class=\"container-fluid\" id=\"register-container\">
    <div class=\"container text-center\">
        <h2>Kirjaudu palveluumme</h2>
        <div class=\"row\">
            <div class=\"col-md-6 col-md-offset-3\">
                {% if error %}
                    <div class=\"login-error\">{{ error.messageKey|trans(error.messageData, 'security') }}</div>
                {% endif %}

                <form action=\"{{ path(\"fos_user_security_check\") }}\" method=\"post\">
                    {% if csrf_token %}
                        <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\" />
                    {% endif %}

                    <div class=\"input-group margin-bottom-sm\">
                        <span class=\"input-group-addon\"><i class=\"fa fa-envelope-o fa-fw\"></i></span>
                        <input class=\"form-control\" type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" placeholder=\"Sähköposti\">
                    </div>
                    <div class=\"input-group\">
                        <span class=\"input-group-addon\"><i class=\"fa fa-key fa-fw\"></i></span>
                        <input class=\"form-control\" type=\"password\" id=\"password\" name=\"_password\" required=\"required\" placeholder=\"Salasana\">
                    </div>

                    <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\" />
                    <label for=\"remember_me\">Muista minut</label><br/>
                    <input type=\"submit\" class=\"btn btn-default login-button\" id=\"_submit\" name=\"_submit\" value=\"Kirjaudu sisään\" />
                    <p>
                        <a href=\"{{ path('fos_user_resetting_request') }}\">Unohtuiko salasana?</a><br/>
                        <a href=\"{{ path('fos_user_registration_register') }}\">Rekisteröidy</a>
                    </p>
                </form>
            </div>
        </div>
    </div>
</div>

{% block stylesheets %}
    <link href=\"{{ asset('bundles/app/css/security.css') }}\" rel=\"stylesheet\" />
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
{% endblock %}", "FOSUserBundle:Security:login_content.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/FOSUserBundle/views/Security/login_content.html.twig");
    }
}
