<?php

/* TwigBundle:Exception:exception.json.twig */
class __TwigTemplate_bb278622bea9c55084cec2112dab060362b29230ed870695965dc774f8d20ecf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_678b121d3413edf38068e8e94d6f8ea1b9edd2c0260320e904cd3b6eadefb46d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_678b121d3413edf38068e8e94d6f8ea1b9edd2c0260320e904cd3b6eadefb46d->enter($__internal_678b121d3413edf38068e8e94d6f8ea1b9edd2c0260320e904cd3b6eadefb46d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        $__internal_6e75861f67cda251261aaddda7f14fe46ca2b8ad77d23557166685187caf2a3a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6e75861f67cda251261aaddda7f14fe46ca2b8ad77d23557166685187caf2a3a->enter($__internal_6e75861f67cda251261aaddda7f14fe46ca2b8ad77d23557166685187caf2a3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")), "exception" => $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_678b121d3413edf38068e8e94d6f8ea1b9edd2c0260320e904cd3b6eadefb46d->leave($__internal_678b121d3413edf38068e8e94d6f8ea1b9edd2c0260320e904cd3b6eadefb46d_prof);

        
        $__internal_6e75861f67cda251261aaddda7f14fe46ca2b8ad77d23557166685187caf2a3a->leave($__internal_6e75861f67cda251261aaddda7f14fe46ca2b8ad77d23557166685187caf2a3a_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "TwigBundle:Exception:exception.json.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.json.twig");
    }
}
