<?php

/* FOSUserBundle:Resetting:check_email.html.twig */
class __TwigTemplate_18acd55940fcc72e99d437abd1885af1f3067782e7f4c69aa5eee055eb2ede28 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Resetting:check_email.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0d27ab9d088e1bc50a83074298fd65b72cbf6099e6a59f3d2b53732022d1cec8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0d27ab9d088e1bc50a83074298fd65b72cbf6099e6a59f3d2b53732022d1cec8->enter($__internal_0d27ab9d088e1bc50a83074298fd65b72cbf6099e6a59f3d2b53732022d1cec8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:check_email.html.twig"));

        $__internal_e350911cf24dfc1efe334511f9369c48bb0576079af8f872426c69e92163b29e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e350911cf24dfc1efe334511f9369c48bb0576079af8f872426c69e92163b29e->enter($__internal_e350911cf24dfc1efe334511f9369c48bb0576079af8f872426c69e92163b29e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:check_email.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0d27ab9d088e1bc50a83074298fd65b72cbf6099e6a59f3d2b53732022d1cec8->leave($__internal_0d27ab9d088e1bc50a83074298fd65b72cbf6099e6a59f3d2b53732022d1cec8_prof);

        
        $__internal_e350911cf24dfc1efe334511f9369c48bb0576079af8f872426c69e92163b29e->leave($__internal_e350911cf24dfc1efe334511f9369c48bb0576079af8f872426c69e92163b29e_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_bed176a62897bbe570aa106433dafe9d08f3bcddb729358d1012c4bd3c63bbd7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bed176a62897bbe570aa106433dafe9d08f3bcddb729358d1012c4bd3c63bbd7->enter($__internal_bed176a62897bbe570aa106433dafe9d08f3bcddb729358d1012c4bd3c63bbd7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_a7b43c5bf397532368956b95c44b1395a28d5bef94eafd9d4c95cbe4aba958a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a7b43c5bf397532368956b95c44b1395a28d5bef94eafd9d4c95cbe4aba958a9->enter($__internal_a7b43c5bf397532368956b95c44b1395a28d5bef94eafd9d4c95cbe4aba958a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <div class=\"container-fluid\" id=\"register-container\">
        <div class=\"container text-center\">
            <h2>Salasanan palautuspyyntö vastaanotettu</h2>
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <p>
                        Ohjeet salasanan vaihtoon on lähetetty sähköpostiisi. Ole hyvä ja tarkista sähköpostisi.
                    </p>
                    <p>
                        <a href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
        echo "\">Kirjautuminen</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_a7b43c5bf397532368956b95c44b1395a28d5bef94eafd9d4c95cbe4aba958a9->leave($__internal_a7b43c5bf397532368956b95c44b1395a28d5bef94eafd9d4c95cbe4aba958a9_prof);

        
        $__internal_bed176a62897bbe570aa106433dafe9d08f3bcddb729358d1012c4bd3c63bbd7->leave($__internal_bed176a62897bbe570aa106433dafe9d08f3bcddb729358d1012c4bd3c63bbd7_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:check_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 15,  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}
    <div class=\"container-fluid\" id=\"register-container\">
        <div class=\"container text-center\">
            <h2>Salasanan palautuspyyntö vastaanotettu</h2>
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <p>
                        Ohjeet salasanan vaihtoon on lähetetty sähköpostiisi. Ole hyvä ja tarkista sähköpostisi.
                    </p>
                    <p>
                        <a href=\"{{ path('fos_user_security_login') }}\">Kirjautuminen</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "FOSUserBundle:Resetting:check_email.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/FOSUserBundle/views/Resetting/check_email.html.twig");
    }
}
