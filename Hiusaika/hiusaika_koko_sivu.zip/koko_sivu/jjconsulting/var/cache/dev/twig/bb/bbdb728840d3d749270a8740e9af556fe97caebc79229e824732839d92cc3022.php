<?php

/* bootstrap_3_layout.html.twig */
class __TwigTemplate_603b0da26060779d86953b87f8813f46fbc1c42d7351a8b172345b1719fc7c25 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("form_div_layout.html.twig", "bootstrap_3_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."form_div_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'form_widget_simple' => array($this, 'block_form_widget_simple'),
                'textarea_widget' => array($this, 'block_textarea_widget'),
                'button_widget' => array($this, 'block_button_widget'),
                'money_widget' => array($this, 'block_money_widget'),
                'percent_widget' => array($this, 'block_percent_widget'),
                'datetime_widget' => array($this, 'block_datetime_widget'),
                'date_widget' => array($this, 'block_date_widget'),
                'time_widget' => array($this, 'block_time_widget'),
                'dateinterval_widget' => array($this, 'block_dateinterval_widget'),
                'choice_widget_collapsed' => array($this, 'block_choice_widget_collapsed'),
                'choice_widget_expanded' => array($this, 'block_choice_widget_expanded'),
                'checkbox_widget' => array($this, 'block_checkbox_widget'),
                'radio_widget' => array($this, 'block_radio_widget'),
                'form_label' => array($this, 'block_form_label'),
                'choice_label' => array($this, 'block_choice_label'),
                'checkbox_label' => array($this, 'block_checkbox_label'),
                'radio_label' => array($this, 'block_radio_label'),
                'checkbox_radio_label' => array($this, 'block_checkbox_radio_label'),
                'form_row' => array($this, 'block_form_row'),
                'button_row' => array($this, 'block_button_row'),
                'choice_row' => array($this, 'block_choice_row'),
                'date_row' => array($this, 'block_date_row'),
                'time_row' => array($this, 'block_time_row'),
                'datetime_row' => array($this, 'block_datetime_row'),
                'checkbox_row' => array($this, 'block_checkbox_row'),
                'radio_row' => array($this, 'block_radio_row'),
                'form_errors' => array($this, 'block_form_errors'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_817d2c7b9d954dfedc4c2fda5b6bb1ba858196f882e79d359c5ef40205ed1d70 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_817d2c7b9d954dfedc4c2fda5b6bb1ba858196f882e79d359c5ef40205ed1d70->enter($__internal_817d2c7b9d954dfedc4c2fda5b6bb1ba858196f882e79d359c5ef40205ed1d70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_layout.html.twig"));

        $__internal_3ccb4a5e988e8c157e78ae62f96ea08c3ca6d890a0937b85c69485c4223ef183 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3ccb4a5e988e8c157e78ae62f96ea08c3ca6d890a0937b85c69485c4223ef183->enter($__internal_3ccb4a5e988e8c157e78ae62f96ea08c3ca6d890a0937b85c69485c4223ef183_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_layout.html.twig"));

        // line 2
        echo "
";
        // line 4
        echo "
";
        // line 5
        $this->displayBlock('form_widget_simple', $context, $blocks);
        // line 11
        echo "
";
        // line 12
        $this->displayBlock('textarea_widget', $context, $blocks);
        // line 16
        echo "
";
        // line 17
        $this->displayBlock('button_widget', $context, $blocks);
        // line 21
        echo "
";
        // line 22
        $this->displayBlock('money_widget', $context, $blocks);
        // line 34
        echo "
";
        // line 35
        $this->displayBlock('percent_widget', $context, $blocks);
        // line 41
        echo "
";
        // line 42
        $this->displayBlock('datetime_widget', $context, $blocks);
        // line 55
        echo "
";
        // line 56
        $this->displayBlock('date_widget', $context, $blocks);
        // line 74
        echo "
";
        // line 75
        $this->displayBlock('time_widget', $context, $blocks);
        // line 90
        $this->displayBlock('dateinterval_widget', $context, $blocks);
        // line 128
        $this->displayBlock('choice_widget_collapsed', $context, $blocks);
        // line 132
        echo "
";
        // line 133
        $this->displayBlock('choice_widget_expanded', $context, $blocks);
        // line 152
        echo "
";
        // line 153
        $this->displayBlock('checkbox_widget', $context, $blocks);
        // line 163
        echo "
";
        // line 164
        $this->displayBlock('radio_widget', $context, $blocks);
        // line 174
        echo "
";
        // line 176
        echo "
";
        // line 177
        $this->displayBlock('form_label', $context, $blocks);
        // line 181
        echo "
";
        // line 182
        $this->displayBlock('choice_label', $context, $blocks);
        // line 187
        echo "
";
        // line 188
        $this->displayBlock('checkbox_label', $context, $blocks);
        // line 193
        echo "
";
        // line 194
        $this->displayBlock('radio_label', $context, $blocks);
        // line 199
        echo "
";
        // line 200
        $this->displayBlock('checkbox_radio_label', $context, $blocks);
        // line 224
        echo "
";
        // line 226
        echo "
";
        // line 227
        $this->displayBlock('form_row', $context, $blocks);
        // line 234
        echo "
";
        // line 235
        $this->displayBlock('button_row', $context, $blocks);
        // line 240
        echo "
";
        // line 241
        $this->displayBlock('choice_row', $context, $blocks);
        // line 245
        echo "
";
        // line 246
        $this->displayBlock('date_row', $context, $blocks);
        // line 250
        echo "
";
        // line 251
        $this->displayBlock('time_row', $context, $blocks);
        // line 255
        echo "
";
        // line 256
        $this->displayBlock('datetime_row', $context, $blocks);
        // line 260
        echo "
";
        // line 261
        $this->displayBlock('checkbox_row', $context, $blocks);
        // line 267
        echo "
";
        // line 268
        $this->displayBlock('radio_row', $context, $blocks);
        // line 274
        echo "
";
        // line 276
        echo "
";
        // line 277
        $this->displayBlock('form_errors', $context, $blocks);
        
        $__internal_817d2c7b9d954dfedc4c2fda5b6bb1ba858196f882e79d359c5ef40205ed1d70->leave($__internal_817d2c7b9d954dfedc4c2fda5b6bb1ba858196f882e79d359c5ef40205ed1d70_prof);

        
        $__internal_3ccb4a5e988e8c157e78ae62f96ea08c3ca6d890a0937b85c69485c4223ef183->leave($__internal_3ccb4a5e988e8c157e78ae62f96ea08c3ca6d890a0937b85c69485c4223ef183_prof);

    }

    // line 5
    public function block_form_widget_simple($context, array $blocks = array())
    {
        $__internal_a5a6455aa589622483b578446549390325a3d12d4c828f5fb530e967b3a871e7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a5a6455aa589622483b578446549390325a3d12d4c828f5fb530e967b3a871e7->enter($__internal_a5a6455aa589622483b578446549390325a3d12d4c828f5fb530e967b3a871e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        $__internal_6f931a2f0e926234a44627f8c65cbba94d2b960bd65e1914e7b6817c93db0299 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6f931a2f0e926234a44627f8c65cbba94d2b960bd65e1914e7b6817c93db0299->enter($__internal_6f931a2f0e926234a44627f8c65cbba94d2b960bd65e1914e7b6817c93db0299_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        // line 6
        if (( !array_key_exists("type", $context) || !twig_in_filter(($context["type"] ?? $this->getContext($context, "type")), array(0 => "file", 1 => "hidden")))) {
            // line 7
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        }
        // line 9
        $this->displayParentBlock("form_widget_simple", $context, $blocks);
        
        $__internal_6f931a2f0e926234a44627f8c65cbba94d2b960bd65e1914e7b6817c93db0299->leave($__internal_6f931a2f0e926234a44627f8c65cbba94d2b960bd65e1914e7b6817c93db0299_prof);

        
        $__internal_a5a6455aa589622483b578446549390325a3d12d4c828f5fb530e967b3a871e7->leave($__internal_a5a6455aa589622483b578446549390325a3d12d4c828f5fb530e967b3a871e7_prof);

    }

    // line 12
    public function block_textarea_widget($context, array $blocks = array())
    {
        $__internal_e17402463ab922b31a1d3f1ca712db23b347c5aafdd186dc38b53a0b1b927225 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e17402463ab922b31a1d3f1ca712db23b347c5aafdd186dc38b53a0b1b927225->enter($__internal_e17402463ab922b31a1d3f1ca712db23b347c5aafdd186dc38b53a0b1b927225_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textarea_widget"));

        $__internal_135e6866a1cfc59e8498d0dad79bea59d1f0a7aaa6aaa768f2e153f6a1c39769 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_135e6866a1cfc59e8498d0dad79bea59d1f0a7aaa6aaa768f2e153f6a1c39769->enter($__internal_135e6866a1cfc59e8498d0dad79bea59d1f0a7aaa6aaa768f2e153f6a1c39769_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textarea_widget"));

        // line 13
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        // line 14
        $this->displayParentBlock("textarea_widget", $context, $blocks);
        
        $__internal_135e6866a1cfc59e8498d0dad79bea59d1f0a7aaa6aaa768f2e153f6a1c39769->leave($__internal_135e6866a1cfc59e8498d0dad79bea59d1f0a7aaa6aaa768f2e153f6a1c39769_prof);

        
        $__internal_e17402463ab922b31a1d3f1ca712db23b347c5aafdd186dc38b53a0b1b927225->leave($__internal_e17402463ab922b31a1d3f1ca712db23b347c5aafdd186dc38b53a0b1b927225_prof);

    }

    // line 17
    public function block_button_widget($context, array $blocks = array())
    {
        $__internal_8c5aa7c5aa6eb899a90e1520bf9ddce9e571a209ecd25cb1434753da1eac7e2d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8c5aa7c5aa6eb899a90e1520bf9ddce9e571a209ecd25cb1434753da1eac7e2d->enter($__internal_8c5aa7c5aa6eb899a90e1520bf9ddce9e571a209ecd25cb1434753da1eac7e2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        $__internal_fa7ba47914584de255c0709c712c9fa2c513e2fb0057c0f361f95c9a2baaf3be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa7ba47914584de255c0709c712c9fa2c513e2fb0057c0f361f95c9a2baaf3be->enter($__internal_fa7ba47914584de255c0709c712c9fa2c513e2fb0057c0f361f95c9a2baaf3be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        // line 18
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "btn-default")) : ("btn-default")) . " btn"))));
        // line 19
        $this->displayParentBlock("button_widget", $context, $blocks);
        
        $__internal_fa7ba47914584de255c0709c712c9fa2c513e2fb0057c0f361f95c9a2baaf3be->leave($__internal_fa7ba47914584de255c0709c712c9fa2c513e2fb0057c0f361f95c9a2baaf3be_prof);

        
        $__internal_8c5aa7c5aa6eb899a90e1520bf9ddce9e571a209ecd25cb1434753da1eac7e2d->leave($__internal_8c5aa7c5aa6eb899a90e1520bf9ddce9e571a209ecd25cb1434753da1eac7e2d_prof);

    }

    // line 22
    public function block_money_widget($context, array $blocks = array())
    {
        $__internal_b577c377abd91b0b5da572e04f5a28c2c5ad2f96c3f31fc45d24111341fc182b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b577c377abd91b0b5da572e04f5a28c2c5ad2f96c3f31fc45d24111341fc182b->enter($__internal_b577c377abd91b0b5da572e04f5a28c2c5ad2f96c3f31fc45d24111341fc182b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        $__internal_195f35834231b825d573a7b29355c7fce25edad4afcb51bb688250ead879d62f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_195f35834231b825d573a7b29355c7fce25edad4afcb51bb688250ead879d62f->enter($__internal_195f35834231b825d573a7b29355c7fce25edad4afcb51bb688250ead879d62f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        // line 23
        echo "<div class=\"input-group\">
        ";
        // line 24
        $context["append"] = (is_string($__internal_5f133ae01ee39e9db39ac71da85891b0a3e3a9f9f62ca0dc103f34a6fd0918b5 = ($context["money_pattern"] ?? $this->getContext($context, "money_pattern"))) && is_string($__internal_919d4d2fdace67dc46d0bb30740d6e7133fa9378b7c98b6f9fddc9c9147e9680 = "{{") && ('' === $__internal_919d4d2fdace67dc46d0bb30740d6e7133fa9378b7c98b6f9fddc9c9147e9680 || 0 === strpos($__internal_5f133ae01ee39e9db39ac71da85891b0a3e3a9f9f62ca0dc103f34a6fd0918b5, $__internal_919d4d2fdace67dc46d0bb30740d6e7133fa9378b7c98b6f9fddc9c9147e9680)));
        // line 25
        echo "        ";
        if ( !($context["append"] ?? $this->getContext($context, "append"))) {
            // line 26
            echo "            <span class=\"input-group-addon\">";
            echo twig_escape_filter($this->env, twig_replace_filter(($context["money_pattern"] ?? $this->getContext($context, "money_pattern")), array("{{ widget }}" => "")), "html", null, true);
            echo "</span>
        ";
        }
        // line 28
        $this->displayBlock("form_widget_simple", $context, $blocks);
        // line 29
        if (($context["append"] ?? $this->getContext($context, "append"))) {
            // line 30
            echo "            <span class=\"input-group-addon\">";
            echo twig_escape_filter($this->env, twig_replace_filter(($context["money_pattern"] ?? $this->getContext($context, "money_pattern")), array("{{ widget }}" => "")), "html", null, true);
            echo "</span>
        ";
        }
        // line 32
        echo "    </div>";
        
        $__internal_195f35834231b825d573a7b29355c7fce25edad4afcb51bb688250ead879d62f->leave($__internal_195f35834231b825d573a7b29355c7fce25edad4afcb51bb688250ead879d62f_prof);

        
        $__internal_b577c377abd91b0b5da572e04f5a28c2c5ad2f96c3f31fc45d24111341fc182b->leave($__internal_b577c377abd91b0b5da572e04f5a28c2c5ad2f96c3f31fc45d24111341fc182b_prof);

    }

    // line 35
    public function block_percent_widget($context, array $blocks = array())
    {
        $__internal_3610b0641644d064f6652fa544e9ac61a9f93117a2225ee61b1720fa9bc5f269 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3610b0641644d064f6652fa544e9ac61a9f93117a2225ee61b1720fa9bc5f269->enter($__internal_3610b0641644d064f6652fa544e9ac61a9f93117a2225ee61b1720fa9bc5f269_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        $__internal_cd6fd26e7fd127a18813b8d2102f4126803a5e53b9b1cc684ec6ea65d388e49d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd6fd26e7fd127a18813b8d2102f4126803a5e53b9b1cc684ec6ea65d388e49d->enter($__internal_cd6fd26e7fd127a18813b8d2102f4126803a5e53b9b1cc684ec6ea65d388e49d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        // line 36
        echo "<div class=\"input-group\">";
        // line 37
        $this->displayBlock("form_widget_simple", $context, $blocks);
        // line 38
        echo "<span class=\"input-group-addon\">%</span>
    </div>";
        
        $__internal_cd6fd26e7fd127a18813b8d2102f4126803a5e53b9b1cc684ec6ea65d388e49d->leave($__internal_cd6fd26e7fd127a18813b8d2102f4126803a5e53b9b1cc684ec6ea65d388e49d_prof);

        
        $__internal_3610b0641644d064f6652fa544e9ac61a9f93117a2225ee61b1720fa9bc5f269->leave($__internal_3610b0641644d064f6652fa544e9ac61a9f93117a2225ee61b1720fa9bc5f269_prof);

    }

    // line 42
    public function block_datetime_widget($context, array $blocks = array())
    {
        $__internal_55602e16bc8f8523d34157db5ce22cb750cdf5398058d53d13855aefd489532d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_55602e16bc8f8523d34157db5ce22cb750cdf5398058d53d13855aefd489532d->enter($__internal_55602e16bc8f8523d34157db5ce22cb750cdf5398058d53d13855aefd489532d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        $__internal_3b118a8865412c74faf41a65b7137ea92be3946b529ed669e02668efe0901b8f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3b118a8865412c74faf41a65b7137ea92be3946b529ed669e02668efe0901b8f->enter($__internal_3b118a8865412c74faf41a65b7137ea92be3946b529ed669e02668efe0901b8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        // line 43
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 44
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 46
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 47
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 48
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "date", array()), 'errors');
            // line 49
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "time", array()), 'errors');
            // line 50
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "date", array()), 'widget', array("datetime" => true));
            // line 51
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "time", array()), 'widget', array("datetime" => true));
            // line 52
            echo "</div>";
        }
        
        $__internal_3b118a8865412c74faf41a65b7137ea92be3946b529ed669e02668efe0901b8f->leave($__internal_3b118a8865412c74faf41a65b7137ea92be3946b529ed669e02668efe0901b8f_prof);

        
        $__internal_55602e16bc8f8523d34157db5ce22cb750cdf5398058d53d13855aefd489532d->leave($__internal_55602e16bc8f8523d34157db5ce22cb750cdf5398058d53d13855aefd489532d_prof);

    }

    // line 56
    public function block_date_widget($context, array $blocks = array())
    {
        $__internal_8e2a70ec08df5237bf39b7c2e18c7f76ecc8722a653bf81149adcc3a9792a6aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e2a70ec08df5237bf39b7c2e18c7f76ecc8722a653bf81149adcc3a9792a6aa->enter($__internal_8e2a70ec08df5237bf39b7c2e18c7f76ecc8722a653bf81149adcc3a9792a6aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        $__internal_35dc56a319c143489f5cc812ad42f115b06e07633e6e0350698f5b54771f1fdc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_35dc56a319c143489f5cc812ad42f115b06e07633e6e0350698f5b54771f1fdc->enter($__internal_35dc56a319c143489f5cc812ad42f115b06e07633e6e0350698f5b54771f1fdc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        // line 57
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 58
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 60
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 61
            if (( !array_key_exists("datetime", $context) ||  !($context["datetime"] ?? $this->getContext($context, "datetime")))) {
                // line 62
                echo "<div ";
                $this->displayBlock("widget_container_attributes", $context, $blocks);
                echo ">";
            }
            // line 64
            echo twig_replace_filter(($context["date_pattern"] ?? $this->getContext($context, "date_pattern")), array("{{ year }}" =>             // line 65
$this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "year", array()), 'widget'), "{{ month }}" =>             // line 66
$this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "month", array()), 'widget'), "{{ day }}" =>             // line 67
$this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "day", array()), 'widget')));
            // line 69
            if (( !array_key_exists("datetime", $context) ||  !($context["datetime"] ?? $this->getContext($context, "datetime")))) {
                // line 70
                echo "</div>";
            }
        }
        
        $__internal_35dc56a319c143489f5cc812ad42f115b06e07633e6e0350698f5b54771f1fdc->leave($__internal_35dc56a319c143489f5cc812ad42f115b06e07633e6e0350698f5b54771f1fdc_prof);

        
        $__internal_8e2a70ec08df5237bf39b7c2e18c7f76ecc8722a653bf81149adcc3a9792a6aa->leave($__internal_8e2a70ec08df5237bf39b7c2e18c7f76ecc8722a653bf81149adcc3a9792a6aa_prof);

    }

    // line 75
    public function block_time_widget($context, array $blocks = array())
    {
        $__internal_c4f457c0984431898846436f60c6dcbaac476856d27350a1387232065b55ca84 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c4f457c0984431898846436f60c6dcbaac476856d27350a1387232065b55ca84->enter($__internal_c4f457c0984431898846436f60c6dcbaac476856d27350a1387232065b55ca84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        $__internal_7a2142a45b23e0d66b91b8bd05f7fd47e7008c1f04e4f760a51f43bef7e73fc9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7a2142a45b23e0d66b91b8bd05f7fd47e7008c1f04e4f760a51f43bef7e73fc9->enter($__internal_7a2142a45b23e0d66b91b8bd05f7fd47e7008c1f04e4f760a51f43bef7e73fc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        // line 76
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 77
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 79
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 80
            if (( !array_key_exists("datetime", $context) || (false == ($context["datetime"] ?? $this->getContext($context, "datetime"))))) {
                // line 81
                echo "<div ";
                $this->displayBlock("widget_container_attributes", $context, $blocks);
                echo ">";
            }
            // line 83
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "hour", array()), 'widget');
            if (($context["with_minutes"] ?? $this->getContext($context, "with_minutes"))) {
                echo ":";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minute", array()), 'widget');
            }
            if (($context["with_seconds"] ?? $this->getContext($context, "with_seconds"))) {
                echo ":";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "second", array()), 'widget');
            }
            // line 84
            echo "        ";
            if (( !array_key_exists("datetime", $context) || (false == ($context["datetime"] ?? $this->getContext($context, "datetime"))))) {
                // line 85
                echo "</div>";
            }
        }
        
        $__internal_7a2142a45b23e0d66b91b8bd05f7fd47e7008c1f04e4f760a51f43bef7e73fc9->leave($__internal_7a2142a45b23e0d66b91b8bd05f7fd47e7008c1f04e4f760a51f43bef7e73fc9_prof);

        
        $__internal_c4f457c0984431898846436f60c6dcbaac476856d27350a1387232065b55ca84->leave($__internal_c4f457c0984431898846436f60c6dcbaac476856d27350a1387232065b55ca84_prof);

    }

    // line 90
    public function block_dateinterval_widget($context, array $blocks = array())
    {
        $__internal_6211bb55f675261dc8cfeb077a6324604f6c871a2a0fbac39573cef53c6c3ab9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6211bb55f675261dc8cfeb077a6324604f6c871a2a0fbac39573cef53c6c3ab9->enter($__internal_6211bb55f675261dc8cfeb077a6324604f6c871a2a0fbac39573cef53c6c3ab9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        $__internal_9a52dbc31bd288fb8f16791402de3cb26ea44c337ccd16027a8b0a365d05572e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9a52dbc31bd288fb8f16791402de3cb26ea44c337ccd16027a8b0a365d05572e->enter($__internal_9a52dbc31bd288fb8f16791402de3cb26ea44c337ccd16027a8b0a365d05572e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        // line 91
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 92
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 94
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 95
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 96
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
            // line 97
            echo "<div class=\"table-responsive\">
                <table class=\"table ";
            // line 98
            echo twig_escape_filter($this->env, ((array_key_exists("table_class", $context)) ? (_twig_default_filter(($context["table_class"] ?? $this->getContext($context, "table_class")), "table-bordered table-condensed table-striped")) : ("table-bordered table-condensed table-striped")), "html", null, true);
            echo "\">
                    <thead>
                    <tr>";
            // line 101
            if (($context["with_years"] ?? $this->getContext($context, "with_years"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "years", array()), 'label');
                echo "</th>";
            }
            // line 102
            if (($context["with_months"] ?? $this->getContext($context, "with_months"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "months", array()), 'label');
                echo "</th>";
            }
            // line 103
            if (($context["with_weeks"] ?? $this->getContext($context, "with_weeks"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "weeks", array()), 'label');
                echo "</th>";
            }
            // line 104
            if (($context["with_days"] ?? $this->getContext($context, "with_days"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "days", array()), 'label');
                echo "</th>";
            }
            // line 105
            if (($context["with_hours"] ?? $this->getContext($context, "with_hours"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "hours", array()), 'label');
                echo "</th>";
            }
            // line 106
            if (($context["with_minutes"] ?? $this->getContext($context, "with_minutes"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minutes", array()), 'label');
                echo "</th>";
            }
            // line 107
            if (($context["with_seconds"] ?? $this->getContext($context, "with_seconds"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "seconds", array()), 'label');
                echo "</th>";
            }
            // line 108
            echo "</tr>
                    </thead>
                    <tbody>
                    <tr>";
            // line 112
            if (($context["with_years"] ?? $this->getContext($context, "with_years"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "years", array()), 'widget');
                echo "</td>";
            }
            // line 113
            if (($context["with_months"] ?? $this->getContext($context, "with_months"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "months", array()), 'widget');
                echo "</td>";
            }
            // line 114
            if (($context["with_weeks"] ?? $this->getContext($context, "with_weeks"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "weeks", array()), 'widget');
                echo "</td>";
            }
            // line 115
            if (($context["with_days"] ?? $this->getContext($context, "with_days"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "days", array()), 'widget');
                echo "</td>";
            }
            // line 116
            if (($context["with_hours"] ?? $this->getContext($context, "with_hours"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "hours", array()), 'widget');
                echo "</td>";
            }
            // line 117
            if (($context["with_minutes"] ?? $this->getContext($context, "with_minutes"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minutes", array()), 'widget');
                echo "</td>";
            }
            // line 118
            if (($context["with_seconds"] ?? $this->getContext($context, "with_seconds"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "seconds", array()), 'widget');
                echo "</td>";
            }
            // line 119
            echo "</tr>
                    </tbody>
                </table>
            </div>";
            // line 123
            if (($context["with_invert"] ?? $this->getContext($context, "with_invert"))) {
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "invert", array()), 'widget');
            }
            // line 124
            echo "</div>";
        }
        
        $__internal_9a52dbc31bd288fb8f16791402de3cb26ea44c337ccd16027a8b0a365d05572e->leave($__internal_9a52dbc31bd288fb8f16791402de3cb26ea44c337ccd16027a8b0a365d05572e_prof);

        
        $__internal_6211bb55f675261dc8cfeb077a6324604f6c871a2a0fbac39573cef53c6c3ab9->leave($__internal_6211bb55f675261dc8cfeb077a6324604f6c871a2a0fbac39573cef53c6c3ab9_prof);

    }

    // line 128
    public function block_choice_widget_collapsed($context, array $blocks = array())
    {
        $__internal_aee0cccac916c41f5d450ee1396076d0d4c29bc43484b9627fc913070069d6b0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aee0cccac916c41f5d450ee1396076d0d4c29bc43484b9627fc913070069d6b0->enter($__internal_aee0cccac916c41f5d450ee1396076d0d4c29bc43484b9627fc913070069d6b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_collapsed"));

        $__internal_d5ae1e14baa48c1d8f112d9f5c2247f0ff1475913c6a2e5781f72da60dce21a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d5ae1e14baa48c1d8f112d9f5c2247f0ff1475913c6a2e5781f72da60dce21a1->enter($__internal_d5ae1e14baa48c1d8f112d9f5c2247f0ff1475913c6a2e5781f72da60dce21a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_collapsed"));

        // line 129
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        // line 130
        $this->displayParentBlock("choice_widget_collapsed", $context, $blocks);
        
        $__internal_d5ae1e14baa48c1d8f112d9f5c2247f0ff1475913c6a2e5781f72da60dce21a1->leave($__internal_d5ae1e14baa48c1d8f112d9f5c2247f0ff1475913c6a2e5781f72da60dce21a1_prof);

        
        $__internal_aee0cccac916c41f5d450ee1396076d0d4c29bc43484b9627fc913070069d6b0->leave($__internal_aee0cccac916c41f5d450ee1396076d0d4c29bc43484b9627fc913070069d6b0_prof);

    }

    // line 133
    public function block_choice_widget_expanded($context, array $blocks = array())
    {
        $__internal_c6eab3900e983e332bfec2aeebe8c74ed73b164cd1a55c13b60932944e0b0263 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c6eab3900e983e332bfec2aeebe8c74ed73b164cd1a55c13b60932944e0b0263->enter($__internal_c6eab3900e983e332bfec2aeebe8c74ed73b164cd1a55c13b60932944e0b0263_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        $__internal_96bd71ad994fa05570cc1a7f42da491a9a79015c70613114b90cf89437566f2e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_96bd71ad994fa05570cc1a7f42da491a9a79015c70613114b90cf89437566f2e->enter($__internal_96bd71ad994fa05570cc1a7f42da491a9a79015c70613114b90cf89437566f2e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        // line 134
        if (twig_in_filter("-inline", (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) {
            // line 135
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 136
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 137
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 138
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain"))));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        } else {
            // line 142
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 143
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 144
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 145
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 146
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain"))));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 149
            echo "</div>";
        }
        
        $__internal_96bd71ad994fa05570cc1a7f42da491a9a79015c70613114b90cf89437566f2e->leave($__internal_96bd71ad994fa05570cc1a7f42da491a9a79015c70613114b90cf89437566f2e_prof);

        
        $__internal_c6eab3900e983e332bfec2aeebe8c74ed73b164cd1a55c13b60932944e0b0263->leave($__internal_c6eab3900e983e332bfec2aeebe8c74ed73b164cd1a55c13b60932944e0b0263_prof);

    }

    // line 153
    public function block_checkbox_widget($context, array $blocks = array())
    {
        $__internal_5f7bac2c6612587e5446d9913297149092f4b6d62653e38e3f2b5b975d8f5623 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5f7bac2c6612587e5446d9913297149092f4b6d62653e38e3f2b5b975d8f5623->enter($__internal_5f7bac2c6612587e5446d9913297149092f4b6d62653e38e3f2b5b975d8f5623_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        $__internal_9400955fb5c7ecde33b8f2a81d977aaacb6b64e8127bbd36ae6023dd61a6dec0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9400955fb5c7ecde33b8f2a81d977aaacb6b64e8127bbd36ae6023dd61a6dec0->enter($__internal_9400955fb5c7ecde33b8f2a81d977aaacb6b64e8127bbd36ae6023dd61a6dec0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        // line 154
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 155
        if (twig_in_filter("checkbox-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 156
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
        } else {
            // line 158
            echo "<div class=\"checkbox\">";
            // line 159
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
            // line 160
            echo "</div>";
        }
        
        $__internal_9400955fb5c7ecde33b8f2a81d977aaacb6b64e8127bbd36ae6023dd61a6dec0->leave($__internal_9400955fb5c7ecde33b8f2a81d977aaacb6b64e8127bbd36ae6023dd61a6dec0_prof);

        
        $__internal_5f7bac2c6612587e5446d9913297149092f4b6d62653e38e3f2b5b975d8f5623->leave($__internal_5f7bac2c6612587e5446d9913297149092f4b6d62653e38e3f2b5b975d8f5623_prof);

    }

    // line 164
    public function block_radio_widget($context, array $blocks = array())
    {
        $__internal_58c9bb30c720c01635f7d89e4f7fb58d7aaef7fdf1c9829098cf55338f1a177f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_58c9bb30c720c01635f7d89e4f7fb58d7aaef7fdf1c9829098cf55338f1a177f->enter($__internal_58c9bb30c720c01635f7d89e4f7fb58d7aaef7fdf1c9829098cf55338f1a177f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        $__internal_874ea5843f5d72f8ab108dabafa5fa41fc237cf7122a7b02f02e54a92f2c1063 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_874ea5843f5d72f8ab108dabafa5fa41fc237cf7122a7b02f02e54a92f2c1063->enter($__internal_874ea5843f5d72f8ab108dabafa5fa41fc237cf7122a7b02f02e54a92f2c1063_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        // line 165
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 166
        if (twig_in_filter("radio-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 167
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
        } else {
            // line 169
            echo "<div class=\"radio\">";
            // line 170
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
            // line 171
            echo "</div>";
        }
        
        $__internal_874ea5843f5d72f8ab108dabafa5fa41fc237cf7122a7b02f02e54a92f2c1063->leave($__internal_874ea5843f5d72f8ab108dabafa5fa41fc237cf7122a7b02f02e54a92f2c1063_prof);

        
        $__internal_58c9bb30c720c01635f7d89e4f7fb58d7aaef7fdf1c9829098cf55338f1a177f->leave($__internal_58c9bb30c720c01635f7d89e4f7fb58d7aaef7fdf1c9829098cf55338f1a177f_prof);

    }

    // line 177
    public function block_form_label($context, array $blocks = array())
    {
        $__internal_73323fd302884dfce5745c1a7d18e54374b4b0aa119e6cca9d22c6972ecf1ebd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_73323fd302884dfce5745c1a7d18e54374b4b0aa119e6cca9d22c6972ecf1ebd->enter($__internal_73323fd302884dfce5745c1a7d18e54374b4b0aa119e6cca9d22c6972ecf1ebd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        $__internal_6545841639211fc1d03edd0aa23c25184b40aef223f13af38e414b3d4087ab36 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6545841639211fc1d03edd0aa23c25184b40aef223f13af38e414b3d4087ab36->enter($__internal_6545841639211fc1d03edd0aa23c25184b40aef223f13af38e414b3d4087ab36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        // line 178
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " control-label"))));
        // line 179
        $this->displayParentBlock("form_label", $context, $blocks);
        
        $__internal_6545841639211fc1d03edd0aa23c25184b40aef223f13af38e414b3d4087ab36->leave($__internal_6545841639211fc1d03edd0aa23c25184b40aef223f13af38e414b3d4087ab36_prof);

        
        $__internal_73323fd302884dfce5745c1a7d18e54374b4b0aa119e6cca9d22c6972ecf1ebd->leave($__internal_73323fd302884dfce5745c1a7d18e54374b4b0aa119e6cca9d22c6972ecf1ebd_prof);

    }

    // line 182
    public function block_choice_label($context, array $blocks = array())
    {
        $__internal_60cb99619d6b36333f82a89e5169f9d6962b75f6b9ca53069a33801f727f2a59 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_60cb99619d6b36333f82a89e5169f9d6962b75f6b9ca53069a33801f727f2a59->enter($__internal_60cb99619d6b36333f82a89e5169f9d6962b75f6b9ca53069a33801f727f2a59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_label"));

        $__internal_df9a837f9ba6f831903e5e9602f7d4f22da48da43651103cd97c4cde06f49016 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df9a837f9ba6f831903e5e9602f7d4f22da48da43651103cd97c4cde06f49016->enter($__internal_df9a837f9ba6f831903e5e9602f7d4f22da48da43651103cd97c4cde06f49016_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_label"));

        // line 184
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(twig_replace_filter((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), array("checkbox-inline" => "", "radio-inline" => "")))));
        // line 185
        $this->displayBlock("form_label", $context, $blocks);
        
        $__internal_df9a837f9ba6f831903e5e9602f7d4f22da48da43651103cd97c4cde06f49016->leave($__internal_df9a837f9ba6f831903e5e9602f7d4f22da48da43651103cd97c4cde06f49016_prof);

        
        $__internal_60cb99619d6b36333f82a89e5169f9d6962b75f6b9ca53069a33801f727f2a59->leave($__internal_60cb99619d6b36333f82a89e5169f9d6962b75f6b9ca53069a33801f727f2a59_prof);

    }

    // line 188
    public function block_checkbox_label($context, array $blocks = array())
    {
        $__internal_024708af929d8e07a5dc0313949e77c25e33decd3b3889dc4cc948f75321a110 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_024708af929d8e07a5dc0313949e77c25e33decd3b3889dc4cc948f75321a110->enter($__internal_024708af929d8e07a5dc0313949e77c25e33decd3b3889dc4cc948f75321a110_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_label"));

        $__internal_3779b56e7e85999be74496717dcb7e987ea156e3be21c984747a25cdd6c912f0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3779b56e7e85999be74496717dcb7e987ea156e3be21c984747a25cdd6c912f0->enter($__internal_3779b56e7e85999be74496717dcb7e987ea156e3be21c984747a25cdd6c912f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_label"));

        // line 189
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("for" => ($context["id"] ?? $this->getContext($context, "id"))));
        // line 191
        $this->displayBlock("checkbox_radio_label", $context, $blocks);
        
        $__internal_3779b56e7e85999be74496717dcb7e987ea156e3be21c984747a25cdd6c912f0->leave($__internal_3779b56e7e85999be74496717dcb7e987ea156e3be21c984747a25cdd6c912f0_prof);

        
        $__internal_024708af929d8e07a5dc0313949e77c25e33decd3b3889dc4cc948f75321a110->leave($__internal_024708af929d8e07a5dc0313949e77c25e33decd3b3889dc4cc948f75321a110_prof);

    }

    // line 194
    public function block_radio_label($context, array $blocks = array())
    {
        $__internal_e140de5657be549bdce9d11645bfa55cbf9029417457488e3e321c659c3106e5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e140de5657be549bdce9d11645bfa55cbf9029417457488e3e321c659c3106e5->enter($__internal_e140de5657be549bdce9d11645bfa55cbf9029417457488e3e321c659c3106e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_label"));

        $__internal_4221771ccc72c9b8efff098d29a6574b23a4a4ae73ec5874f9020fd2d0e01fed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4221771ccc72c9b8efff098d29a6574b23a4a4ae73ec5874f9020fd2d0e01fed->enter($__internal_4221771ccc72c9b8efff098d29a6574b23a4a4ae73ec5874f9020fd2d0e01fed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_label"));

        // line 195
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("for" => ($context["id"] ?? $this->getContext($context, "id"))));
        // line 197
        $this->displayBlock("checkbox_radio_label", $context, $blocks);
        
        $__internal_4221771ccc72c9b8efff098d29a6574b23a4a4ae73ec5874f9020fd2d0e01fed->leave($__internal_4221771ccc72c9b8efff098d29a6574b23a4a4ae73ec5874f9020fd2d0e01fed_prof);

        
        $__internal_e140de5657be549bdce9d11645bfa55cbf9029417457488e3e321c659c3106e5->leave($__internal_e140de5657be549bdce9d11645bfa55cbf9029417457488e3e321c659c3106e5_prof);

    }

    // line 200
    public function block_checkbox_radio_label($context, array $blocks = array())
    {
        $__internal_6a81f0cb08cadd0042749fdb6065429b686fc8bb8df62cce9518a19cb39d3526 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6a81f0cb08cadd0042749fdb6065429b686fc8bb8df62cce9518a19cb39d3526->enter($__internal_6a81f0cb08cadd0042749fdb6065429b686fc8bb8df62cce9518a19cb39d3526_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        $__internal_b8165e2f01bbbd44d7498ada26e6bf5c10a90733df5d4647a1405e6b71434040 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8165e2f01bbbd44d7498ada26e6bf5c10a90733df5d4647a1405e6b71434040->enter($__internal_b8165e2f01bbbd44d7498ada26e6bf5c10a90733df5d4647a1405e6b71434040_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        // line 201
        echo "    ";
        // line 202
        echo "    ";
        if (array_key_exists("widget", $context)) {
            // line 203
            echo "        ";
            if (($context["required"] ?? $this->getContext($context, "required"))) {
                // line 204
                echo "            ";
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " required"))));
                // line 205
                echo "        ";
            }
            // line 206
            echo "        ";
            if (array_key_exists("parent_label_class", $context)) {
                // line 207
                echo "            ";
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter((((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " ") . ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class"))))));
                // line 208
                echo "        ";
            }
            // line 209
            echo "        ";
            if (( !(($context["label"] ?? $this->getContext($context, "label")) === false) && twig_test_empty(($context["label"] ?? $this->getContext($context, "label"))))) {
                // line 210
                if ( !twig_test_empty(($context["label_format"] ?? $this->getContext($context, "label_format")))) {
                    // line 211
                    $context["label"] = twig_replace_filter(($context["label_format"] ?? $this->getContext($context, "label_format")), array("%name%" =>                     // line 212
($context["name"] ?? $this->getContext($context, "name")), "%id%" =>                     // line 213
($context["id"] ?? $this->getContext($context, "id"))));
                } else {
                    // line 216
                    $context["label"] = $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->humanize(($context["name"] ?? $this->getContext($context, "name")));
                }
            }
            // line 219
            echo "        <label";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["label_attr"] ?? $this->getContext($context, "label_attr")));
            foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                echo " ";
                echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                echo "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">";
            // line 220
            echo ($context["widget"] ?? $this->getContext($context, "widget"));
            echo " ";
            echo twig_escape_filter($this->env, (( !(($context["label"] ?? $this->getContext($context, "label")) === false)) ? ((((($context["translation_domain"] ?? $this->getContext($context, "translation_domain")) === false)) ? (($context["label"] ?? $this->getContext($context, "label"))) : ($this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["label"] ?? $this->getContext($context, "label")), array(), ($context["translation_domain"] ?? $this->getContext($context, "translation_domain")))))) : ("")), "html", null, true);
            // line 221
            echo "</label>
    ";
        }
        
        $__internal_b8165e2f01bbbd44d7498ada26e6bf5c10a90733df5d4647a1405e6b71434040->leave($__internal_b8165e2f01bbbd44d7498ada26e6bf5c10a90733df5d4647a1405e6b71434040_prof);

        
        $__internal_6a81f0cb08cadd0042749fdb6065429b686fc8bb8df62cce9518a19cb39d3526->leave($__internal_6a81f0cb08cadd0042749fdb6065429b686fc8bb8df62cce9518a19cb39d3526_prof);

    }

    // line 227
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_f4cae32964ca6dad09189ca3b5391fff3e42750285d201f74cc0a14ec09d08ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f4cae32964ca6dad09189ca3b5391fff3e42750285d201f74cc0a14ec09d08ff->enter($__internal_f4cae32964ca6dad09189ca3b5391fff3e42750285d201f74cc0a14ec09d08ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_a6a14dadce309c098d6ca7f4b25167247a7a69050ea516897c4a9043748a5a00 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a6a14dadce309c098d6ca7f4b25167247a7a69050ea516897c4a9043748a5a00->enter($__internal_a6a14dadce309c098d6ca7f4b25167247a7a69050ea516897c4a9043748a5a00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 228
        echo "<div class=\"form-group";
        if ((( !($context["compound"] ?? $this->getContext($context, "compound")) || ((array_key_exists("force_error", $context)) ? (_twig_default_filter(($context["force_error"] ?? $this->getContext($context, "force_error")), false)) : (false))) &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            echo " has-error";
        }
        echo "\">";
        // line 229
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 230
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 231
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 232
        echo "</div>";
        
        $__internal_a6a14dadce309c098d6ca7f4b25167247a7a69050ea516897c4a9043748a5a00->leave($__internal_a6a14dadce309c098d6ca7f4b25167247a7a69050ea516897c4a9043748a5a00_prof);

        
        $__internal_f4cae32964ca6dad09189ca3b5391fff3e42750285d201f74cc0a14ec09d08ff->leave($__internal_f4cae32964ca6dad09189ca3b5391fff3e42750285d201f74cc0a14ec09d08ff_prof);

    }

    // line 235
    public function block_button_row($context, array $blocks = array())
    {
        $__internal_87ae190cefcb7dc699c8077f6f98e26ecaa9209f1c47208a0cc662f77a10b232 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_87ae190cefcb7dc699c8077f6f98e26ecaa9209f1c47208a0cc662f77a10b232->enter($__internal_87ae190cefcb7dc699c8077f6f98e26ecaa9209f1c47208a0cc662f77a10b232_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        $__internal_3634658105866bb6ef93fc136db77b284fc81516f72432fe1a7dcc8327a22c54 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3634658105866bb6ef93fc136db77b284fc81516f72432fe1a7dcc8327a22c54->enter($__internal_3634658105866bb6ef93fc136db77b284fc81516f72432fe1a7dcc8327a22c54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        // line 236
        echo "<div class=\"form-group\">";
        // line 237
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 238
        echo "</div>";
        
        $__internal_3634658105866bb6ef93fc136db77b284fc81516f72432fe1a7dcc8327a22c54->leave($__internal_3634658105866bb6ef93fc136db77b284fc81516f72432fe1a7dcc8327a22c54_prof);

        
        $__internal_87ae190cefcb7dc699c8077f6f98e26ecaa9209f1c47208a0cc662f77a10b232->leave($__internal_87ae190cefcb7dc699c8077f6f98e26ecaa9209f1c47208a0cc662f77a10b232_prof);

    }

    // line 241
    public function block_choice_row($context, array $blocks = array())
    {
        $__internal_388d1ace9388450aa4fa09cdeb53e332de29c42b1f3eca6e3655f253ab9a0db4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_388d1ace9388450aa4fa09cdeb53e332de29c42b1f3eca6e3655f253ab9a0db4->enter($__internal_388d1ace9388450aa4fa09cdeb53e332de29c42b1f3eca6e3655f253ab9a0db4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_row"));

        $__internal_ae36e738347dfe16c4c6ca3fc28dd1133f9d2761317d70ecf7c894fc1da579b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ae36e738347dfe16c4c6ca3fc28dd1133f9d2761317d70ecf7c894fc1da579b0->enter($__internal_ae36e738347dfe16c4c6ca3fc28dd1133f9d2761317d70ecf7c894fc1da579b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_row"));

        // line 242
        $context["force_error"] = true;
        // line 243
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_ae36e738347dfe16c4c6ca3fc28dd1133f9d2761317d70ecf7c894fc1da579b0->leave($__internal_ae36e738347dfe16c4c6ca3fc28dd1133f9d2761317d70ecf7c894fc1da579b0_prof);

        
        $__internal_388d1ace9388450aa4fa09cdeb53e332de29c42b1f3eca6e3655f253ab9a0db4->leave($__internal_388d1ace9388450aa4fa09cdeb53e332de29c42b1f3eca6e3655f253ab9a0db4_prof);

    }

    // line 246
    public function block_date_row($context, array $blocks = array())
    {
        $__internal_641f74822a5f4b3f1cf420abc6b8d4ead99d4b7fb7dd26b243164a05e048fc9e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_641f74822a5f4b3f1cf420abc6b8d4ead99d4b7fb7dd26b243164a05e048fc9e->enter($__internal_641f74822a5f4b3f1cf420abc6b8d4ead99d4b7fb7dd26b243164a05e048fc9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_row"));

        $__internal_ee67a9b8bed4884aef82b200f30bd4ab413c5eb66e189a44b8195842e9cf52b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee67a9b8bed4884aef82b200f30bd4ab413c5eb66e189a44b8195842e9cf52b4->enter($__internal_ee67a9b8bed4884aef82b200f30bd4ab413c5eb66e189a44b8195842e9cf52b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_row"));

        // line 247
        $context["force_error"] = true;
        // line 248
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_ee67a9b8bed4884aef82b200f30bd4ab413c5eb66e189a44b8195842e9cf52b4->leave($__internal_ee67a9b8bed4884aef82b200f30bd4ab413c5eb66e189a44b8195842e9cf52b4_prof);

        
        $__internal_641f74822a5f4b3f1cf420abc6b8d4ead99d4b7fb7dd26b243164a05e048fc9e->leave($__internal_641f74822a5f4b3f1cf420abc6b8d4ead99d4b7fb7dd26b243164a05e048fc9e_prof);

    }

    // line 251
    public function block_time_row($context, array $blocks = array())
    {
        $__internal_80cd102f6cddae10e3baec162aa451bd4b615e8325451b2dcae76c1163a18708 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_80cd102f6cddae10e3baec162aa451bd4b615e8325451b2dcae76c1163a18708->enter($__internal_80cd102f6cddae10e3baec162aa451bd4b615e8325451b2dcae76c1163a18708_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_row"));

        $__internal_eed4fa1a7dd1717e0d087fb728250dab80ab3aea1c62432c878422cc179394c9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eed4fa1a7dd1717e0d087fb728250dab80ab3aea1c62432c878422cc179394c9->enter($__internal_eed4fa1a7dd1717e0d087fb728250dab80ab3aea1c62432c878422cc179394c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_row"));

        // line 252
        $context["force_error"] = true;
        // line 253
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_eed4fa1a7dd1717e0d087fb728250dab80ab3aea1c62432c878422cc179394c9->leave($__internal_eed4fa1a7dd1717e0d087fb728250dab80ab3aea1c62432c878422cc179394c9_prof);

        
        $__internal_80cd102f6cddae10e3baec162aa451bd4b615e8325451b2dcae76c1163a18708->leave($__internal_80cd102f6cddae10e3baec162aa451bd4b615e8325451b2dcae76c1163a18708_prof);

    }

    // line 256
    public function block_datetime_row($context, array $blocks = array())
    {
        $__internal_06d6f72828f2dca354d0719a410619c161608d555d7612e35d0092e17b4b18ee = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_06d6f72828f2dca354d0719a410619c161608d555d7612e35d0092e17b4b18ee->enter($__internal_06d6f72828f2dca354d0719a410619c161608d555d7612e35d0092e17b4b18ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_row"));

        $__internal_6baa08acfd22b125486beb4eb886e8fd31d80fc01677f079ad5aa7939551dc16 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6baa08acfd22b125486beb4eb886e8fd31d80fc01677f079ad5aa7939551dc16->enter($__internal_6baa08acfd22b125486beb4eb886e8fd31d80fc01677f079ad5aa7939551dc16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_row"));

        // line 257
        $context["force_error"] = true;
        // line 258
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_6baa08acfd22b125486beb4eb886e8fd31d80fc01677f079ad5aa7939551dc16->leave($__internal_6baa08acfd22b125486beb4eb886e8fd31d80fc01677f079ad5aa7939551dc16_prof);

        
        $__internal_06d6f72828f2dca354d0719a410619c161608d555d7612e35d0092e17b4b18ee->leave($__internal_06d6f72828f2dca354d0719a410619c161608d555d7612e35d0092e17b4b18ee_prof);

    }

    // line 261
    public function block_checkbox_row($context, array $blocks = array())
    {
        $__internal_f9675b57d514cc3e3e3d3c371aab1f94e7fd253c36e4ebbd0c5a0882e9c14b2a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f9675b57d514cc3e3e3d3c371aab1f94e7fd253c36e4ebbd0c5a0882e9c14b2a->enter($__internal_f9675b57d514cc3e3e3d3c371aab1f94e7fd253c36e4ebbd0c5a0882e9c14b2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        $__internal_d3864b802ebb8cb1eda789f93079cd6511bbbeca87f1ff04561541ca56c5b3d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d3864b802ebb8cb1eda789f93079cd6511bbbeca87f1ff04561541ca56c5b3d5->enter($__internal_d3864b802ebb8cb1eda789f93079cd6511bbbeca87f1ff04561541ca56c5b3d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        // line 262
        echo "<div class=\"form-group";
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            echo " has-error";
        }
        echo "\">";
        // line 263
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 264
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 265
        echo "</div>";
        
        $__internal_d3864b802ebb8cb1eda789f93079cd6511bbbeca87f1ff04561541ca56c5b3d5->leave($__internal_d3864b802ebb8cb1eda789f93079cd6511bbbeca87f1ff04561541ca56c5b3d5_prof);

        
        $__internal_f9675b57d514cc3e3e3d3c371aab1f94e7fd253c36e4ebbd0c5a0882e9c14b2a->leave($__internal_f9675b57d514cc3e3e3d3c371aab1f94e7fd253c36e4ebbd0c5a0882e9c14b2a_prof);

    }

    // line 268
    public function block_radio_row($context, array $blocks = array())
    {
        $__internal_a89411b1205d03bc8847ea471788ed164ade64b5a4fdfc96244309ef3988d022 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a89411b1205d03bc8847ea471788ed164ade64b5a4fdfc96244309ef3988d022->enter($__internal_a89411b1205d03bc8847ea471788ed164ade64b5a4fdfc96244309ef3988d022_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_row"));

        $__internal_3f824dc9e0986693c299cad96af85e86c278d6fd1f21ac4f9e606f86609fa347 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3f824dc9e0986693c299cad96af85e86c278d6fd1f21ac4f9e606f86609fa347->enter($__internal_3f824dc9e0986693c299cad96af85e86c278d6fd1f21ac4f9e606f86609fa347_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_row"));

        // line 269
        echo "<div class=\"form-group";
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            echo " has-error";
        }
        echo "\">";
        // line 270
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 271
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 272
        echo "</div>";
        
        $__internal_3f824dc9e0986693c299cad96af85e86c278d6fd1f21ac4f9e606f86609fa347->leave($__internal_3f824dc9e0986693c299cad96af85e86c278d6fd1f21ac4f9e606f86609fa347_prof);

        
        $__internal_a89411b1205d03bc8847ea471788ed164ade64b5a4fdfc96244309ef3988d022->leave($__internal_a89411b1205d03bc8847ea471788ed164ade64b5a4fdfc96244309ef3988d022_prof);

    }

    // line 277
    public function block_form_errors($context, array $blocks = array())
    {
        $__internal_be0a88b0e020cbf2467d7cf7f8fdbc8ff57301b10fc291b88f704d4cbe10dd6f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_be0a88b0e020cbf2467d7cf7f8fdbc8ff57301b10fc291b88f704d4cbe10dd6f->enter($__internal_be0a88b0e020cbf2467d7cf7f8fdbc8ff57301b10fc291b88f704d4cbe10dd6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        $__internal_e636a66d51b331ac385072ee36a795b819ba3e4d2c4c53e8ad6301fd475e87a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e636a66d51b331ac385072ee36a795b819ba3e4d2c4c53e8ad6301fd475e87a8->enter($__internal_e636a66d51b331ac385072ee36a795b819ba3e4d2c4c53e8ad6301fd475e87a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        // line 278
        if ((twig_length_filter($this->env, ($context["errors"] ?? $this->getContext($context, "errors"))) > 0)) {
            // line 279
            if ($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) {
                echo "<span class=\"help-block\">";
            } else {
                echo "<div class=\"alert alert-danger\">";
            }
            // line 280
            echo "    <ul class=\"list-unstyled\">";
            // line 281
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["errors"] ?? $this->getContext($context, "errors")));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 282
                echo "<li><span class=\"glyphicon glyphicon-exclamation-sign\"></span> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
                echo "</li>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 284
            echo "</ul>
    ";
            // line 285
            if ($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) {
                echo "</span>";
            } else {
                echo "</div>";
            }
        }
        
        $__internal_e636a66d51b331ac385072ee36a795b819ba3e4d2c4c53e8ad6301fd475e87a8->leave($__internal_e636a66d51b331ac385072ee36a795b819ba3e4d2c4c53e8ad6301fd475e87a8_prof);

        
        $__internal_be0a88b0e020cbf2467d7cf7f8fdbc8ff57301b10fc291b88f704d4cbe10dd6f->leave($__internal_be0a88b0e020cbf2467d7cf7f8fdbc8ff57301b10fc291b88f704d4cbe10dd6f_prof);

    }

    public function getTemplateName()
    {
        return "bootstrap_3_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  1139 => 285,  1136 => 284,  1128 => 282,  1124 => 281,  1122 => 280,  1116 => 279,  1114 => 278,  1105 => 277,  1095 => 272,  1093 => 271,  1091 => 270,  1085 => 269,  1076 => 268,  1066 => 265,  1064 => 264,  1062 => 263,  1056 => 262,  1047 => 261,  1037 => 258,  1035 => 257,  1026 => 256,  1016 => 253,  1014 => 252,  1005 => 251,  995 => 248,  993 => 247,  984 => 246,  974 => 243,  972 => 242,  963 => 241,  953 => 238,  951 => 237,  949 => 236,  940 => 235,  930 => 232,  928 => 231,  926 => 230,  924 => 229,  918 => 228,  909 => 227,  897 => 221,  893 => 220,  878 => 219,  874 => 216,  871 => 213,  870 => 212,  869 => 211,  867 => 210,  864 => 209,  861 => 208,  858 => 207,  855 => 206,  852 => 205,  849 => 204,  846 => 203,  843 => 202,  841 => 201,  832 => 200,  822 => 197,  820 => 195,  811 => 194,  801 => 191,  799 => 189,  790 => 188,  780 => 185,  778 => 184,  769 => 182,  759 => 179,  757 => 178,  748 => 177,  737 => 171,  735 => 170,  733 => 169,  730 => 167,  728 => 166,  726 => 165,  717 => 164,  706 => 160,  704 => 159,  702 => 158,  699 => 156,  697 => 155,  695 => 154,  686 => 153,  675 => 149,  669 => 146,  668 => 145,  667 => 144,  663 => 143,  659 => 142,  652 => 138,  651 => 137,  650 => 136,  646 => 135,  644 => 134,  635 => 133,  625 => 130,  623 => 129,  614 => 128,  603 => 124,  599 => 123,  594 => 119,  588 => 118,  582 => 117,  576 => 116,  570 => 115,  564 => 114,  558 => 113,  552 => 112,  547 => 108,  541 => 107,  535 => 106,  529 => 105,  523 => 104,  517 => 103,  511 => 102,  505 => 101,  500 => 98,  497 => 97,  495 => 96,  491 => 95,  489 => 94,  486 => 92,  484 => 91,  475 => 90,  463 => 85,  460 => 84,  450 => 83,  445 => 81,  443 => 80,  441 => 79,  438 => 77,  436 => 76,  427 => 75,  415 => 70,  413 => 69,  411 => 67,  410 => 66,  409 => 65,  408 => 64,  403 => 62,  401 => 61,  399 => 60,  396 => 58,  394 => 57,  385 => 56,  374 => 52,  372 => 51,  370 => 50,  368 => 49,  366 => 48,  362 => 47,  360 => 46,  357 => 44,  355 => 43,  346 => 42,  335 => 38,  333 => 37,  331 => 36,  322 => 35,  312 => 32,  306 => 30,  304 => 29,  302 => 28,  296 => 26,  293 => 25,  291 => 24,  288 => 23,  279 => 22,  269 => 19,  267 => 18,  258 => 17,  248 => 14,  246 => 13,  237 => 12,  227 => 9,  224 => 7,  222 => 6,  213 => 5,  203 => 277,  200 => 276,  197 => 274,  195 => 268,  192 => 267,  190 => 261,  187 => 260,  185 => 256,  182 => 255,  180 => 251,  177 => 250,  175 => 246,  172 => 245,  170 => 241,  167 => 240,  165 => 235,  162 => 234,  160 => 227,  157 => 226,  154 => 224,  152 => 200,  149 => 199,  147 => 194,  144 => 193,  142 => 188,  139 => 187,  137 => 182,  134 => 181,  132 => 177,  129 => 176,  126 => 174,  124 => 164,  121 => 163,  119 => 153,  116 => 152,  114 => 133,  111 => 132,  109 => 128,  107 => 90,  105 => 75,  102 => 74,  100 => 56,  97 => 55,  95 => 42,  92 => 41,  90 => 35,  87 => 34,  85 => 22,  82 => 21,  80 => 17,  77 => 16,  75 => 12,  72 => 11,  70 => 5,  67 => 4,  64 => 2,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"form_div_layout.html.twig\" %}

{# Widgets #}

{% block form_widget_simple -%}
    {% if type is not defined or type not in ['file', 'hidden'] %}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) -%}
    {% endif %}
    {{- parent() -}}
{%- endblock form_widget_simple %}

{% block textarea_widget -%}
    {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) %}
    {{- parent() -}}
{%- endblock textarea_widget %}

{% block button_widget -%}
    {% set attr = attr|merge({class: (attr.class|default('btn-default') ~ ' btn')|trim}) %}
    {{- parent() -}}
{%- endblock %}

{% block money_widget -%}
    <div class=\"input-group\">
        {% set append = money_pattern starts with '{{' %}
        {% if not append %}
            <span class=\"input-group-addon\">{{ money_pattern|replace({ '{{ widget }}':''}) }}</span>
        {% endif %}
        {{- block('form_widget_simple') -}}
        {% if append %}
            <span class=\"input-group-addon\">{{ money_pattern|replace({ '{{ widget }}':''}) }}</span>
        {% endif %}
    </div>
{%- endblock money_widget %}

{% block percent_widget -%}
    <div class=\"input-group\">
        {{- block('form_widget_simple') -}}
        <span class=\"input-group-addon\">%</span>
    </div>
{%- endblock percent_widget %}

{% block datetime_widget -%}
    {% if widget == 'single_text' %}
        {{- block('form_widget_simple') -}}
    {% else -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        <div {{ block('widget_container_attributes') }}>
            {{- form_errors(form.date) -}}
            {{- form_errors(form.time) -}}
            {{- form_widget(form.date, { datetime: true } ) -}}
            {{- form_widget(form.time, { datetime: true } ) -}}
        </div>
    {%- endif %}
{%- endblock datetime_widget %}

{% block date_widget -%}
    {% if widget == 'single_text' %}
        {{- block('form_widget_simple') -}}
    {% else -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        {% if datetime is not defined or not datetime -%}
            <div {{ block('widget_container_attributes') -}}>
        {%- endif %}
            {{- date_pattern|replace({
                '{{ year }}': form_widget(form.year),
                '{{ month }}': form_widget(form.month),
                '{{ day }}': form_widget(form.day),
            })|raw -}}
        {% if datetime is not defined or not datetime -%}
            </div>
        {%- endif -%}
    {% endif %}
{%- endblock date_widget %}

{% block time_widget -%}
    {% if widget == 'single_text' %}
        {{- block('form_widget_simple') -}}
    {% else -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        {% if datetime is not defined or false == datetime -%}
            <div {{ block('widget_container_attributes') -}}>
        {%- endif -%}
        {{- form_widget(form.hour) }}{% if with_minutes %}:{{ form_widget(form.minute) }}{% endif %}{% if with_seconds %}:{{ form_widget(form.second) }}{% endif %}
        {% if datetime is not defined or false == datetime -%}
            </div>
        {%- endif -%}
    {% endif %}
{%- endblock time_widget %}

{%- block dateinterval_widget -%}
    {%- if widget == 'single_text' -%}
        {{- block('form_widget_simple') -}}
    {%- else -%}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        <div {{ block('widget_container_attributes') }}>
            {{- form_errors(form) -}}
            <div class=\"table-responsive\">
                <table class=\"table {{ table_class|default('table-bordered table-condensed table-striped') }}\">
                    <thead>
                    <tr>
                        {%- if with_years %}<th>{{ form_label(form.years) }}</th>{% endif -%}
                        {%- if with_months %}<th>{{ form_label(form.months) }}</th>{% endif -%}
                        {%- if with_weeks %}<th>{{ form_label(form.weeks) }}</th>{% endif -%}
                        {%- if with_days %}<th>{{ form_label(form.days) }}</th>{% endif -%}
                        {%- if with_hours %}<th>{{ form_label(form.hours) }}</th>{% endif -%}
                        {%- if with_minutes %}<th>{{ form_label(form.minutes) }}</th>{% endif -%}
                        {%- if with_seconds %}<th>{{ form_label(form.seconds) }}</th>{% endif -%}
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        {%- if with_years %}<td>{{ form_widget(form.years) }}</td>{% endif -%}
                        {%- if with_months %}<td>{{ form_widget(form.months) }}</td>{% endif -%}
                        {%- if with_weeks %}<td>{{ form_widget(form.weeks) }}</td>{% endif -%}
                        {%- if with_days %}<td>{{ form_widget(form.days) }}</td>{% endif -%}
                        {%- if with_hours %}<td>{{ form_widget(form.hours) }}</td>{% endif -%}
                        {%- if with_minutes %}<td>{{ form_widget(form.minutes) }}</td>{% endif -%}
                        {%- if with_seconds %}<td>{{ form_widget(form.seconds) }}</td>{% endif -%}
                    </tr>
                    </tbody>
                </table>
            </div>
            {%- if with_invert %}{{ form_widget(form.invert) }}{% endif -%}
        </div>
    {%- endif -%}
{%- endblock dateinterval_widget -%}

{% block choice_widget_collapsed -%}
    {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) %}
    {{- parent() -}}
{%- endblock %}

{% block choice_widget_expanded -%}
    {% if '-inline' in label_attr.class|default('') -%}
        {%- for child in form %}
            {{- form_widget(child, {
                parent_label_class: label_attr.class|default(''),
                translation_domain: choice_translation_domain,
            }) -}}
        {% endfor -%}
    {%- else -%}
        <div {{ block('widget_container_attributes') }}>
            {%- for child in form %}
                {{- form_widget(child, {
                    parent_label_class: label_attr.class|default(''),
                    translation_domain: choice_translation_domain,
                }) -}}
            {% endfor -%}
        </div>
    {%- endif %}
{%- endblock choice_widget_expanded %}

{% block checkbox_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {% if 'checkbox-inline' in parent_label_class %}
        {{- form_label(form, null, { widget: parent() }) -}}
    {% else -%}
        <div class=\"checkbox\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif %}
{%- endblock checkbox_widget %}

{% block radio_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {% if 'radio-inline' in parent_label_class %}
        {{- form_label(form, null, { widget: parent() }) -}}
    {% else -%}
        <div class=\"radio\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif %}
{%- endblock radio_widget %}

{# Labels #}

{% block form_label -%}
    {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' control-label')|trim}) -%}
    {{- parent() -}}
{%- endblock form_label %}

{% block choice_label -%}
    {# remove the checkbox-inline and radio-inline class, it's only useful for embed labels #}
    {%- set label_attr = label_attr|merge({class: label_attr.class|default('')|replace({'checkbox-inline': '', 'radio-inline': ''})|trim}) -%}
    {{- block('form_label') -}}
{% endblock %}

{% block checkbox_label -%}
    {%- set label_attr = label_attr|merge({'for': id}) -%}

    {{- block('checkbox_radio_label') -}}
{%- endblock checkbox_label %}

{% block radio_label -%}
    {%- set label_attr = label_attr|merge({'for': id}) -%}

    {{- block('checkbox_radio_label') -}}
{%- endblock radio_label %}

{% block checkbox_radio_label %}
    {# Do not display the label if widget is not defined in order to prevent double label rendering #}
    {% if widget is defined %}
        {% if required %}
            {% set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' required')|trim}) %}
        {% endif %}
        {% if parent_label_class is defined %}
            {% set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' ' ~ parent_label_class)|trim}) %}
        {% endif %}
        {% if label is not same as(false) and label is empty %}
            {%- if label_format is not empty -%}
                {% set label = label_format|replace({
                    '%name%': name,
                    '%id%': id,
                }) %}
            {%- else -%}
                {% set label = name|humanize %}
            {%- endif -%}
        {% endif %}
        <label{% for attrname, attrvalue in label_attr %} {{ attrname }}=\"{{ attrvalue }}\"{% endfor %}>
            {{- widget|raw }} {{ label is not same as(false) ? (translation_domain is same as(false) ? label : label|trans({}, translation_domain)) -}}
        </label>
    {% endif %}
{% endblock checkbox_radio_label %}

{# Rows #}

{% block form_row -%}
    <div class=\"form-group{% if (not compound or force_error|default(false)) and not valid %} has-error{% endif %}\">
        {{- form_label(form) -}}
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock form_row %}

{% block button_row -%}
    <div class=\"form-group\">
        {{- form_widget(form) -}}
    </div>
{%- endblock button_row %}

{% block choice_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock choice_row %}

{% block date_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock date_row %}

{% block time_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock time_row %}

{% block datetime_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock datetime_row %}

{% block checkbox_row -%}
    <div class=\"form-group{% if not valid %} has-error{% endif %}\">
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock checkbox_row %}

{% block radio_row -%}
    <div class=\"form-group{% if not valid %} has-error{% endif %}\">
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock radio_row %}

{# Errors #}

{% block form_errors -%}
    {% if errors|length > 0 -%}
    {% if form.parent %}<span class=\"help-block\">{% else %}<div class=\"alert alert-danger\">{% endif %}
    <ul class=\"list-unstyled\">
        {%- for error in errors -%}
            <li><span class=\"glyphicon glyphicon-exclamation-sign\"></span> {{ error.message }}</li>
        {%- endfor -%}
    </ul>
    {% if form.parent %}</span>{% else %}</div>{% endif %}
    {%- endif %}
{%- endblock form_errors %}
", "bootstrap_3_layout.html.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bridge/Twig/Resources/views/Form/bootstrap_3_layout.html.twig");
    }
}
