<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_f18539496f0d9c4be9c02f92141e3745c676badeb66460167f96768ca8a78e97 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b2af130e4db9fe0e2105fbca6d3321cec0b31d462a5882c161049ceae6e640b6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b2af130e4db9fe0e2105fbca6d3321cec0b31d462a5882c161049ceae6e640b6->enter($__internal_b2af130e4db9fe0e2105fbca6d3321cec0b31d462a5882c161049ceae6e640b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_98bbe7e89349589e59c3a60100de62cf83c12eb7a6c3e8197727985140b49b5d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_98bbe7e89349589e59c3a60100de62cf83c12eb7a6c3e8197727985140b49b5d->enter($__internal_98bbe7e89349589e59c3a60100de62cf83c12eb7a6c3e8197727985140b49b5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b2af130e4db9fe0e2105fbca6d3321cec0b31d462a5882c161049ceae6e640b6->leave($__internal_b2af130e4db9fe0e2105fbca6d3321cec0b31d462a5882c161049ceae6e640b6_prof);

        
        $__internal_98bbe7e89349589e59c3a60100de62cf83c12eb7a6c3e8197727985140b49b5d->leave($__internal_98bbe7e89349589e59c3a60100de62cf83c12eb7a6c3e8197727985140b49b5d_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_5cb1ef16180f3f5f0c0c5890d687dc98cf884aaff663090c4eb722515f36321c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5cb1ef16180f3f5f0c0c5890d687dc98cf884aaff663090c4eb722515f36321c->enter($__internal_5cb1ef16180f3f5f0c0c5890d687dc98cf884aaff663090c4eb722515f36321c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ebd41ee97ee42658a9363c85c74c9b9a88842c7b74db17c63b2681082a268072 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ebd41ee97ee42658a9363c85c74c9b9a88842c7b74db17c63b2681082a268072->enter($__internal_ebd41ee97ee42658a9363c85c74c9b9a88842c7b74db17c63b2681082a268072_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_ebd41ee97ee42658a9363c85c74c9b9a88842c7b74db17c63b2681082a268072->leave($__internal_ebd41ee97ee42658a9363c85c74c9b9a88842c7b74db17c63b2681082a268072_prof);

        
        $__internal_5cb1ef16180f3f5f0c0c5890d687dc98cf884aaff663090c4eb722515f36321c->leave($__internal_5cb1ef16180f3f5f0c0c5890d687dc98cf884aaff663090c4eb722515f36321c_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_c151a652d27c44eb1d64ec272a20a478c37e947e707953376a14f0de3c1f776d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c151a652d27c44eb1d64ec272a20a478c37e947e707953376a14f0de3c1f776d->enter($__internal_c151a652d27c44eb1d64ec272a20a478c37e947e707953376a14f0de3c1f776d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_5cdcee223d406aca6ccd27b962994a0b03b430c5c1c854003bcf46a6bb7340d7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5cdcee223d406aca6ccd27b962994a0b03b430c5c1c854003bcf46a6bb7340d7->enter($__internal_5cdcee223d406aca6ccd27b962994a0b03b430c5c1c854003bcf46a6bb7340d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_5cdcee223d406aca6ccd27b962994a0b03b430c5c1c854003bcf46a6bb7340d7->leave($__internal_5cdcee223d406aca6ccd27b962994a0b03b430c5c1c854003bcf46a6bb7340d7_prof);

        
        $__internal_c151a652d27c44eb1d64ec272a20a478c37e947e707953376a14f0de3c1f776d->leave($__internal_c151a652d27c44eb1d64ec272a20a478c37e947e707953376a14f0de3c1f776d_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
