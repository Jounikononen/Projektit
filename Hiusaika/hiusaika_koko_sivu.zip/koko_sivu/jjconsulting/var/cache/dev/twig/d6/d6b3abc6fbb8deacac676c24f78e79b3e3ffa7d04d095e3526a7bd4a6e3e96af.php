<?php

/* @Twig/images/icon-minus-square.svg */
class __TwigTemplate_9228406ce1a5ecf52e599125c760b25c6abd0561d3d4d3cba5e5cb7418fcc3f9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_83aa72e83e6eb5daec4939cc52f19059c655b6967cb101cd1444e8c43476ebca = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_83aa72e83e6eb5daec4939cc52f19059c655b6967cb101cd1444e8c43476ebca->enter($__internal_83aa72e83e6eb5daec4939cc52f19059c655b6967cb101cd1444e8c43476ebca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        $__internal_1407ac7ab75ee7de22bcf9bc7faab6edad85293e60611b9ee27d6492ecc56dce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1407ac7ab75ee7de22bcf9bc7faab6edad85293e60611b9ee27d6492ecc56dce->enter($__internal_1407ac7ab75ee7de22bcf9bc7faab6edad85293e60611b9ee27d6492ecc56dce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
";
        
        $__internal_83aa72e83e6eb5daec4939cc52f19059c655b6967cb101cd1444e8c43476ebca->leave($__internal_83aa72e83e6eb5daec4939cc52f19059c655b6967cb101cd1444e8c43476ebca_prof);

        
        $__internal_1407ac7ab75ee7de22bcf9bc7faab6edad85293e60611b9ee27d6492ecc56dce->leave($__internal_1407ac7ab75ee7de22bcf9bc7faab6edad85293e60611b9ee27d6492ecc56dce_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-minus-square.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
", "@Twig/images/icon-minus-square.svg", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/icon-minus-square.svg");
    }
}
