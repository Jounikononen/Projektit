<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_787089ed6c36761ccebd6fb06231cd794dcefea7adc17d4d0fe3d0491aa78466 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f77c1a994ab2e6a88f5bfdb057fd8b802c6d49cc312640af9fe8428d302e05b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f77c1a994ab2e6a88f5bfdb057fd8b802c6d49cc312640af9fe8428d302e05b4->enter($__internal_f77c1a994ab2e6a88f5bfdb057fd8b802c6d49cc312640af9fe8428d302e05b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        $__internal_2e05dd54f074d5e22c6f65570d827cb855e9fc180b29365ad6d558fa8f25efe7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e05dd54f074d5e22c6f65570d827cb855e9fc180b29365ad6d558fa8f25efe7->enter($__internal_2e05dd54f074d5e22c6f65570d827cb855e9fc180b29365ad6d558fa8f25efe7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_f77c1a994ab2e6a88f5bfdb057fd8b802c6d49cc312640af9fe8428d302e05b4->leave($__internal_f77c1a994ab2e6a88f5bfdb057fd8b802c6d49cc312640af9fe8428d302e05b4_prof);

        
        $__internal_2e05dd54f074d5e22c6f65570d827cb855e9fc180b29365ad6d558fa8f25efe7->leave($__internal_2e05dd54f074d5e22c6f65570d827cb855e9fc180b29365ad6d558fa8f25efe7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
", "@Framework/Form/submit_widget.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/submit_widget.html.php");
    }
}
