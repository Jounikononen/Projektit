<?php

/* FOSUserBundle:Profile:show_content.html.twig */
class __TwigTemplate_7532a25b7bd015949ff1b72cfd467d52577f2df895bbf480ed157d9eab8be78f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_303c01c6ed44e2dbb12cdd94fcf3a98fd3dd6fc85f2a7f6a91b8cbb28601ca43 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_303c01c6ed44e2dbb12cdd94fcf3a98fd3dd6fc85f2a7f6a91b8cbb28601ca43->enter($__internal_303c01c6ed44e2dbb12cdd94fcf3a98fd3dd6fc85f2a7f6a91b8cbb28601ca43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show_content.html.twig"));

        $__internal_d22a1c37b39b45591fc905ee5431f0afe15bb1b5d8a88fd9ddad360d5cf29520 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d22a1c37b39b45591fc905ee5431f0afe15bb1b5d8a88fd9ddad360d5cf29520->enter($__internal_d22a1c37b39b45591fc905ee5431f0afe15bb1b5d8a88fd9ddad360d5cf29520_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show_content.html.twig"));

        // line 2
        echo "
<div class=\"fos_user_user_show\">
    <p>";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("profile.show.username", array(), "FOSUserBundle"), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "username", array()), "html", null, true);
        echo "</p>
    <p>";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("profile.show.email", array(), "FOSUserBundle"), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "</p>
</div>
";
        
        $__internal_303c01c6ed44e2dbb12cdd94fcf3a98fd3dd6fc85f2a7f6a91b8cbb28601ca43->leave($__internal_303c01c6ed44e2dbb12cdd94fcf3a98fd3dd6fc85f2a7f6a91b8cbb28601ca43_prof);

        
        $__internal_d22a1c37b39b45591fc905ee5431f0afe15bb1b5d8a88fd9ddad360d5cf29520->leave($__internal_d22a1c37b39b45591fc905ee5431f0afe15bb1b5d8a88fd9ddad360d5cf29520_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  35 => 5,  29 => 4,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

<div class=\"fos_user_user_show\">
    <p>{{ 'profile.show.username'|trans }}: {{ user.username }}</p>
    <p>{{ 'profile.show.email'|trans }}: {{ user.email }}</p>
</div>
", "FOSUserBundle:Profile:show_content.html.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Profile/show_content.html.twig");
    }
}
