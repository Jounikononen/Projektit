<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_30a3d2496c30df3f1f110ab2c2a3335ef48434ae925967e4467a9ffced429227 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_00784ba8983c288deaacae8ab59b4aa716da4dc15d94aae8152dcf829cbef934 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_00784ba8983c288deaacae8ab59b4aa716da4dc15d94aae8152dcf829cbef934->enter($__internal_00784ba8983c288deaacae8ab59b4aa716da4dc15d94aae8152dcf829cbef934_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        $__internal_e1232d5ad2b61f3271c98d20bc37c9a43cd467d2a7a73dcfa859d148e4d75b37 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e1232d5ad2b61f3271c98d20bc37c9a43cd467d2a7a73dcfa859d148e4d75b37->enter($__internal_e1232d5ad2b61f3271c98d20bc37c9a43cd467d2a7a73dcfa859d148e4d75b37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_00784ba8983c288deaacae8ab59b4aa716da4dc15d94aae8152dcf829cbef934->leave($__internal_00784ba8983c288deaacae8ab59b4aa716da4dc15d94aae8152dcf829cbef934_prof);

        
        $__internal_e1232d5ad2b61f3271c98d20bc37c9a43cd467d2a7a73dcfa859d148e4d75b37->leave($__internal_e1232d5ad2b61f3271c98d20bc37c9a43cd467d2a7a73dcfa859d148e4d75b37_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
", "@Framework/Form/integer_widget.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/integer_widget.html.php");
    }
}
