<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_575e716ff07d06ccafcc9c1b88cb8e438c6a8527e495c48f9c3d8920d8372c31 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_22e9b0497296fc10f4cd2457766fe55518da86a6b4119534b0ce7b871daa39b1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_22e9b0497296fc10f4cd2457766fe55518da86a6b4119534b0ce7b871daa39b1->enter($__internal_22e9b0497296fc10f4cd2457766fe55518da86a6b4119534b0ce7b871daa39b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        $__internal_8a1f2efe5d135fb0e454980b88e65a38d1695bb148b7b8f5a92e912a08a6b685 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8a1f2efe5d135fb0e454980b88e65a38d1695bb148b7b8f5a92e912a08a6b685->enter($__internal_8a1f2efe5d135fb0e454980b88e65a38d1695bb148b7b8f5a92e912a08a6b685_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_22e9b0497296fc10f4cd2457766fe55518da86a6b4119534b0ce7b871daa39b1->leave($__internal_22e9b0497296fc10f4cd2457766fe55518da86a6b4119534b0ce7b871daa39b1_prof);

        
        $__internal_8a1f2efe5d135fb0e454980b88e65a38d1695bb148b7b8f5a92e912a08a6b685->leave($__internal_8a1f2efe5d135fb0e454980b88e65a38d1695bb148b7b8f5a92e912a08a6b685_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/search_widget.html.php");
    }
}
