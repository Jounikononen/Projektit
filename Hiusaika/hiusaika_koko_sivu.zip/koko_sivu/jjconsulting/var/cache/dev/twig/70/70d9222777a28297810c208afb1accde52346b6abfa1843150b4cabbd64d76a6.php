<?php

/* FOSUserBundle:Registration:confirmed.html.twig */
class __TwigTemplate_89a49ba899623b85ad14b171629b0ab51df1f3b990d311be3613b038bfac5445 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Registration:confirmed.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8db129fb892f61b3184d004228872d60c478094180811a7aacee21390392eca7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8db129fb892f61b3184d004228872d60c478094180811a7aacee21390392eca7->enter($__internal_8db129fb892f61b3184d004228872d60c478094180811a7aacee21390392eca7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:confirmed.html.twig"));

        $__internal_4b5bf6c350c477a58ebdadcec93dc935b78ff29c11d98d09b58aae180025e1f2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b5bf6c350c477a58ebdadcec93dc935b78ff29c11d98d09b58aae180025e1f2->enter($__internal_4b5bf6c350c477a58ebdadcec93dc935b78ff29c11d98d09b58aae180025e1f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:confirmed.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8db129fb892f61b3184d004228872d60c478094180811a7aacee21390392eca7->leave($__internal_8db129fb892f61b3184d004228872d60c478094180811a7aacee21390392eca7_prof);

        
        $__internal_4b5bf6c350c477a58ebdadcec93dc935b78ff29c11d98d09b58aae180025e1f2->leave($__internal_4b5bf6c350c477a58ebdadcec93dc935b78ff29c11d98d09b58aae180025e1f2_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f832444b2d474a9efd33f99d345ff843849043db39266c722d22b5bc2b3f7d8b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f832444b2d474a9efd33f99d345ff843849043db39266c722d22b5bc2b3f7d8b->enter($__internal_f832444b2d474a9efd33f99d345ff843849043db39266c722d22b5bc2b3f7d8b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_597f7524488e85e52be0a2bce4a3420f0e95d4f614f2588a1586f9892685c7e8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_597f7524488e85e52be0a2bce4a3420f0e95d4f614f2588a1586f9892685c7e8->enter($__internal_597f7524488e85e52be0a2bce4a3420f0e95d4f614f2588a1586f9892685c7e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.confirmed", array("%username%" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "username", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
    ";
        // line 7
        if (($context["targetUrl"] ?? $this->getContext($context, "targetUrl"))) {
            // line 8
            echo "    <p><a href=\"";
            echo twig_escape_filter($this->env, ($context["targetUrl"] ?? $this->getContext($context, "targetUrl")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.back", array(), "FOSUserBundle"), "html", null, true);
            echo "</a></p>
    ";
        }
        
        $__internal_597f7524488e85e52be0a2bce4a3420f0e95d4f614f2588a1586f9892685c7e8->leave($__internal_597f7524488e85e52be0a2bce4a3420f0e95d4f614f2588a1586f9892685c7e8_prof);

        
        $__internal_f832444b2d474a9efd33f99d345ff843849043db39266c722d22b5bc2b3f7d8b->leave($__internal_f832444b2d474a9efd33f99d345ff843849043db39266c722d22b5bc2b3f7d8b_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:confirmed.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 8,  54 => 7,  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}
    <p>{{ 'registration.confirmed'|trans({'%username%': user.username}) }}</p>
    {% if targetUrl %}
    <p><a href=\"{{ targetUrl }}\">{{ 'registration.back'|trans }}</a></p>
    {% endif %}
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:confirmed.html.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Registration/confirmed.html.twig");
    }
}
