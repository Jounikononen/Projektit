<?php

/* FOSUserBundle:Profile:edit.html.twig */
class __TwigTemplate_094c22034199487d466ea1bafdf3968b50ee7f3eed8da38837950d3e5baf2d0b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Profile:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b26d4f870fbb03139e078078b845c56a923364f003623639a5e001a046234b1d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b26d4f870fbb03139e078078b845c56a923364f003623639a5e001a046234b1d->enter($__internal_b26d4f870fbb03139e078078b845c56a923364f003623639a5e001a046234b1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit.html.twig"));

        $__internal_e308d766ad7c34f5292c984c7f5fc70542c8417823c7b72364bbb8aeed936a68 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e308d766ad7c34f5292c984c7f5fc70542c8417823c7b72364bbb8aeed936a68->enter($__internal_e308d766ad7c34f5292c984c7f5fc70542c8417823c7b72364bbb8aeed936a68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b26d4f870fbb03139e078078b845c56a923364f003623639a5e001a046234b1d->leave($__internal_b26d4f870fbb03139e078078b845c56a923364f003623639a5e001a046234b1d_prof);

        
        $__internal_e308d766ad7c34f5292c984c7f5fc70542c8417823c7b72364bbb8aeed936a68->leave($__internal_e308d766ad7c34f5292c984c7f5fc70542c8417823c7b72364bbb8aeed936a68_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_0f927a623c8b2fbb70aa32c9eb33998bab129a1f796902a4dd86d1367b43a2c7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0f927a623c8b2fbb70aa32c9eb33998bab129a1f796902a4dd86d1367b43a2c7->enter($__internal_0f927a623c8b2fbb70aa32c9eb33998bab129a1f796902a4dd86d1367b43a2c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_1cb992899676b6d3731ab978d7609a2623545a3128394bf5288d3c69726609f5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1cb992899676b6d3731ab978d7609a2623545a3128394bf5288d3c69726609f5->enter($__internal_1cb992899676b6d3731ab978d7609a2623545a3128394bf5288d3c69726609f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Profile/edit_content.html.twig", "FOSUserBundle:Profile:edit.html.twig", 4)->display($context);
        
        $__internal_1cb992899676b6d3731ab978d7609a2623545a3128394bf5288d3c69726609f5->leave($__internal_1cb992899676b6d3731ab978d7609a2623545a3128394bf5288d3c69726609f5_prof);

        
        $__internal_0f927a623c8b2fbb70aa32c9eb33998bab129a1f796902a4dd86d1367b43a2c7->leave($__internal_0f927a623c8b2fbb70aa32c9eb33998bab129a1f796902a4dd86d1367b43a2c7_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Profile/edit_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Profile:edit.html.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Profile/edit.html.twig");
    }
}
