<?php

/* @Framework/Form/widget_attributes.html.php */
class __TwigTemplate_6d2f3981d51a35336573228f70f297ce9c42de4a481b050b85e0f57782101121 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c423fa3ee0e5e0a3c3fcbdc25905a84b883a503d13cc51a36e0603c179c516ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c423fa3ee0e5e0a3c3fcbdc25905a84b883a503d13cc51a36e0603c179c516ff->enter($__internal_c423fa3ee0e5e0a3c3fcbdc25905a84b883a503d13cc51a36e0603c179c516ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        $__internal_baa345a8f483d015266b03da8ed1ce8704f6c747e909d46017a617268f14fbad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_baa345a8f483d015266b03da8ed1ce8704f6c747e909d46017a617268f14fbad->enter($__internal_baa345a8f483d015266b03da8ed1ce8704f6c747e909d46017a617268f14fbad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_c423fa3ee0e5e0a3c3fcbdc25905a84b883a503d13cc51a36e0603c179c516ff->leave($__internal_c423fa3ee0e5e0a3c3fcbdc25905a84b883a503d13cc51a36e0603c179c516ff_prof);

        
        $__internal_baa345a8f483d015266b03da8ed1ce8704f6c747e909d46017a617268f14fbad->leave($__internal_baa345a8f483d015266b03da8ed1ce8704f6c747e909d46017a617268f14fbad_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_attributes.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/widget_attributes.html.php");
    }
}
