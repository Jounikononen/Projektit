<?php

/* Default/index.html.twig */
class __TwigTemplate_c8ac9d21f5b4159d39e5898036db56ce0832ed4a55646b316865260669af6fbc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "Default/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_677259385aa545fc17e5acf3cb98e5a43db56f5042d8af18852e80f3c84a6e50 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_677259385aa545fc17e5acf3cb98e5a43db56f5042d8af18852e80f3c84a6e50->enter($__internal_677259385aa545fc17e5acf3cb98e5a43db56f5042d8af18852e80f3c84a6e50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Default/index.html.twig"));

        $__internal_e13defa63959e7413afb2bca75a986759f64b8a9a0ccf0fbc018a3ae39a262a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e13defa63959e7413afb2bca75a986759f64b8a9a0ccf0fbc018a3ae39a262a1->enter($__internal_e13defa63959e7413afb2bca75a986759f64b8a9a0ccf0fbc018a3ae39a262a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_677259385aa545fc17e5acf3cb98e5a43db56f5042d8af18852e80f3c84a6e50->leave($__internal_677259385aa545fc17e5acf3cb98e5a43db56f5042d8af18852e80f3c84a6e50_prof);

        
        $__internal_e13defa63959e7413afb2bca75a986759f64b8a9a0ccf0fbc018a3ae39a262a1->leave($__internal_e13defa63959e7413afb2bca75a986759f64b8a9a0ccf0fbc018a3ae39a262a1_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_0ca05a9dae934d38fd767756ad0053c55b464b0c4ddf17163a4fa561a1604dba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0ca05a9dae934d38fd767756ad0053c55b464b0c4ddf17163a4fa561a1604dba->enter($__internal_0ca05a9dae934d38fd767756ad0053c55b464b0c4ddf17163a4fa561a1604dba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_b5eb4f9057511a99de8b39cff668a3be31e8a4414ef842e8ec6e81fea106b4df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b5eb4f9057511a99de8b39cff668a3be31e8a4414ef842e8ec6e81fea106b4df->enter($__internal_b5eb4f9057511a99de8b39cff668a3be31e8a4414ef842e8ec6e81fea106b4df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Etusivu";
        
        $__internal_b5eb4f9057511a99de8b39cff668a3be31e8a4414ef842e8ec6e81fea106b4df->leave($__internal_b5eb4f9057511a99de8b39cff668a3be31e8a4414ef842e8ec6e81fea106b4df_prof);

        
        $__internal_0ca05a9dae934d38fd767756ad0053c55b464b0c4ddf17163a4fa561a1604dba->leave($__internal_0ca05a9dae934d38fd767756ad0053c55b464b0c4ddf17163a4fa561a1604dba_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_22e20e907521fa86b6d6c68ab5ae04a10189c2ae7c2ce8ee0a2b8c2b7d0a4c59 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_22e20e907521fa86b6d6c68ab5ae04a10189c2ae7c2ce8ee0a2b8c2b7d0a4c59->enter($__internal_22e20e907521fa86b6d6c68ab5ae04a10189c2ae7c2ce8ee0a2b8c2b7d0a4c59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f113555847f651a48d979ae199e13723dfcad26fb34e8a83d11e352fd16afaf4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f113555847f651a48d979ae199e13723dfcad26fb34e8a83d11e352fd16afaf4->enter($__internal_f113555847f651a48d979ae199e13723dfcad26fb34e8a83d11e352fd16afaf4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"jumbotron text-center\">
        <h2>Hae</h2>
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Company:searchBar", array("q" => null)));
        // line 10
        echo "
        <p><a href=\"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("searchCompany");
        echo "\" class=\"btn btn-default btn-md\">Näytä kaikki</a></p>
    </div>

    <div id=\"about\" class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-sm-8\">
                <h2>Tietoa meistä</h2><br>
                <h4>tekstiä</h4><br>
                <p>Lisää tekstiä</p>
                <br><a href=\"";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("about");
        echo "\"><button class=\"btn btn-default btn-lg\">Lue lisää</button></a>
            </div>
            <div class=\"col-sm-4\">
                <span class=\"glyphicon glyphicon-flag logo\"></span>
            </div>
        </div>
    </div>

    <div class=\"container-fluid text-center bg-grey\">

        <h2>Asiakkaittemme kommentteja</h2>
        <div id=\"myCarousel\" class=\"carousel slide text-center\" data-ride=\"carousel\">
            <!-- Indikaattorit -->
            <ol class=\"carousel-indicators\">
                <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>
                <li data-target=\"#myCarousel\" data-slide-to=\"1\"></li>
                <li data-target=\"#myCarousel\" data-slide-to=\"2\"></li>
            </ol>

            <!-- Kommentit karusellissa -->
            <div class=\"carousel-inner\" role=\"listbox\">
                <div class=\"item active\">
                    <h4>\"Ihan loistavat sivut!\"<br><span>Jaana, Mikkeli</span></h4>
                </div>
                <div class=\"item\">
                    <h4>\"Tälläistä nettisivua on kaivattu!\"<br><span>Joona, Lappeenranta</span></h4>
                </div>
                <div class=\"item\">
                    <h4>\"Hyvät sivut!\"<br><span>Jouni, Lappeenranta</span></h4>
                </div>
            </div>

            <a class=\"left carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"prev\">
                <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">takaisin</span>
            </a>
            <a class=\"right carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"next\">
                <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">Seuraava</span>
            </a>
        </div>
    </div>

    <div id=\"contact\" class=\"container-fluid\">
        <h2 class=\"text-center\">Lähetä palautetta</h2>
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <p>Vastaamme palautteisiin 24 tunnin kuluessa</p>
                <p><i class=\"fa fa-phone\" aria-hidden=\"true\"></i> 040 778 4649</p>
                <p><i class=\"fa fa-envelope\" aria-hidden=\"true\"></i> jouni.kononen@gmail.com</p>
            </div>
            <div class=\"col-sm-8 slideanim\">
                <div class=\"row\">
                    ";
        // line 73
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["contactForm"]) ? $context["contactForm"] : $this->getContext($context, "contactForm")), 'form_start');
        echo "
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 75
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["contactForm"]) ? $context["contactForm"] : $this->getContext($context, "contactForm")), "name", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 78
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["contactForm"]) ? $context["contactForm"] : $this->getContext($context, "contactForm")), "email", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-12 form-group\">
                        ";
        // line 81
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["contactForm"]) ? $context["contactForm"] : $this->getContext($context, "contactForm")), "message", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-12 form-group\">
                        ";
        // line 84
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["contactForm"]) ? $context["contactForm"] : $this->getContext($context, "contactForm")), "submit", array()), 'row');
        echo "
                    </div>
                    ";
        // line 86
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["contactForm"]) ? $context["contactForm"] : $this->getContext($context, "contactForm")), 'form_end');
        echo "
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_f113555847f651a48d979ae199e13723dfcad26fb34e8a83d11e352fd16afaf4->leave($__internal_f113555847f651a48d979ae199e13723dfcad26fb34e8a83d11e352fd16afaf4_prof);

        
        $__internal_22e20e907521fa86b6d6c68ab5ae04a10189c2ae7c2ce8ee0a2b8c2b7d0a4c59->leave($__internal_22e20e907521fa86b6d6c68ab5ae04a10189c2ae7c2ce8ee0a2b8c2b7d0a4c59_prof);

    }

    // line 93
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_46b03f9fb25376d3d226afa25cc8bb3eab9da637b34695d8aab08758a8e9d705 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_46b03f9fb25376d3d226afa25cc8bb3eab9da637b34695d8aab08758a8e9d705->enter($__internal_46b03f9fb25376d3d226afa25cc8bb3eab9da637b34695d8aab08758a8e9d705_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_08ecb8da891037472f2ba66f6a0bb1eb292ed1ac0ac5b646441c470b64765c52 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_08ecb8da891037472f2ba66f6a0bb1eb292ed1ac0ac5b646441c470b64765c52->enter($__internal_08ecb8da891037472f2ba66f6a0bb1eb292ed1ac0ac5b646441c470b64765c52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_08ecb8da891037472f2ba66f6a0bb1eb292ed1ac0ac5b646441c470b64765c52->leave($__internal_08ecb8da891037472f2ba66f6a0bb1eb292ed1ac0ac5b646441c470b64765c52_prof);

        
        $__internal_46b03f9fb25376d3d226afa25cc8bb3eab9da637b34695d8aab08758a8e9d705->leave($__internal_46b03f9fb25376d3d226afa25cc8bb3eab9da637b34695d8aab08758a8e9d705_prof);

    }

    // line 96
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_fcf680e9ffc318b426cd918dd5a79ea137935b60ac9866070c425d042d0a0ed8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fcf680e9ffc318b426cd918dd5a79ea137935b60ac9866070c425d042d0a0ed8->enter($__internal_fcf680e9ffc318b426cd918dd5a79ea137935b60ac9866070c425d042d0a0ed8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_e04f98766d576791cad3e5d185d840364de12ff573a47d9ed14e200a95c6f6c3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e04f98766d576791cad3e5d185d840364de12ff573a47d9ed14e200a95c6f6c3->enter($__internal_e04f98766d576791cad3e5d185d840364de12ff573a47d9ed14e200a95c6f6c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 97
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_e04f98766d576791cad3e5d185d840364de12ff573a47d9ed14e200a95c6f6c3->leave($__internal_e04f98766d576791cad3e5d185d840364de12ff573a47d9ed14e200a95c6f6c3_prof);

        
        $__internal_fcf680e9ffc318b426cd918dd5a79ea137935b60ac9866070c425d042d0a0ed8->leave($__internal_fcf680e9ffc318b426cd918dd5a79ea137935b60ac9866070c425d042d0a0ed8_prof);

    }

    public function getTemplateName()
    {
        return "Default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  218 => 97,  209 => 96,  192 => 93,  176 => 86,  171 => 84,  165 => 81,  159 => 78,  153 => 75,  148 => 73,  92 => 20,  80 => 11,  77 => 10,  75 => 7,  70 => 4,  61 => 3,  43 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block title %}Etusivu{% endblock %}
{% block body %}

    <div class=\"jumbotron text-center\">
        <h2>Hae</h2>
        {{ render(controller(
            'AppBundle:Company:searchBar',
            { 'q' : null }
        )) }}
        <p><a href=\"{{ path('searchCompany') }}\" class=\"btn btn-default btn-md\">Näytä kaikki</a></p>
    </div>

    <div id=\"about\" class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-sm-8\">
                <h2>Tietoa meistä</h2><br>
                <h4>tekstiä</h4><br>
                <p>Lisää tekstiä</p>
                <br><a href=\"{{ path('about') }}\"><button class=\"btn btn-default btn-lg\">Lue lisää</button></a>
            </div>
            <div class=\"col-sm-4\">
                <span class=\"glyphicon glyphicon-flag logo\"></span>
            </div>
        </div>
    </div>

    <div class=\"container-fluid text-center bg-grey\">

        <h2>Asiakkaittemme kommentteja</h2>
        <div id=\"myCarousel\" class=\"carousel slide text-center\" data-ride=\"carousel\">
            <!-- Indikaattorit -->
            <ol class=\"carousel-indicators\">
                <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>
                <li data-target=\"#myCarousel\" data-slide-to=\"1\"></li>
                <li data-target=\"#myCarousel\" data-slide-to=\"2\"></li>
            </ol>

            <!-- Kommentit karusellissa -->
            <div class=\"carousel-inner\" role=\"listbox\">
                <div class=\"item active\">
                    <h4>\"Ihan loistavat sivut!\"<br><span>Jaana, Mikkeli</span></h4>
                </div>
                <div class=\"item\">
                    <h4>\"Tälläistä nettisivua on kaivattu!\"<br><span>Joona, Lappeenranta</span></h4>
                </div>
                <div class=\"item\">
                    <h4>\"Hyvät sivut!\"<br><span>Jouni, Lappeenranta</span></h4>
                </div>
            </div>

            <a class=\"left carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"prev\">
                <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">takaisin</span>
            </a>
            <a class=\"right carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"next\">
                <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">Seuraava</span>
            </a>
        </div>
    </div>

    <div id=\"contact\" class=\"container-fluid\">
        <h2 class=\"text-center\">Lähetä palautetta</h2>
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <p>Vastaamme palautteisiin 24 tunnin kuluessa</p>
                <p><i class=\"fa fa-phone\" aria-hidden=\"true\"></i> 040 778 4649</p>
                <p><i class=\"fa fa-envelope\" aria-hidden=\"true\"></i> jouni.kononen@gmail.com</p>
            </div>
            <div class=\"col-sm-8 slideanim\">
                <div class=\"row\">
                    {{form_start(contactForm)}}
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(contactForm.name)}}
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(contactForm.email)}}
                    </div>
                    <div class=\"col-sm-12 form-group\">
                        {{form_row(contactForm.message)}}
                    </div>
                    <div class=\"col-sm-12 form-group\">
                        {{form_row(contactForm.submit)}}
                    </div>
                    {{form_end(contactForm)}}
                </div>
            </div>
        </div>
    </div>
{% endblock %}

{% block stylesheets %}
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
{% endblock %}
", "Default/index.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Default/index.html.twig");
    }
}
