<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_dffceffaa315031c6f08a7c62ce41de420e1eee9baecf98caf4cd708a1c2c066 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8680c62275e02e67e42e246d3f9e769770d21cb18284c9e9262684b2ba09c452 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8680c62275e02e67e42e246d3f9e769770d21cb18284c9e9262684b2ba09c452->enter($__internal_8680c62275e02e67e42e246d3f9e769770d21cb18284c9e9262684b2ba09c452_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        $__internal_c2f9220c23df221615c562481019384b26cd7056facecea81398dd407de2c2ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2f9220c23df221615c562481019384b26cd7056facecea81398dd407de2c2ff->enter($__internal_c2f9220c23df221615c562481019384b26cd7056facecea81398dd407de2c2ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_8680c62275e02e67e42e246d3f9e769770d21cb18284c9e9262684b2ba09c452->leave($__internal_8680c62275e02e67e42e246d3f9e769770d21cb18284c9e9262684b2ba09c452_prof);

        
        $__internal_c2f9220c23df221615c562481019384b26cd7056facecea81398dd407de2c2ff->leave($__internal_c2f9220c23df221615c562481019384b26cd7056facecea81398dd407de2c2ff_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
", "@Framework/Form/hidden_widget.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_widget.html.php");
    }
}
