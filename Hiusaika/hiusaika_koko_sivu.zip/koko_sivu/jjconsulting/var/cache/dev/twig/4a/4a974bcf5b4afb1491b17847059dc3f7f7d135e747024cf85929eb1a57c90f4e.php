<?php

/* :Admin:companyEdit.html.twig */
class __TwigTemplate_a3f232674f7ee30ecc09a9515160adc3957cc30b9ed3e661038c4ecfc7a75796 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Admin:companyEdit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6fb64046e1e56bff4439c6311b019500df3f68025931b14333d64f516654d724 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6fb64046e1e56bff4439c6311b019500df3f68025931b14333d64f516654d724->enter($__internal_6fb64046e1e56bff4439c6311b019500df3f68025931b14333d64f516654d724_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:companyEdit.html.twig"));

        $__internal_d8dbf071ca9440fcd0d2b3d9b44b23708df94c1ac898a352af1efed95564b93a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8dbf071ca9440fcd0d2b3d9b44b23708df94c1ac898a352af1efed95564b93a->enter($__internal_d8dbf071ca9440fcd0d2b3d9b44b23708df94c1ac898a352af1efed95564b93a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:companyEdit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6fb64046e1e56bff4439c6311b019500df3f68025931b14333d64f516654d724->leave($__internal_6fb64046e1e56bff4439c6311b019500df3f68025931b14333d64f516654d724_prof);

        
        $__internal_d8dbf071ca9440fcd0d2b3d9b44b23708df94c1ac898a352af1efed95564b93a->leave($__internal_d8dbf071ca9440fcd0d2b3d9b44b23708df94c1ac898a352af1efed95564b93a_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_0202b3c39d3db71826ab62976663f5b5a3653d5e49d7f3d79d2a6bcdfa5a7164 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0202b3c39d3db71826ab62976663f5b5a3653d5e49d7f3d79d2a6bcdfa5a7164->enter($__internal_0202b3c39d3db71826ab62976663f5b5a3653d5e49d7f3d79d2a6bcdfa5a7164_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_2cfc405e23f30f9cca87e309d6af38356f71fab5c3176f461b52dc30dacb7d4d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2cfc405e23f30f9cca87e309d6af38356f71fab5c3176f461b52dc30dacb7d4d->enter($__internal_2cfc405e23f30f9cca87e309d6af38356f71fab5c3176f461b52dc30dacb7d4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Yritykset tietojen muokkaus";
        
        $__internal_2cfc405e23f30f9cca87e309d6af38356f71fab5c3176f461b52dc30dacb7d4d->leave($__internal_2cfc405e23f30f9cca87e309d6af38356f71fab5c3176f461b52dc30dacb7d4d_prof);

        
        $__internal_0202b3c39d3db71826ab62976663f5b5a3653d5e49d7f3d79d2a6bcdfa5a7164->leave($__internal_0202b3c39d3db71826ab62976663f5b5a3653d5e49d7f3d79d2a6bcdfa5a7164_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_5027d21f01ea472fc1a153de6d4f9f9f0a3a339bb755fafa87370afae2ca1588 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5027d21f01ea472fc1a153de6d4f9f9f0a3a339bb755fafa87370afae2ca1588->enter($__internal_5027d21f01ea472fc1a153de6d4f9f9f0a3a339bb755fafa87370afae2ca1588_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_fef5d203579edd69d49bdf37f7f73253b2ebf59d48b2e6a97c7af3a3c9169091 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fef5d203579edd69d49bdf37f7f73253b2ebf59d48b2e6a97c7af3a3c9169091->enter($__internal_fef5d203579edd69d49bdf37f7f73253b2ebf59d48b2e6a97c7af3a3c9169091_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<div class=\"container-fluid bg-grey dashboard-company-info\">
    <div class=\"container\">
        <h2 class=\"text-center\">Yrityksen tiedot</h2>
        <div class=\"row\">
            ";
        // line 8
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
                <div class=\"col-sm-12\">
                    <div class=\"col-sm-12 checkbox-input\">
                        ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "user", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 14
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "name", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 17
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "vatId", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 20
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "address", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-2 form-group\">
                        ";
        // line 23
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "postcode", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-4 form-group\">
                        ";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "city", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 29
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "phone", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 32
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "email", array()), 'row');
        echo "
                    </div>
                </div>

                <h4 class=\"info-header\">Aukioloajat</h4>

                <div class=\"col-sm-6\">
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 40
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "openingHoursMonday", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 43
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "openingHoursTuesday", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 46
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "openingHoursWednesday", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 49
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "openingHoursThursday", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 52
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "openingHoursFriday", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 55
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "openingHoursSaturday", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 58
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "openingHoursSunday", array()), 'row');
        echo "
                    </div>
                </div>

                <div class=\"col-sm-6\">
                    <div class=\"col-sm-12 form-group\">
                        ";
        // line 64
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'row');
        echo "
                    </div>
                </div>

                <h4 class=\"info-header\">Palvelut ja hinnasto</h4>

                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        <div class=\"col-sm-6 form-group\">
                            <div>
                                <label for=\"default-service-add-name\">Palvelun nimi</label>
                                <select class=\"form-control\" id=\"default-service-add-name\">
                                    ";
        // line 76
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["defaultServices"] ?? $this->getContext($context, "defaultServices")));
        foreach ($context['_seq'] as $context["_key"] => $context["service"]) {
            // line 77
            echo "                                        <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["service"], "id", array()), "html", null, true);
            echo "\"
                                        ";
            // line 78
            if (twig_in_filter($this->getAttribute($context["service"], "id", array()), ($context["selectedDefaultServices"] ?? $this->getContext($context, "selectedDefaultServices")))) {
                // line 79
                echo "                                            disabled
                                        ";
            }
            // line 81
            echo "                                        >";
            echo twig_escape_filter($this->env, $this->getAttribute($context["service"], "name", array()), "html", null, true);
            echo "</option>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['service'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 83
        echo "                                </select>
                            </div>
                        </div>
                        <div class=\"col-sm-3 form-group\">
                            <div>
                                <label for=\"default-service-add-priceFrom\">Hinta</label>
                                <input type=\"text\" class=\"form-control\" id=\"default-service-add-priceFrom\">
                            </div>
                        </div>
                        <div class=\"col-sm-3 form-group\">
                            <div>
                                <label for=\"default-service-add-priceTo\">Hinta</label>
                                <input type=\"text\" class=\"form-control\" id=\"default-service-add-priceTo\">
                            </div>
                        </div>
                        <div class=\"col-sm-12 form-group\">
                            <a href=\"#\" id=\"add-default-service\" class=\"btn btn-default\"><i class=\"fa fa-plus\" aria-hidden=\"true\"></i> Lisää peruspalvelu</a>
                        </div>
                    </div>

                    <div class=\"col-sm-6\">
                        <div class=\"col-sm-12 form-group\">
                            <table class=\"table table-hover table-responsive\" id=\"selected-services\">
                                <thead>
                                    <tr>
                                        <th class=\"col-name\">Valitut palvelut</th>
                                        <th class=\"col-price\">Hinta</th>
                                        <th class=\"col-remove\">Poista</th>
                                    </tr>
                                </thead>
                                <tbody id=\"selected-default-services-collection\">
                                    ";
        // line 114
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "defaultServices", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["service"]) {
            // line 115
            echo "                                        <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "name", array()), "vars", array()), "value", array()), "html", null, true);
            echo "\">
                                            <td class=\"col-name\">
                                                ";
            // line 117
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "name", array()), "vars", array()), "data", array()), "name", array()), "html", null, true);
            echo "
                                                <input type=\"hidden\" id=\"";
            // line 118
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "name", array()), "vars", array()), "id", array()), "html", null, true);
            echo "\" 
                                                    name=\"";
            // line 119
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "name", array()), "vars", array()), "full_name", array()), "html", null, true);
            echo "\" 
                                                    value=\"";
            // line 120
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "name", array()), "vars", array()), "value", array()), "html", null, true);
            echo "\" />
                                                ";
            // line 121
            $this->getAttribute($context["service"], "setRendered", array());
            // line 122
            echo "                                                ";
            // line 123
            echo "                                            </td>
                                            <td class=\"col-price\">
                                                ";
            // line 125
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "priceFrom", array()), "vars", array()), "value", array()), "html", null, true);
            echo " ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($context["service"], "priceFrom", array()), 'row');
            echo "
                                                -
                                                ";
            // line 127
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "priceTo", array()), "vars", array()), "value", array()), "html", null, true);
            echo " ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($context["service"], "priceTo", array()), 'row');
            echo "
                                                €
                                            </td>
                                            <td class=\"col-remove\">
                                                <a class=\"default-service-remove\" href=\"#\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></a>
                                            </td>
                                        </tr>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['service'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 135
        echo "                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        <div class=\"col-sm-6 form-group\">
                            <div>
                                <label for=\"service-add-name\">Palvelun nimi</label>
                                <input type=\"text\" class=\"form-control\" id=\"service-add-name\">
                            </div>
                        </div>
                        <div class=\"col-sm-3 form-group\">
                            <div>
                                <label for=\"service-add-priceFrom\">Hinta</label>
                                <input type=\"text\" class=\"form-control\" id=\"service-add-priceFrom\">
                            </div>
                        </div>
                        <div class=\"col-sm-3 form-group\">
                            <div>
                                <label for=\"service-add-priceTo\">Hinta</label>
                                <input type=\"text\" class=\"form-control\" id=\"service-add-priceTo\">
                            </div>
                        </div>
                        <div class=\"col-sm-12 form-group\">
                            <a href=\"#\" id=\"add-service\" class=\"btn btn-default\"><i class=\"fa fa-plus\" aria-hidden=\"true\"></i> Lisää muu palvelu</a>
                        </div>
                    </div>

                    <div class=\"col-sm-6\">
                        <div class=\"col-sm-12 form-group\">
                            <table class=\"table table-hover table-responsive\" id=\"selected-services\">
                                <thead>
                                    <tr>
                                        <th class=\"col-name\">Muut palvelut</th>
                                        <th class=\"col-price\">Hinta</th>
                                        <th class=\"col-remove\">Poista</th>
                                    </tr>
                                </thead>
                                <tbody id=\"selected-services-collection\">
                                    ";
        // line 176
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "services", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["service"]) {
            // line 177
            echo "                                        <tr>
                                            <td class=\"col-name\">";
            // line 178
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "name", array()), "vars", array()), "value", array()), "html", null, true);
            echo " ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($context["service"], "name", array()), 'row');
            echo "</td>
                                            <td class=\"col-price\">
                                                ";
            // line 180
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "priceFrom", array()), "vars", array()), "value", array()), "html", null, true);
            echo " ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($context["service"], "priceFrom", array()), 'row');
            echo "
                                                -
                                                ";
            // line 182
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "priceTo", array()), "vars", array()), "value", array()), "html", null, true);
            echo " ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($context["service"], "priceTo", array()), 'row');
            echo "
                                                €
                                            </td>
                                            <td class=\"col-remove\">
                                                <a class=\"service-remove\" href=\"#\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></a>
                                            </td>
                                        </tr>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['service'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 190
        echo "                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class=\"col-sm-12\">
                    <div class=\"col-sm-12 form-group\">
                        ";
        // line 198
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "submit", array()), 'row');
        echo "
                    </div>
                </div>
            ";
        // line 201
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
        </div>
    </div>
</div>

";
        
        $__internal_fef5d203579edd69d49bdf37f7f73253b2ebf59d48b2e6a97c7af3a3c9169091->leave($__internal_fef5d203579edd69d49bdf37f7f73253b2ebf59d48b2e6a97c7af3a3c9169091_prof);

        
        $__internal_5027d21f01ea472fc1a153de6d4f9f9f0a3a339bb755fafa87370afae2ca1588->leave($__internal_5027d21f01ea472fc1a153de6d4f9f9f0a3a339bb755fafa87370afae2ca1588_prof);

    }

    // line 208
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e1d4fb2c133d9e2f5a8bdc7c1151d883ee12e06d7ec4d34b65cbcdcc79237b18 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e1d4fb2c133d9e2f5a8bdc7c1151d883ee12e06d7ec4d34b65cbcdcc79237b18->enter($__internal_e1d4fb2c133d9e2f5a8bdc7c1151d883ee12e06d7ec4d34b65cbcdcc79237b18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_10eb9a2a5bffc1c7a17a8ce9cd07f66e3f1f89ad792255d17dbc21254339d019 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_10eb9a2a5bffc1c7a17a8ce9cd07f66e3f1f89ad792255d17dbc21254339d019->enter($__internal_10eb9a2a5bffc1c7a17a8ce9cd07f66e3f1f89ad792255d17dbc21254339d019_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 209
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/dashboard.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
    <link href=\"";
        // line 210
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/admin.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
";
        
        $__internal_10eb9a2a5bffc1c7a17a8ce9cd07f66e3f1f89ad792255d17dbc21254339d019->leave($__internal_10eb9a2a5bffc1c7a17a8ce9cd07f66e3f1f89ad792255d17dbc21254339d019_prof);

        
        $__internal_e1d4fb2c133d9e2f5a8bdc7c1151d883ee12e06d7ec4d34b65cbcdcc79237b18->leave($__internal_e1d4fb2c133d9e2f5a8bdc7c1151d883ee12e06d7ec4d34b65cbcdcc79237b18_prof);

    }

    // line 213
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_704310d9cb4337acf28d96e9b787ca85cd7a27466be664cf7546747c4aafbdcd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_704310d9cb4337acf28d96e9b787ca85cd7a27466be664cf7546747c4aafbdcd->enter($__internal_704310d9cb4337acf28d96e9b787ca85cd7a27466be664cf7546747c4aafbdcd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_5b2c8960c07909798ee301a9e002476a221d9ea63f0b616d90365f581d23a06e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5b2c8960c07909798ee301a9e002476a221d9ea63f0b616d90365f581d23a06e->enter($__internal_5b2c8960c07909798ee301a9e002476a221d9ea63f0b616d90365f581d23a06e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 214
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 215
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/companyservicehandler.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_5b2c8960c07909798ee301a9e002476a221d9ea63f0b616d90365f581d23a06e->leave($__internal_5b2c8960c07909798ee301a9e002476a221d9ea63f0b616d90365f581d23a06e_prof);

        
        $__internal_704310d9cb4337acf28d96e9b787ca85cd7a27466be664cf7546747c4aafbdcd->leave($__internal_704310d9cb4337acf28d96e9b787ca85cd7a27466be664cf7546747c4aafbdcd_prof);

    }

    public function getTemplateName()
    {
        return ":Admin:companyEdit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  461 => 215,  456 => 214,  447 => 213,  435 => 210,  430 => 209,  421 => 208,  405 => 201,  399 => 198,  389 => 190,  373 => 182,  366 => 180,  359 => 178,  356 => 177,  352 => 176,  309 => 135,  293 => 127,  286 => 125,  282 => 123,  280 => 122,  278 => 121,  274 => 120,  270 => 119,  266 => 118,  262 => 117,  256 => 115,  252 => 114,  219 => 83,  210 => 81,  206 => 79,  204 => 78,  199 => 77,  195 => 76,  180 => 64,  171 => 58,  165 => 55,  159 => 52,  153 => 49,  147 => 46,  141 => 43,  135 => 40,  124 => 32,  118 => 29,  112 => 26,  106 => 23,  100 => 20,  94 => 17,  88 => 14,  82 => 11,  76 => 8,  70 => 4,  61 => 3,  43 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block title %}Yritykset tietojen muokkaus{% endblock %}
{% block body %}
<div class=\"container-fluid bg-grey dashboard-company-info\">
    <div class=\"container\">
        <h2 class=\"text-center\">Yrityksen tiedot</h2>
        <div class=\"row\">
            {{form_start(form)}}
                <div class=\"col-sm-12\">
                    <div class=\"col-sm-12 checkbox-input\">
                        {{form_row(form.user)}}
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(form.name)}}
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(form.vatId)}}
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(form.address)}}
                    </div>
                    <div class=\"col-sm-2 form-group\">
                        {{form_row(form.postcode)}}
                    </div>
                    <div class=\"col-sm-4 form-group\">
                        {{form_row(form.city)}}
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(form.phone)}}
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(form.email)}}
                    </div>
                </div>

                <h4 class=\"info-header\">Aukioloajat</h4>

                <div class=\"col-sm-6\">
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(form.openingHoursMonday)}}
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(form.openingHoursTuesday)}}
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(form.openingHoursWednesday)}}
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(form.openingHoursThursday)}}
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(form.openingHoursFriday)}}
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(form.openingHoursSaturday)}}
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(form.openingHoursSunday)}}
                    </div>
                </div>

                <div class=\"col-sm-6\">
                    <div class=\"col-sm-12 form-group\">
                        {{form_row(form.description)}}
                    </div>
                </div>

                <h4 class=\"info-header\">Palvelut ja hinnasto</h4>

                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        <div class=\"col-sm-6 form-group\">
                            <div>
                                <label for=\"default-service-add-name\">Palvelun nimi</label>
                                <select class=\"form-control\" id=\"default-service-add-name\">
                                    {% for service in defaultServices %}
                                        <option value=\"{{ service.id }}\"
                                        {% if service.id in selectedDefaultServices %}
                                            disabled
                                        {% endif %}
                                        >{{ service.name }}</option>
                                    {% endfor %}
                                </select>
                            </div>
                        </div>
                        <div class=\"col-sm-3 form-group\">
                            <div>
                                <label for=\"default-service-add-priceFrom\">Hinta</label>
                                <input type=\"text\" class=\"form-control\" id=\"default-service-add-priceFrom\">
                            </div>
                        </div>
                        <div class=\"col-sm-3 form-group\">
                            <div>
                                <label for=\"default-service-add-priceTo\">Hinta</label>
                                <input type=\"text\" class=\"form-control\" id=\"default-service-add-priceTo\">
                            </div>
                        </div>
                        <div class=\"col-sm-12 form-group\">
                            <a href=\"#\" id=\"add-default-service\" class=\"btn btn-default\"><i class=\"fa fa-plus\" aria-hidden=\"true\"></i> Lisää peruspalvelu</a>
                        </div>
                    </div>

                    <div class=\"col-sm-6\">
                        <div class=\"col-sm-12 form-group\">
                            <table class=\"table table-hover table-responsive\" id=\"selected-services\">
                                <thead>
                                    <tr>
                                        <th class=\"col-name\">Valitut palvelut</th>
                                        <th class=\"col-price\">Hinta</th>
                                        <th class=\"col-remove\">Poista</th>
                                    </tr>
                                </thead>
                                <tbody id=\"selected-default-services-collection\">
                                    {% for service in form.defaultServices %}
                                        <tr data-id=\"{{ service.name.vars.value }}\">
                                            <td class=\"col-name\">
                                                {{ service.name.vars.data.name }}
                                                <input type=\"hidden\" id=\"{{ service.name.vars.id }}\" 
                                                    name=\"{{ service.name.vars.full_name }}\" 
                                                    value=\"{{ service.name.vars.value }}\" />
                                                {% do service.setRendered %}
                                                {#{{ service.name.vars.value }} {{ form_row(service.name) }}#}
                                            </td>
                                            <td class=\"col-price\">
                                                {{ service.priceFrom.vars.value }} {{ form_row(service.priceFrom) }}
                                                -
                                                {{ service.priceTo.vars.value }} {{ form_row(service.priceTo) }}
                                                €
                                            </td>
                                            <td class=\"col-remove\">
                                                <a class=\"default-service-remove\" href=\"#\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></a>
                                            </td>
                                        </tr>
                                    {% endfor %}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        <div class=\"col-sm-6 form-group\">
                            <div>
                                <label for=\"service-add-name\">Palvelun nimi</label>
                                <input type=\"text\" class=\"form-control\" id=\"service-add-name\">
                            </div>
                        </div>
                        <div class=\"col-sm-3 form-group\">
                            <div>
                                <label for=\"service-add-priceFrom\">Hinta</label>
                                <input type=\"text\" class=\"form-control\" id=\"service-add-priceFrom\">
                            </div>
                        </div>
                        <div class=\"col-sm-3 form-group\">
                            <div>
                                <label for=\"service-add-priceTo\">Hinta</label>
                                <input type=\"text\" class=\"form-control\" id=\"service-add-priceTo\">
                            </div>
                        </div>
                        <div class=\"col-sm-12 form-group\">
                            <a href=\"#\" id=\"add-service\" class=\"btn btn-default\"><i class=\"fa fa-plus\" aria-hidden=\"true\"></i> Lisää muu palvelu</a>
                        </div>
                    </div>

                    <div class=\"col-sm-6\">
                        <div class=\"col-sm-12 form-group\">
                            <table class=\"table table-hover table-responsive\" id=\"selected-services\">
                                <thead>
                                    <tr>
                                        <th class=\"col-name\">Muut palvelut</th>
                                        <th class=\"col-price\">Hinta</th>
                                        <th class=\"col-remove\">Poista</th>
                                    </tr>
                                </thead>
                                <tbody id=\"selected-services-collection\">
                                    {% for service in form.services %}
                                        <tr>
                                            <td class=\"col-name\">{{ service.name.vars.value }} {{ form_row(service.name) }}</td>
                                            <td class=\"col-price\">
                                                {{ service.priceFrom.vars.value }} {{ form_row(service.priceFrom) }}
                                                -
                                                {{ service.priceTo.vars.value }} {{ form_row(service.priceTo) }}
                                                €
                                            </td>
                                            <td class=\"col-remove\">
                                                <a class=\"service-remove\" href=\"#\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></a>
                                            </td>
                                        </tr>
                                    {% endfor %}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class=\"col-sm-12\">
                    <div class=\"col-sm-12 form-group\">
                        {{form_row(form.submit)}}
                    </div>
                </div>
            {{form_end(form)}}
        </div>
    </div>
</div>

{% endblock %}

{% block stylesheets %}
    <link href=\"{{ asset('bundles/app/css/dashboard.css') }}\" rel=\"stylesheet\" />
    <link href=\"{{ asset('bundles/app/css/admin.css') }}\" rel=\"stylesheet\" />
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
    <script src=\"{{ asset('bundles/app/js/companyservicehandler.js') }}\"></script>
{% endblock %}
", ":Admin:companyEdit.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Admin/companyEdit.html.twig");
    }
}
