<?php

/* FOSUserBundle:ChangePassword:change_password_content.html.twig */
class __TwigTemplate_b47663a0b08ae893856c5913f98423988ef690e7b238f47c8c969ce0209c949d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ab29cd3e54cbdb9f29e9b3b0701c7bdff331024ca9fffc2087f8c7fddb81f9bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ab29cd3e54cbdb9f29e9b3b0701c7bdff331024ca9fffc2087f8c7fddb81f9bd->enter($__internal_ab29cd3e54cbdb9f29e9b3b0701c7bdff331024ca9fffc2087f8c7fddb81f9bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:ChangePassword:change_password_content.html.twig"));

        $__internal_67158eeb3fff3b2fed00a7cadbee5036629f6fe8edc6dac8c8de1d08c74dda0a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_67158eeb3fff3b2fed00a7cadbee5036629f6fe8edc6dac8c8de1d08c74dda0a->enter($__internal_67158eeb3fff3b2fed00a7cadbee5036629f6fe8edc6dac8c8de1d08c74dda0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:ChangePassword:change_password_content.html.twig"));

        // line 2
        echo "
<div class=\"container-fluid\" id=\"register-container\">
    <div class=\"container\">
        <h2 class=\"text-center\">Salasanan vaihto</h2>
        
        ";
        // line 7
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_change_password"), "attr" => array("class" => "fos_user_change_password")));
        echo "
        <div class=\"row\">
            <div class=\"col-md-6 col-md-offset-3\">
                <div class=\"form-group\">
                    ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "current_password", array()), 'label', array("label" => "Nykyinen salasana"));
        echo "
                    ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "current_password", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                    ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "current_password", array()), 'errors');
        echo "
                </div>
                <div class=\"form-group\">
                    ";
        // line 16
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "first", array()), 'label', array("label" => "Uusi salasana"));
        echo "
                    ";
        // line 17
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "first", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                    ";
        // line 18
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "first", array()), 'errors');
        echo "
                </div>
                <div class=\"form-group\">
                    ";
        // line 21
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "second", array()), 'label', array("label" => "Salasana uudelleen"));
        echo "
                    ";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "second", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                    ";
        // line 23
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "second", array()), 'errors');
        echo "
                </div>
            </div>
        </div>

        <div class=\"row\">
            <div class=\"col-sm-12 text-center\"> 
                <input type=\"submit\" value=\"Vaihda salasana\" class=\"btn btn-default login-button\" />
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-sm-12 text-center\"> 
                <a href=\"";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("dashboard");
        echo "\" class=\"btn btn-default\">Peruuta</a>
            </div>
        </div>
        ";
        // line 38
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
    </div>
</div>

";
        // line 42
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 45
        echo "
";
        // line 46
        $this->displayBlock('javascripts', $context, $blocks);
        
        $__internal_ab29cd3e54cbdb9f29e9b3b0701c7bdff331024ca9fffc2087f8c7fddb81f9bd->leave($__internal_ab29cd3e54cbdb9f29e9b3b0701c7bdff331024ca9fffc2087f8c7fddb81f9bd_prof);

        
        $__internal_67158eeb3fff3b2fed00a7cadbee5036629f6fe8edc6dac8c8de1d08c74dda0a->leave($__internal_67158eeb3fff3b2fed00a7cadbee5036629f6fe8edc6dac8c8de1d08c74dda0a_prof);

    }

    // line 42
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_87ce4b2e9ed11457d60275c9899e28f3f2924f81486d3fe0f2d58cd1362f96a4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_87ce4b2e9ed11457d60275c9899e28f3f2924f81486d3fe0f2d58cd1362f96a4->enter($__internal_87ce4b2e9ed11457d60275c9899e28f3f2924f81486d3fe0f2d58cd1362f96a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_fa82c26b4a32e20498dc2ec21e365e62bbfe13f5a35c082a52dda186616a7e01 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa82c26b4a32e20498dc2ec21e365e62bbfe13f5a35c082a52dda186616a7e01->enter($__internal_fa82c26b4a32e20498dc2ec21e365e62bbfe13f5a35c082a52dda186616a7e01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 43
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/security.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
";
        
        $__internal_fa82c26b4a32e20498dc2ec21e365e62bbfe13f5a35c082a52dda186616a7e01->leave($__internal_fa82c26b4a32e20498dc2ec21e365e62bbfe13f5a35c082a52dda186616a7e01_prof);

        
        $__internal_87ce4b2e9ed11457d60275c9899e28f3f2924f81486d3fe0f2d58cd1362f96a4->leave($__internal_87ce4b2e9ed11457d60275c9899e28f3f2924f81486d3fe0f2d58cd1362f96a4_prof);

    }

    // line 46
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_9b77deef9ace9d194dd1f266a2c4c3627c1ba9a7648fe6b7d5e7e2c3733a03cc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9b77deef9ace9d194dd1f266a2c4c3627c1ba9a7648fe6b7d5e7e2c3733a03cc->enter($__internal_9b77deef9ace9d194dd1f266a2c4c3627c1ba9a7648fe6b7d5e7e2c3733a03cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_d431ddff503817c5cc8e7bbf32a8f28033d5d6448eeb10b70faefcd8d773d803 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d431ddff503817c5cc8e7bbf32a8f28033d5d6448eeb10b70faefcd8d773d803->enter($__internal_d431ddff503817c5cc8e7bbf32a8f28033d5d6448eeb10b70faefcd8d773d803_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 47
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_d431ddff503817c5cc8e7bbf32a8f28033d5d6448eeb10b70faefcd8d773d803->leave($__internal_d431ddff503817c5cc8e7bbf32a8f28033d5d6448eeb10b70faefcd8d773d803_prof);

        
        $__internal_9b77deef9ace9d194dd1f266a2c4c3627c1ba9a7648fe6b7d5e7e2c3733a03cc->leave($__internal_9b77deef9ace9d194dd1f266a2c4c3627c1ba9a7648fe6b7d5e7e2c3733a03cc_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:ChangePassword:change_password_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  151 => 47,  142 => 46,  129 => 43,  120 => 42,  110 => 46,  107 => 45,  105 => 42,  98 => 38,  92 => 35,  77 => 23,  73 => 22,  69 => 21,  63 => 18,  59 => 17,  55 => 16,  49 => 13,  45 => 12,  41 => 11,  34 => 7,  27 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

<div class=\"container-fluid\" id=\"register-container\">
    <div class=\"container\">
        <h2 class=\"text-center\">Salasanan vaihto</h2>
        
        {{ form_start(form, { 'action': path('fos_user_change_password'), 'attr': { 'class': 'fos_user_change_password' } }) }}
        <div class=\"row\">
            <div class=\"col-md-6 col-md-offset-3\">
                <div class=\"form-group\">
                    {{ form_label(form.current_password, 'Nykyinen salasana') }}
                    {{ form_widget(form.current_password, {'attr': {'class': 'form-control'}}) }}
                    {{ form_errors(form.current_password) }}
                </div>
                <div class=\"form-group\">
                    {{ form_label(form.plainPassword.first, 'Uusi salasana') }}
                    {{ form_widget(form.plainPassword.first, {'attr': {'class': 'form-control'}}) }}
                    {{ form_errors(form.plainPassword.first) }}
                </div>
                <div class=\"form-group\">
                    {{ form_label(form.plainPassword.second, 'Salasana uudelleen') }}
                    {{ form_widget(form.plainPassword.second, {'attr': {'class': 'form-control'}}) }}
                    {{ form_errors(form.plainPassword.second) }}
                </div>
            </div>
        </div>

        <div class=\"row\">
            <div class=\"col-sm-12 text-center\"> 
                <input type=\"submit\" value=\"Vaihda salasana\" class=\"btn btn-default login-button\" />
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-sm-12 text-center\"> 
                <a href=\"{{ path('dashboard') }}\" class=\"btn btn-default\">Peruuta</a>
            </div>
        </div>
        {{ form_end(form) }}
    </div>
</div>

{% block stylesheets %}
    <link href=\"{{ asset('bundles/app/css/security.css') }}\" rel=\"stylesheet\" />
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
{% endblock %}
", "FOSUserBundle:ChangePassword:change_password_content.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/FOSUserBundle/views/ChangePassword/change_password_content.html.twig");
    }
}
