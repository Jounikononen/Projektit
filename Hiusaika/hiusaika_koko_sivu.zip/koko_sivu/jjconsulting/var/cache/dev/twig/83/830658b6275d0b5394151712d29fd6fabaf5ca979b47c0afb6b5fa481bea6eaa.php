<?php

/* @FOSUser/layout.html.twig */
class __TwigTemplate_c357e93b6e71822b54adba38c0009053aabccfbfce0febe87865118875e613fc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "@FOSUser/layout.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'fos_user_content' => array($this, 'block_fos_user_content'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3cf802377e7410d1a43ba0d1dac94087d18dd397ffda0c8bbee010d40152200e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3cf802377e7410d1a43ba0d1dac94087d18dd397ffda0c8bbee010d40152200e->enter($__internal_3cf802377e7410d1a43ba0d1dac94087d18dd397ffda0c8bbee010d40152200e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/layout.html.twig"));

        $__internal_34c4e4fefd47af7c2dbbf0cfb8f28470c5d67471d1af60de22ac887a8376f131 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_34c4e4fefd47af7c2dbbf0cfb8f28470c5d67471d1af60de22ac887a8376f131->enter($__internal_34c4e4fefd47af7c2dbbf0cfb8f28470c5d67471d1af60de22ac887a8376f131_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3cf802377e7410d1a43ba0d1dac94087d18dd397ffda0c8bbee010d40152200e->leave($__internal_3cf802377e7410d1a43ba0d1dac94087d18dd397ffda0c8bbee010d40152200e_prof);

        
        $__internal_34c4e4fefd47af7c2dbbf0cfb8f28470c5d67471d1af60de22ac887a8376f131->leave($__internal_34c4e4fefd47af7c2dbbf0cfb8f28470c5d67471d1af60de22ac887a8376f131_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_c83878114b880a3a69d39067329480e812e701a45bf3a18f2673af851878d568 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c83878114b880a3a69d39067329480e812e701a45bf3a18f2673af851878d568->enter($__internal_c83878114b880a3a69d39067329480e812e701a45bf3a18f2673af851878d568_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0cc540acf5c101440fed52b7ffa90bc056169e3f52a1c09b8112d138fcc4d8d0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0cc540acf5c101440fed52b7ffa90bc056169e3f52a1c09b8112d138fcc4d8d0->enter($__internal_0cc540acf5c101440fed52b7ffa90bc056169e3f52a1c09b8112d138fcc4d8d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        $this->displayBlock('fos_user_content', $context, $blocks);
        
        $__internal_0cc540acf5c101440fed52b7ffa90bc056169e3f52a1c09b8112d138fcc4d8d0->leave($__internal_0cc540acf5c101440fed52b7ffa90bc056169e3f52a1c09b8112d138fcc4d8d0_prof);

        
        $__internal_c83878114b880a3a69d39067329480e812e701a45bf3a18f2673af851878d568->leave($__internal_c83878114b880a3a69d39067329480e812e701a45bf3a18f2673af851878d568_prof);

    }

    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_ba935056276314b9aa14281d6d35170607c47752df752ce0e5ab43697847c9ea = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba935056276314b9aa14281d6d35170607c47752df752ce0e5ab43697847c9ea->enter($__internal_ba935056276314b9aa14281d6d35170607c47752df752ce0e5ab43697847c9ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_16e608fdabf881a4c830c575e11746fd432f455bf2e4d3401b04e2ce09d5c4ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_16e608fdabf881a4c830c575e11746fd432f455bf2e4d3401b04e2ce09d5c4ea->enter($__internal_16e608fdabf881a4c830c575e11746fd432f455bf2e4d3401b04e2ce09d5c4ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 5
        echo "    ";
        
        $__internal_16e608fdabf881a4c830c575e11746fd432f455bf2e4d3401b04e2ce09d5c4ea->leave($__internal_16e608fdabf881a4c830c575e11746fd432f455bf2e4d3401b04e2ce09d5c4ea_prof);

        
        $__internal_ba935056276314b9aa14281d6d35170607c47752df752ce0e5ab43697847c9ea->leave($__internal_ba935056276314b9aa14281d6d35170607c47752df752ce0e5ab43697847c9ea_prof);

    }

    // line 8
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_7e8a9e63629a75c2fa339aba51a9381420b0b7f16f03296217d26ab68c49ace7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7e8a9e63629a75c2fa339aba51a9381420b0b7f16f03296217d26ab68c49ace7->enter($__internal_7e8a9e63629a75c2fa339aba51a9381420b0b7f16f03296217d26ab68c49ace7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_6177f21f991ae2cb16cb53689046de0764878cf0e31d486d9fc3206e95688023 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6177f21f991ae2cb16cb53689046de0764878cf0e31d486d9fc3206e95688023->enter($__internal_6177f21f991ae2cb16cb53689046de0764878cf0e31d486d9fc3206e95688023_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 9
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_6177f21f991ae2cb16cb53689046de0764878cf0e31d486d9fc3206e95688023->leave($__internal_6177f21f991ae2cb16cb53689046de0764878cf0e31d486d9fc3206e95688023_prof);

        
        $__internal_7e8a9e63629a75c2fa339aba51a9381420b0b7f16f03296217d26ab68c49ace7->leave($__internal_7e8a9e63629a75c2fa339aba51a9381420b0b7f16f03296217d26ab68c49ace7_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 9,  80 => 8,  70 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    {% block fos_user_content %}
    {% endblock fos_user_content %}
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
{% endblock %}", "@FOSUser/layout.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/FOSUserBundle/views/layout.html.twig");
    }
}
