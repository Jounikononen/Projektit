<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_37014beb14ee17318afb478ffb6d509ae2d589e6a0068e235a9858b3d0d99d2d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_10704550a5a878440b9969454724898c48a1517ef4c288d189efd338d5df9d6d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_10704550a5a878440b9969454724898c48a1517ef4c288d189efd338d5df9d6d->enter($__internal_10704550a5a878440b9969454724898c48a1517ef4c288d189efd338d5df9d6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_6d4fbf64a32ed39a3de7725fa0d5fadba0097f968095386b0f2e254acfb5f222 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d4fbf64a32ed39a3de7725fa0d5fadba0097f968095386b0f2e254acfb5f222->enter($__internal_6d4fbf64a32ed39a3de7725fa0d5fadba0097f968095386b0f2e254acfb5f222_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_10704550a5a878440b9969454724898c48a1517ef4c288d189efd338d5df9d6d->leave($__internal_10704550a5a878440b9969454724898c48a1517ef4c288d189efd338d5df9d6d_prof);

        
        $__internal_6d4fbf64a32ed39a3de7725fa0d5fadba0097f968095386b0f2e254acfb5f222->leave($__internal_6d4fbf64a32ed39a3de7725fa0d5fadba0097f968095386b0f2e254acfb5f222_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/button_row.html.php");
    }
}
