<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_0aaca924a558c2ba1d3e2fff3eac8e4a822f296cfb77ba7e5b639f741528e7d3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_be758604f3ec1c384bdf593ae84802404df1709a8a8702e32155549be97d9c7e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_be758604f3ec1c384bdf593ae84802404df1709a8a8702e32155549be97d9c7e->enter($__internal_be758604f3ec1c384bdf593ae84802404df1709a8a8702e32155549be97d9c7e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        $__internal_ed073fc0a7fe8e2ed9a105b00b05f45de10a2f982ccfb7ba29d734c662422bb1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed073fc0a7fe8e2ed9a105b00b05f45de10a2f982ccfb7ba29d734c662422bb1->enter($__internal_ed073fc0a7fe8e2ed9a105b00b05f45de10a2f982ccfb7ba29d734c662422bb1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_be758604f3ec1c384bdf593ae84802404df1709a8a8702e32155549be97d9c7e->leave($__internal_be758604f3ec1c384bdf593ae84802404df1709a8a8702e32155549be97d9c7e_prof);

        
        $__internal_ed073fc0a7fe8e2ed9a105b00b05f45de10a2f982ccfb7ba29d734c662422bb1->leave($__internal_ed073fc0a7fe8e2ed9a105b00b05f45de10a2f982ccfb7ba29d734c662422bb1_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "TwigBundle:Exception:exception.css.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.css.twig");
    }
}
