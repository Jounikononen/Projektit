<?php

/* bootstrap_3_horizontal_layout.html.twig */
class __TwigTemplate_50a0be0d550758d5023c984934356164268c62dda22f1b752ba045eafef2e14a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("bootstrap_3_layout.html.twig", "bootstrap_3_horizontal_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."bootstrap_3_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'form_start' => array($this, 'block_form_start'),
                'form_label' => array($this, 'block_form_label'),
                'form_label_class' => array($this, 'block_form_label_class'),
                'form_row' => array($this, 'block_form_row'),
                'checkbox_row' => array($this, 'block_checkbox_row'),
                'radio_row' => array($this, 'block_radio_row'),
                'checkbox_radio_row' => array($this, 'block_checkbox_radio_row'),
                'submit_row' => array($this, 'block_submit_row'),
                'reset_row' => array($this, 'block_reset_row'),
                'form_group_class' => array($this, 'block_form_group_class'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_306726ec4393c38cb7b86ece634c7ef5184e98369cb59385cfadd20c7fe7786e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_306726ec4393c38cb7b86ece634c7ef5184e98369cb59385cfadd20c7fe7786e->enter($__internal_306726ec4393c38cb7b86ece634c7ef5184e98369cb59385cfadd20c7fe7786e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_horizontal_layout.html.twig"));

        $__internal_79db5c8eaff30c56c0c99c6a3aacc4a270dfd7d79ecd86113fa2dae228d1c961 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_79db5c8eaff30c56c0c99c6a3aacc4a270dfd7d79ecd86113fa2dae228d1c961->enter($__internal_79db5c8eaff30c56c0c99c6a3aacc4a270dfd7d79ecd86113fa2dae228d1c961_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_horizontal_layout.html.twig"));

        // line 2
        echo "
";
        // line 3
        $this->displayBlock('form_start', $context, $blocks);
        // line 7
        echo "
";
        // line 9
        echo "
";
        // line 10
        $this->displayBlock('form_label', $context, $blocks);
        // line 20
        echo "
";
        // line 21
        $this->displayBlock('form_label_class', $context, $blocks);
        // line 24
        echo "
";
        // line 26
        echo "
";
        // line 27
        $this->displayBlock('form_row', $context, $blocks);
        // line 36
        echo "
";
        // line 37
        $this->displayBlock('checkbox_row', $context, $blocks);
        // line 40
        echo "
";
        // line 41
        $this->displayBlock('radio_row', $context, $blocks);
        // line 44
        echo "
";
        // line 45
        $this->displayBlock('checkbox_radio_row', $context, $blocks);
        // line 56
        echo "
";
        // line 57
        $this->displayBlock('submit_row', $context, $blocks);
        // line 67
        echo "
";
        // line 68
        $this->displayBlock('reset_row', $context, $blocks);
        // line 78
        echo "
";
        // line 79
        $this->displayBlock('form_group_class', $context, $blocks);
        
        $__internal_306726ec4393c38cb7b86ece634c7ef5184e98369cb59385cfadd20c7fe7786e->leave($__internal_306726ec4393c38cb7b86ece634c7ef5184e98369cb59385cfadd20c7fe7786e_prof);

        
        $__internal_79db5c8eaff30c56c0c99c6a3aacc4a270dfd7d79ecd86113fa2dae228d1c961->leave($__internal_79db5c8eaff30c56c0c99c6a3aacc4a270dfd7d79ecd86113fa2dae228d1c961_prof);

    }

    // line 3
    public function block_form_start($context, array $blocks = array())
    {
        $__internal_80bdc51e105b9dec5d6a655057a62e3f8a2a371e31ff9e85aa699202b9c68728 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_80bdc51e105b9dec5d6a655057a62e3f8a2a371e31ff9e85aa699202b9c68728->enter($__internal_80bdc51e105b9dec5d6a655057a62e3f8a2a371e31ff9e85aa699202b9c68728_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_start"));

        $__internal_b8a618ba119cfbab16e6f2d610dea65635ffed710aa77b345743de39436e506b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8a618ba119cfbab16e6f2d610dea65635ffed710aa77b345743de39436e506b->enter($__internal_b8a618ba119cfbab16e6f2d610dea65635ffed710aa77b345743de39436e506b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_start"));

        // line 4
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-horizontal"))));
        // line 5
        $this->displayParentBlock("form_start", $context, $blocks);
        
        $__internal_b8a618ba119cfbab16e6f2d610dea65635ffed710aa77b345743de39436e506b->leave($__internal_b8a618ba119cfbab16e6f2d610dea65635ffed710aa77b345743de39436e506b_prof);

        
        $__internal_80bdc51e105b9dec5d6a655057a62e3f8a2a371e31ff9e85aa699202b9c68728->leave($__internal_80bdc51e105b9dec5d6a655057a62e3f8a2a371e31ff9e85aa699202b9c68728_prof);

    }

    // line 10
    public function block_form_label($context, array $blocks = array())
    {
        $__internal_ba244a557d9391aeffe3f8595e2088d8b5e6e531276a91d5a3bbd3f1556b726a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba244a557d9391aeffe3f8595e2088d8b5e6e531276a91d5a3bbd3f1556b726a->enter($__internal_ba244a557d9391aeffe3f8595e2088d8b5e6e531276a91d5a3bbd3f1556b726a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        $__internal_a4df77848bf93c856fd48adcff7439d946d77a59b4254fcbdfa331beb4df9b8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a4df77848bf93c856fd48adcff7439d946d77a59b4254fcbdfa331beb4df9b8d->enter($__internal_a4df77848bf93c856fd48adcff7439d946d77a59b4254fcbdfa331beb4df9b8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        // line 11
        ob_start();
        // line 12
        echo "    ";
        if ((($context["label"] ?? $this->getContext($context, "label")) === false)) {
            // line 13
            echo "        <div class=\"";
            $this->displayBlock("form_label_class", $context, $blocks);
            echo "\"></div>
    ";
        } else {
            // line 15
            echo "        ";
            $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter((((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " ") .             $this->renderBlock("form_label_class", $context, $blocks)))));
            // line 16
            $this->displayParentBlock("form_label", $context, $blocks);
        }
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_a4df77848bf93c856fd48adcff7439d946d77a59b4254fcbdfa331beb4df9b8d->leave($__internal_a4df77848bf93c856fd48adcff7439d946d77a59b4254fcbdfa331beb4df9b8d_prof);

        
        $__internal_ba244a557d9391aeffe3f8595e2088d8b5e6e531276a91d5a3bbd3f1556b726a->leave($__internal_ba244a557d9391aeffe3f8595e2088d8b5e6e531276a91d5a3bbd3f1556b726a_prof);

    }

    // line 21
    public function block_form_label_class($context, array $blocks = array())
    {
        $__internal_b4c50d7fc80777d204e01a75b7c53e86f36ac273b13beb6864d911b6283d2d57 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b4c50d7fc80777d204e01a75b7c53e86f36ac273b13beb6864d911b6283d2d57->enter($__internal_b4c50d7fc80777d204e01a75b7c53e86f36ac273b13beb6864d911b6283d2d57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label_class"));

        $__internal_4bd4dca0ce49bc92a5dfaf357750238882daf5ecaea96793b7f386267b1e815d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4bd4dca0ce49bc92a5dfaf357750238882daf5ecaea96793b7f386267b1e815d->enter($__internal_4bd4dca0ce49bc92a5dfaf357750238882daf5ecaea96793b7f386267b1e815d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label_class"));

        // line 22
        echo "col-sm-2";
        
        $__internal_4bd4dca0ce49bc92a5dfaf357750238882daf5ecaea96793b7f386267b1e815d->leave($__internal_4bd4dca0ce49bc92a5dfaf357750238882daf5ecaea96793b7f386267b1e815d_prof);

        
        $__internal_b4c50d7fc80777d204e01a75b7c53e86f36ac273b13beb6864d911b6283d2d57->leave($__internal_b4c50d7fc80777d204e01a75b7c53e86f36ac273b13beb6864d911b6283d2d57_prof);

    }

    // line 27
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_5920b233fde9be9aa3e99a69ca37c26904a0be70da7bd4565108d6ee8bcb98af = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5920b233fde9be9aa3e99a69ca37c26904a0be70da7bd4565108d6ee8bcb98af->enter($__internal_5920b233fde9be9aa3e99a69ca37c26904a0be70da7bd4565108d6ee8bcb98af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_8756f5115a8715ee66f6f399e5c0a9236941b7e3201a773b796a764b6ba10f4d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8756f5115a8715ee66f6f399e5c0a9236941b7e3201a773b796a764b6ba10f4d->enter($__internal_8756f5115a8715ee66f6f399e5c0a9236941b7e3201a773b796a764b6ba10f4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 28
        echo "<div class=\"form-group";
        if ((( !($context["compound"] ?? $this->getContext($context, "compound")) || ((array_key_exists("force_error", $context)) ? (_twig_default_filter(($context["force_error"] ?? $this->getContext($context, "force_error")), false)) : (false))) &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            echo " has-error";
        }
        echo "\">";
        // line 29
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 30
        echo "<div class=\"";
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">";
        // line 31
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 32
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 33
        echo "</div>
";
        // line 34
        echo "</div>";
        
        $__internal_8756f5115a8715ee66f6f399e5c0a9236941b7e3201a773b796a764b6ba10f4d->leave($__internal_8756f5115a8715ee66f6f399e5c0a9236941b7e3201a773b796a764b6ba10f4d_prof);

        
        $__internal_5920b233fde9be9aa3e99a69ca37c26904a0be70da7bd4565108d6ee8bcb98af->leave($__internal_5920b233fde9be9aa3e99a69ca37c26904a0be70da7bd4565108d6ee8bcb98af_prof);

    }

    // line 37
    public function block_checkbox_row($context, array $blocks = array())
    {
        $__internal_31a85e59e049eda5115196a90ac6c409c95b698648de162ef93f02741fb6aa4e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_31a85e59e049eda5115196a90ac6c409c95b698648de162ef93f02741fb6aa4e->enter($__internal_31a85e59e049eda5115196a90ac6c409c95b698648de162ef93f02741fb6aa4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        $__internal_48dcc409144373737c4d031facd1b54adef925aef6c8cef97235c27834982f67 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48dcc409144373737c4d031facd1b54adef925aef6c8cef97235c27834982f67->enter($__internal_48dcc409144373737c4d031facd1b54adef925aef6c8cef97235c27834982f67_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        // line 38
        $this->displayBlock("checkbox_radio_row", $context, $blocks);
        
        $__internal_48dcc409144373737c4d031facd1b54adef925aef6c8cef97235c27834982f67->leave($__internal_48dcc409144373737c4d031facd1b54adef925aef6c8cef97235c27834982f67_prof);

        
        $__internal_31a85e59e049eda5115196a90ac6c409c95b698648de162ef93f02741fb6aa4e->leave($__internal_31a85e59e049eda5115196a90ac6c409c95b698648de162ef93f02741fb6aa4e_prof);

    }

    // line 41
    public function block_radio_row($context, array $blocks = array())
    {
        $__internal_44fbe67898b1da96b22f8f1d8e4769690711785bd25e680d97f47b457d5e96d2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_44fbe67898b1da96b22f8f1d8e4769690711785bd25e680d97f47b457d5e96d2->enter($__internal_44fbe67898b1da96b22f8f1d8e4769690711785bd25e680d97f47b457d5e96d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_row"));

        $__internal_ddea8c0cb8a4966aee6c12d5a850d9d4807c6dbdfcfae62f5bf1adf3df7169a5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ddea8c0cb8a4966aee6c12d5a850d9d4807c6dbdfcfae62f5bf1adf3df7169a5->enter($__internal_ddea8c0cb8a4966aee6c12d5a850d9d4807c6dbdfcfae62f5bf1adf3df7169a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_row"));

        // line 42
        $this->displayBlock("checkbox_radio_row", $context, $blocks);
        
        $__internal_ddea8c0cb8a4966aee6c12d5a850d9d4807c6dbdfcfae62f5bf1adf3df7169a5->leave($__internal_ddea8c0cb8a4966aee6c12d5a850d9d4807c6dbdfcfae62f5bf1adf3df7169a5_prof);

        
        $__internal_44fbe67898b1da96b22f8f1d8e4769690711785bd25e680d97f47b457d5e96d2->leave($__internal_44fbe67898b1da96b22f8f1d8e4769690711785bd25e680d97f47b457d5e96d2_prof);

    }

    // line 45
    public function block_checkbox_radio_row($context, array $blocks = array())
    {
        $__internal_6cf5e07c87646242ddaca242bc4a6b1612545fa79e16e4d5fcde855290c70e73 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6cf5e07c87646242ddaca242bc4a6b1612545fa79e16e4d5fcde855290c70e73->enter($__internal_6cf5e07c87646242ddaca242bc4a6b1612545fa79e16e4d5fcde855290c70e73_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_row"));

        $__internal_4bbf26a726b14ecf4482523c8100a549c1089c8ae7a5681e60c3243e9cae7c86 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4bbf26a726b14ecf4482523c8100a549c1089c8ae7a5681e60c3243e9cae7c86->enter($__internal_4bbf26a726b14ecf4482523c8100a549c1089c8ae7a5681e60c3243e9cae7c86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_row"));

        // line 46
        ob_start();
        // line 47
        echo "    <div class=\"form-group";
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            echo " has-error";
        }
        echo "\">
        <div class=\"";
        // line 48
        $this->displayBlock("form_label_class", $context, $blocks);
        echo "\"></div>
        <div class=\"";
        // line 49
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">
            ";
        // line 50
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
            ";
        // line 51
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        echo "
        </div>
    </div>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_4bbf26a726b14ecf4482523c8100a549c1089c8ae7a5681e60c3243e9cae7c86->leave($__internal_4bbf26a726b14ecf4482523c8100a549c1089c8ae7a5681e60c3243e9cae7c86_prof);

        
        $__internal_6cf5e07c87646242ddaca242bc4a6b1612545fa79e16e4d5fcde855290c70e73->leave($__internal_6cf5e07c87646242ddaca242bc4a6b1612545fa79e16e4d5fcde855290c70e73_prof);

    }

    // line 57
    public function block_submit_row($context, array $blocks = array())
    {
        $__internal_87a92d89d60f4a8dab76a1046b7cb16441fdbc1145fe12c9e745f7320fe66be9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_87a92d89d60f4a8dab76a1046b7cb16441fdbc1145fe12c9e745f7320fe66be9->enter($__internal_87a92d89d60f4a8dab76a1046b7cb16441fdbc1145fe12c9e745f7320fe66be9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "submit_row"));

        $__internal_b2ef86d05c5fdb2989873bd53bac7b8cd994c159052c00aef6e5a9d5b0567ff7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2ef86d05c5fdb2989873bd53bac7b8cd994c159052c00aef6e5a9d5b0567ff7->enter($__internal_b2ef86d05c5fdb2989873bd53bac7b8cd994c159052c00aef6e5a9d5b0567ff7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "submit_row"));

        // line 58
        ob_start();
        // line 59
        echo "    <div class=\"form-group\">
        <div class=\"";
        // line 60
        $this->displayBlock("form_label_class", $context, $blocks);
        echo "\"></div>
        <div class=\"";
        // line 61
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">
            ";
        // line 62
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
        </div>
    </div>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_b2ef86d05c5fdb2989873bd53bac7b8cd994c159052c00aef6e5a9d5b0567ff7->leave($__internal_b2ef86d05c5fdb2989873bd53bac7b8cd994c159052c00aef6e5a9d5b0567ff7_prof);

        
        $__internal_87a92d89d60f4a8dab76a1046b7cb16441fdbc1145fe12c9e745f7320fe66be9->leave($__internal_87a92d89d60f4a8dab76a1046b7cb16441fdbc1145fe12c9e745f7320fe66be9_prof);

    }

    // line 68
    public function block_reset_row($context, array $blocks = array())
    {
        $__internal_9b302af7ccadae088fd48ff03813f8263cde17bcaabd2ab9a8686fbaf05c67c0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9b302af7ccadae088fd48ff03813f8263cde17bcaabd2ab9a8686fbaf05c67c0->enter($__internal_9b302af7ccadae088fd48ff03813f8263cde17bcaabd2ab9a8686fbaf05c67c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "reset_row"));

        $__internal_1eab25212e66b87413b8604c002654f44d04b42515da10b4bf7209f98ff73ec4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1eab25212e66b87413b8604c002654f44d04b42515da10b4bf7209f98ff73ec4->enter($__internal_1eab25212e66b87413b8604c002654f44d04b42515da10b4bf7209f98ff73ec4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "reset_row"));

        // line 69
        ob_start();
        // line 70
        echo "    <div class=\"form-group\">
        <div class=\"";
        // line 71
        $this->displayBlock("form_label_class", $context, $blocks);
        echo "\"></div>
        <div class=\"";
        // line 72
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">
            ";
        // line 73
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
        </div>
    </div>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_1eab25212e66b87413b8604c002654f44d04b42515da10b4bf7209f98ff73ec4->leave($__internal_1eab25212e66b87413b8604c002654f44d04b42515da10b4bf7209f98ff73ec4_prof);

        
        $__internal_9b302af7ccadae088fd48ff03813f8263cde17bcaabd2ab9a8686fbaf05c67c0->leave($__internal_9b302af7ccadae088fd48ff03813f8263cde17bcaabd2ab9a8686fbaf05c67c0_prof);

    }

    // line 79
    public function block_form_group_class($context, array $blocks = array())
    {
        $__internal_cf13199029811cdd5128782ad31fc419db533d02de1070455083af638ddc4346 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cf13199029811cdd5128782ad31fc419db533d02de1070455083af638ddc4346->enter($__internal_cf13199029811cdd5128782ad31fc419db533d02de1070455083af638ddc4346_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_group_class"));

        $__internal_0c2bbd39390d6d8cea2538ce649d924613a5f1595f4458736071b520ec7b1000 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0c2bbd39390d6d8cea2538ce649d924613a5f1595f4458736071b520ec7b1000->enter($__internal_0c2bbd39390d6d8cea2538ce649d924613a5f1595f4458736071b520ec7b1000_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_group_class"));

        // line 80
        echo "col-sm-10";
        
        $__internal_0c2bbd39390d6d8cea2538ce649d924613a5f1595f4458736071b520ec7b1000->leave($__internal_0c2bbd39390d6d8cea2538ce649d924613a5f1595f4458736071b520ec7b1000_prof);

        
        $__internal_cf13199029811cdd5128782ad31fc419db533d02de1070455083af638ddc4346->leave($__internal_cf13199029811cdd5128782ad31fc419db533d02de1070455083af638ddc4346_prof);

    }

    public function getTemplateName()
    {
        return "bootstrap_3_horizontal_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  390 => 80,  381 => 79,  366 => 73,  362 => 72,  358 => 71,  355 => 70,  353 => 69,  344 => 68,  329 => 62,  325 => 61,  321 => 60,  318 => 59,  316 => 58,  307 => 57,  292 => 51,  288 => 50,  284 => 49,  280 => 48,  273 => 47,  271 => 46,  262 => 45,  252 => 42,  243 => 41,  233 => 38,  224 => 37,  214 => 34,  211 => 33,  209 => 32,  207 => 31,  203 => 30,  201 => 29,  195 => 28,  186 => 27,  176 => 22,  167 => 21,  155 => 16,  152 => 15,  146 => 13,  143 => 12,  141 => 11,  132 => 10,  122 => 5,  120 => 4,  111 => 3,  101 => 79,  98 => 78,  96 => 68,  93 => 67,  91 => 57,  88 => 56,  86 => 45,  83 => 44,  81 => 41,  78 => 40,  76 => 37,  73 => 36,  71 => 27,  68 => 26,  65 => 24,  63 => 21,  60 => 20,  58 => 10,  55 => 9,  52 => 7,  50 => 3,  47 => 2,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"bootstrap_3_layout.html.twig\" %}

{% block form_start -%}
    {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-horizontal')|trim}) %}
    {{- parent() -}}
{%- endblock form_start %}

{# Labels #}

{% block form_label -%}
{% spaceless %}
    {% if label is same as(false) %}
        <div class=\"{{ block('form_label_class') }}\"></div>
    {% else %}
        {% set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' ' ~ block('form_label_class'))|trim}) %}
        {{- parent() -}}
    {% endif %}
{% endspaceless %}
{%- endblock form_label %}

{% block form_label_class -%}
col-sm-2
{%- endblock form_label_class %}

{# Rows #}

{% block form_row -%}
    <div class=\"form-group{% if (not compound or force_error|default(false)) and not valid %} has-error{% endif %}\">
        {{- form_label(form) -}}
        <div class=\"{{ block('form_group_class') }}\">
            {{- form_widget(form) -}}
            {{- form_errors(form) -}}
        </div>
{##}</div>
{%- endblock form_row %}

{% block checkbox_row -%}
    {{- block('checkbox_radio_row') -}}
{%- endblock checkbox_row %}

{% block radio_row -%}
    {{- block('checkbox_radio_row') -}}
{%- endblock radio_row %}

{% block checkbox_radio_row -%}
{% spaceless %}
    <div class=\"form-group{% if not valid %} has-error{% endif %}\">
        <div class=\"{{ block('form_label_class') }}\"></div>
        <div class=\"{{ block('form_group_class') }}\">
            {{ form_widget(form) }}
            {{ form_errors(form) }}
        </div>
    </div>
{% endspaceless %}
{%- endblock checkbox_radio_row %}

{% block submit_row -%}
{% spaceless %}
    <div class=\"form-group\">
        <div class=\"{{ block('form_label_class') }}\"></div>
        <div class=\"{{ block('form_group_class') }}\">
            {{ form_widget(form) }}
        </div>
    </div>
{% endspaceless %}
{% endblock submit_row %}

{% block reset_row -%}
{% spaceless %}
    <div class=\"form-group\">
        <div class=\"{{ block('form_label_class') }}\"></div>
        <div class=\"{{ block('form_group_class') }}\">
            {{ form_widget(form) }}
        </div>
    </div>
{% endspaceless %}
{% endblock reset_row %}

{% block form_group_class -%}
col-sm-10
{%- endblock form_group_class %}
", "bootstrap_3_horizontal_layout.html.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bridge/Twig/Resources/views/Form/bootstrap_3_horizontal_layout.html.twig");
    }
}
