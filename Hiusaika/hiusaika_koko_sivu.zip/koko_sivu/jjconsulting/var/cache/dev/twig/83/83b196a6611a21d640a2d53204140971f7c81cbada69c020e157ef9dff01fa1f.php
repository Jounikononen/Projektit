<?php

/* FOSUserBundle:Resetting:request.html.twig */
class __TwigTemplate_9f2579f6da48fa1545405ea10ae325e9754fa82c9456cc442dfec938dcbaa0b4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Resetting:request.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1bc5a47158fb7c939b75b3f0b16bafae4a726075404303425ef1af3a17f30b9c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1bc5a47158fb7c939b75b3f0b16bafae4a726075404303425ef1af3a17f30b9c->enter($__internal_1bc5a47158fb7c939b75b3f0b16bafae4a726075404303425ef1af3a17f30b9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $__internal_b56605e52009d7910901d0fac4afb31289f23d0060497435c718902356630743 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b56605e52009d7910901d0fac4afb31289f23d0060497435c718902356630743->enter($__internal_b56605e52009d7910901d0fac4afb31289f23d0060497435c718902356630743_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1bc5a47158fb7c939b75b3f0b16bafae4a726075404303425ef1af3a17f30b9c->leave($__internal_1bc5a47158fb7c939b75b3f0b16bafae4a726075404303425ef1af3a17f30b9c_prof);

        
        $__internal_b56605e52009d7910901d0fac4afb31289f23d0060497435c718902356630743->leave($__internal_b56605e52009d7910901d0fac4afb31289f23d0060497435c718902356630743_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_cb16e6dc8d1e9d29c1b72f224e13f3ae062781de69eb6d3a3a3f807e53b517d0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb16e6dc8d1e9d29c1b72f224e13f3ae062781de69eb6d3a3a3f807e53b517d0->enter($__internal_cb16e6dc8d1e9d29c1b72f224e13f3ae062781de69eb6d3a3a3f807e53b517d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_7be6dd5f5d27bcdd4d591f0107d235026042f2cc54a1a4ca66f4846051def42d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7be6dd5f5d27bcdd4d591f0107d235026042f2cc54a1a4ca66f4846051def42d->enter($__internal_7be6dd5f5d27bcdd4d591f0107d235026042f2cc54a1a4ca66f4846051def42d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Resetting/request_content.html.twig", "FOSUserBundle:Resetting:request.html.twig", 4)->display($context);
        
        $__internal_7be6dd5f5d27bcdd4d591f0107d235026042f2cc54a1a4ca66f4846051def42d->leave($__internal_7be6dd5f5d27bcdd4d591f0107d235026042f2cc54a1a4ca66f4846051def42d_prof);

        
        $__internal_cb16e6dc8d1e9d29c1b72f224e13f3ae062781de69eb6d3a3a3f807e53b517d0->leave($__internal_cb16e6dc8d1e9d29c1b72f224e13f3ae062781de69eb6d3a3a3f807e53b517d0_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Resetting/request_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Resetting:request.html.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Resetting/request.html.twig");
    }
}
