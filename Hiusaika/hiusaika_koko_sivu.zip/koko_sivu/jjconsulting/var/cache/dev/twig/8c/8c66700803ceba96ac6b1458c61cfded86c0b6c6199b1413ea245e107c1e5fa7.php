<?php

/* FOSUserBundle:Resetting:reset_content.html.twig */
class __TwigTemplate_0934b617afa1dd893482469b88bab21d25e6e2a69a104d60d6b186b119116c3a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_601ffae3529c40ed15aa0573cd927dab9cd468deae41fa2f321ce6321fb75035 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_601ffae3529c40ed15aa0573cd927dab9cd468deae41fa2f321ce6321fb75035->enter($__internal_601ffae3529c40ed15aa0573cd927dab9cd468deae41fa2f321ce6321fb75035_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset_content.html.twig"));

        $__internal_07dcbfab22d531eb37eaca2a284d544f31b887adc7ffd84f74f04671de34aa15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_07dcbfab22d531eb37eaca2a284d544f31b887adc7ffd84f74f04671de34aa15->enter($__internal_07dcbfab22d531eb37eaca2a284d544f31b887adc7ffd84f74f04671de34aa15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset_content.html.twig"));

        // line 2
        echo "
<div class=\"container-fluid\" id=\"register-container\">
    <div class=\"container\">
        <h2 class=\"text-center\">Salasanan palautus</h2>
        <h4 class=\"text-center\">Anna uusi salasana</h4>
        
        ";
        // line 8
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_resetting_reset", array("token" => ($context["token"] ?? $this->getContext($context, "token")))), "attr" => array("class" => "fos_user_resetting_reset")));
        echo "
        <div class=\"row\">
            <div class=\"col-md-6 col-md-offset-3\">
                <div class=\"form-group\">
                    ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "first", array()), 'label', array("label" => "Uusi salasana"));
        echo "
                    ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "first", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                    ";
        // line 14
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "first", array()), 'errors');
        echo "
                </div>
                <div class=\"form-group\">
                    ";
        // line 17
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "second", array()), 'label', array("label" => "Salasana uudelleen"));
        echo "
                    ";
        // line 18
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "second", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                    ";
        // line 19
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "second", array()), 'errors');
        echo "
                </div>
            </div>
        </div>

        <div class=\"row\">
            <div class=\"col-sm-12 text-center\"> 
                <input type=\"submit\" value=\"Vaihda salasana\" class=\"btn btn-default login-button\" />
            </div>
        </div>
        ";
        // line 29
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
    </div>
</div>

";
        // line 33
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 36
        echo "
";
        // line 37
        $this->displayBlock('javascripts', $context, $blocks);
        
        $__internal_601ffae3529c40ed15aa0573cd927dab9cd468deae41fa2f321ce6321fb75035->leave($__internal_601ffae3529c40ed15aa0573cd927dab9cd468deae41fa2f321ce6321fb75035_prof);

        
        $__internal_07dcbfab22d531eb37eaca2a284d544f31b887adc7ffd84f74f04671de34aa15->leave($__internal_07dcbfab22d531eb37eaca2a284d544f31b887adc7ffd84f74f04671de34aa15_prof);

    }

    // line 33
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ff434d0d429fc75755e5335b02a700d9577f99bd67ad4e7003c081bc90302b24 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff434d0d429fc75755e5335b02a700d9577f99bd67ad4e7003c081bc90302b24->enter($__internal_ff434d0d429fc75755e5335b02a700d9577f99bd67ad4e7003c081bc90302b24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_6607e38a8f1d9adea65ddbdb3eea52cbc382ed11e058136c24cab950b152a8c4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6607e38a8f1d9adea65ddbdb3eea52cbc382ed11e058136c24cab950b152a8c4->enter($__internal_6607e38a8f1d9adea65ddbdb3eea52cbc382ed11e058136c24cab950b152a8c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 34
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/security.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
";
        
        $__internal_6607e38a8f1d9adea65ddbdb3eea52cbc382ed11e058136c24cab950b152a8c4->leave($__internal_6607e38a8f1d9adea65ddbdb3eea52cbc382ed11e058136c24cab950b152a8c4_prof);

        
        $__internal_ff434d0d429fc75755e5335b02a700d9577f99bd67ad4e7003c081bc90302b24->leave($__internal_ff434d0d429fc75755e5335b02a700d9577f99bd67ad4e7003c081bc90302b24_prof);

    }

    // line 37
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_00f499b269f961253505f5a83629584fad8d1b76c35d74fbd2d4806bb46c653a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_00f499b269f961253505f5a83629584fad8d1b76c35d74fbd2d4806bb46c653a->enter($__internal_00f499b269f961253505f5a83629584fad8d1b76c35d74fbd2d4806bb46c653a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_a75c1afeb4138c3be7210f779798742889b2cfdc11200e74064dcd91db34755e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a75c1afeb4138c3be7210f779798742889b2cfdc11200e74064dcd91db34755e->enter($__internal_a75c1afeb4138c3be7210f779798742889b2cfdc11200e74064dcd91db34755e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 38
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_a75c1afeb4138c3be7210f779798742889b2cfdc11200e74064dcd91db34755e->leave($__internal_a75c1afeb4138c3be7210f779798742889b2cfdc11200e74064dcd91db34755e_prof);

        
        $__internal_00f499b269f961253505f5a83629584fad8d1b76c35d74fbd2d4806bb46c653a->leave($__internal_00f499b269f961253505f5a83629584fad8d1b76c35d74fbd2d4806bb46c653a_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:reset_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  130 => 38,  121 => 37,  108 => 34,  99 => 33,  89 => 37,  86 => 36,  84 => 33,  77 => 29,  64 => 19,  60 => 18,  56 => 17,  50 => 14,  46 => 13,  42 => 12,  35 => 8,  27 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

<div class=\"container-fluid\" id=\"register-container\">
    <div class=\"container\">
        <h2 class=\"text-center\">Salasanan palautus</h2>
        <h4 class=\"text-center\">Anna uusi salasana</h4>
        
        {{ form_start(form, { 'action': path('fos_user_resetting_reset', {'token': token}), 'attr': { 'class': 'fos_user_resetting_reset' } }) }}
        <div class=\"row\">
            <div class=\"col-md-6 col-md-offset-3\">
                <div class=\"form-group\">
                    {{ form_label(form.plainPassword.first, 'Uusi salasana') }}
                    {{ form_widget(form.plainPassword.first, {'attr': {'class': 'form-control'}}) }}
                    {{ form_errors(form.plainPassword.first) }}
                </div>
                <div class=\"form-group\">
                    {{ form_label(form.plainPassword.second, 'Salasana uudelleen') }}
                    {{ form_widget(form.plainPassword.second, {'attr': {'class': 'form-control'}}) }}
                    {{ form_errors(form.plainPassword.second) }}
                </div>
            </div>
        </div>

        <div class=\"row\">
            <div class=\"col-sm-12 text-center\"> 
                <input type=\"submit\" value=\"Vaihda salasana\" class=\"btn btn-default login-button\" />
            </div>
        </div>
        {{ form_end(form) }}
    </div>
</div>

{% block stylesheets %}
    <link href=\"{{ asset('bundles/app/css/security.css') }}\" rel=\"stylesheet\" />
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
{% endblock %}
", "FOSUserBundle:Resetting:reset_content.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/FOSUserBundle/views/Resetting/reset_content.html.twig");
    }
}
