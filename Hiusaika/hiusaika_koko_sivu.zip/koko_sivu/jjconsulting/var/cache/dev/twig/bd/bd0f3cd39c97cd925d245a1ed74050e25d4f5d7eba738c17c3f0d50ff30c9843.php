<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_f95014bfd92059699a6a57ebbeecb8a5c08d2fbab4f9bbcdc9edc50698e19b7f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a47b914cbea30108e84e31362d293ec0c908dc805602eee9d7fbfd6c187c7d6d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a47b914cbea30108e84e31362d293ec0c908dc805602eee9d7fbfd6c187c7d6d->enter($__internal_a47b914cbea30108e84e31362d293ec0c908dc805602eee9d7fbfd6c187c7d6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_eb934ca8c81e06bd8572ce38a3d7f0256a0c66a2ff6ef6024847f6a4bf1c0e1c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb934ca8c81e06bd8572ce38a3d7f0256a0c66a2ff6ef6024847f6a4bf1c0e1c->enter($__internal_eb934ca8c81e06bd8572ce38a3d7f0256a0c66a2ff6ef6024847f6a4bf1c0e1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_a47b914cbea30108e84e31362d293ec0c908dc805602eee9d7fbfd6c187c7d6d->leave($__internal_a47b914cbea30108e84e31362d293ec0c908dc805602eee9d7fbfd6c187c7d6d_prof);

        
        $__internal_eb934ca8c81e06bd8572ce38a3d7f0256a0c66a2ff6ef6024847f6a4bf1c0e1c->leave($__internal_eb934ca8c81e06bd8572ce38a3d7f0256a0c66a2ff6ef6024847f6a4bf1c0e1c_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_91a512bd7b38168688666dc423fc59d2702364133b953e0ba1bc348bb4f97601 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_91a512bd7b38168688666dc423fc59d2702364133b953e0ba1bc348bb4f97601->enter($__internal_91a512bd7b38168688666dc423fc59d2702364133b953e0ba1bc348bb4f97601_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_a468323d684360a0bc719b6d6bae8bf398ebc0f02dd7107bb34be4000ccfde27 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a468323d684360a0bc719b6d6bae8bf398ebc0f02dd7107bb34be4000ccfde27->enter($__internal_a468323d684360a0bc719b6d6bae8bf398ebc0f02dd7107bb34be4000ccfde27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_a468323d684360a0bc719b6d6bae8bf398ebc0f02dd7107bb34be4000ccfde27->leave($__internal_a468323d684360a0bc719b6d6bae8bf398ebc0f02dd7107bb34be4000ccfde27_prof);

        
        $__internal_91a512bd7b38168688666dc423fc59d2702364133b953e0ba1bc348bb4f97601->leave($__internal_91a512bd7b38168688666dc423fc59d2702364133b953e0ba1bc348bb4f97601_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
