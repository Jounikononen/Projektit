<?php

/* FOSUserBundle:Group:edit.html.twig */
class __TwigTemplate_f465cce4674dba3d7dcb6fecad3d94415edf7bb8870a88279129431b1141b242 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_59b5ea104dfd024d40044d2ecede73e6327715f773eb51f98fed0b002e56fbb5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_59b5ea104dfd024d40044d2ecede73e6327715f773eb51f98fed0b002e56fbb5->enter($__internal_59b5ea104dfd024d40044d2ecede73e6327715f773eb51f98fed0b002e56fbb5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $__internal_21a733e601489ee82e5ae2404a760fce36949de2cbf31e53636efcfc7e803a57 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_21a733e601489ee82e5ae2404a760fce36949de2cbf31e53636efcfc7e803a57->enter($__internal_21a733e601489ee82e5ae2404a760fce36949de2cbf31e53636efcfc7e803a57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_59b5ea104dfd024d40044d2ecede73e6327715f773eb51f98fed0b002e56fbb5->leave($__internal_59b5ea104dfd024d40044d2ecede73e6327715f773eb51f98fed0b002e56fbb5_prof);

        
        $__internal_21a733e601489ee82e5ae2404a760fce36949de2cbf31e53636efcfc7e803a57->leave($__internal_21a733e601489ee82e5ae2404a760fce36949de2cbf31e53636efcfc7e803a57_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_c4210e3139dbe6224527f98bc7ae60ad16cafb8c33912118b647306e313d6302 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c4210e3139dbe6224527f98bc7ae60ad16cafb8c33912118b647306e313d6302->enter($__internal_c4210e3139dbe6224527f98bc7ae60ad16cafb8c33912118b647306e313d6302_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_78bcee047d1ae76e3e6605b5d509c033e9c4a6ff6dc1d75ff4f05720aed817c7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78bcee047d1ae76e3e6605b5d509c033e9c4a6ff6dc1d75ff4f05720aed817c7->enter($__internal_78bcee047d1ae76e3e6605b5d509c033e9c4a6ff6dc1d75ff4f05720aed817c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/edit_content.html.twig", "FOSUserBundle:Group:edit.html.twig", 4)->display($context);
        
        $__internal_78bcee047d1ae76e3e6605b5d509c033e9c4a6ff6dc1d75ff4f05720aed817c7->leave($__internal_78bcee047d1ae76e3e6605b5d509c033e9c4a6ff6dc1d75ff4f05720aed817c7_prof);

        
        $__internal_c4210e3139dbe6224527f98bc7ae60ad16cafb8c33912118b647306e313d6302->leave($__internal_c4210e3139dbe6224527f98bc7ae60ad16cafb8c33912118b647306e313d6302_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/edit_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:edit.html.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Group/edit.html.twig");
    }
}
