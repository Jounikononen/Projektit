<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_9109b920d4391ece5c4aa472a19317b37d2b15efed7ef2118ce1dd9404077626 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9b99aa02801a29844a2abc6f9c5c65e31dbd39f08f89dfe87ae104cc1981ce23 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9b99aa02801a29844a2abc6f9c5c65e31dbd39f08f89dfe87ae104cc1981ce23->enter($__internal_9b99aa02801a29844a2abc6f9c5c65e31dbd39f08f89dfe87ae104cc1981ce23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        $__internal_58231a234a2b4405effd7ad98265b9705f68b658bbb841d5a8ba0a00dc05e6d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_58231a234a2b4405effd7ad98265b9705f68b658bbb841d5a8ba0a00dc05e6d2->enter($__internal_58231a234a2b4405effd7ad98265b9705f68b658bbb841d5a8ba0a00dc05e6d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_9b99aa02801a29844a2abc6f9c5c65e31dbd39f08f89dfe87ae104cc1981ce23->leave($__internal_9b99aa02801a29844a2abc6f9c5c65e31dbd39f08f89dfe87ae104cc1981ce23_prof);

        
        $__internal_58231a234a2b4405effd7ad98265b9705f68b658bbb841d5a8ba0a00dc05e6d2->leave($__internal_58231a234a2b4405effd7ad98265b9705f68b658bbb841d5a8ba0a00dc05e6d2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
", "@Framework/Form/form_widget_simple.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_widget_simple.html.php");
    }
}
