<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_eebbd5ba5ba17b583b5aac911697b4d76ac40cc9a08d367ca7b567d87fbd227c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f896192522fee847c9b5555004342ea0991e38748fdc6a02a3e19579ab0ad86b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f896192522fee847c9b5555004342ea0991e38748fdc6a02a3e19579ab0ad86b->enter($__internal_f896192522fee847c9b5555004342ea0991e38748fdc6a02a3e19579ab0ad86b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $__internal_db7c811fb9f8c6a1f45799d51f9c24d8f80d100a5396db77a29f6ab636b1dd30 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_db7c811fb9f8c6a1f45799d51f9c24d8f80d100a5396db77a29f6ab636b1dd30->enter($__internal_db7c811fb9f8c6a1f45799d51f9c24d8f80d100a5396db77a29f6ab636b1dd30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f896192522fee847c9b5555004342ea0991e38748fdc6a02a3e19579ab0ad86b->leave($__internal_f896192522fee847c9b5555004342ea0991e38748fdc6a02a3e19579ab0ad86b_prof);

        
        $__internal_db7c811fb9f8c6a1f45799d51f9c24d8f80d100a5396db77a29f6ab636b1dd30->leave($__internal_db7c811fb9f8c6a1f45799d51f9c24d8f80d100a5396db77a29f6ab636b1dd30_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_da4b2edd41efdad92a063e77318d7a8534a4c6d3afac67673b9d54ce5f839dd3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_da4b2edd41efdad92a063e77318d7a8534a4c6d3afac67673b9d54ce5f839dd3->enter($__internal_da4b2edd41efdad92a063e77318d7a8534a4c6d3afac67673b9d54ce5f839dd3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_472cc01f60ea81af9da1a01502f0a3b7ed5ec4f72709b8fd5823268f76c71a97 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_472cc01f60ea81af9da1a01502f0a3b7ed5ec4f72709b8fd5823268f76c71a97->enter($__internal_472cc01f60ea81af9da1a01502f0a3b7ed5ec4f72709b8fd5823268f76c71a97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Profile/show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 4)->display($context);
        
        $__internal_472cc01f60ea81af9da1a01502f0a3b7ed5ec4f72709b8fd5823268f76c71a97->leave($__internal_472cc01f60ea81af9da1a01502f0a3b7ed5ec4f72709b8fd5823268f76c71a97_prof);

        
        $__internal_da4b2edd41efdad92a063e77318d7a8534a4c6d3afac67673b9d54ce5f839dd3->leave($__internal_da4b2edd41efdad92a063e77318d7a8534a4c6d3afac67673b9d54ce5f839dd3_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Profile/show_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Profile:show.html.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Profile/show.html.twig");
    }
}
