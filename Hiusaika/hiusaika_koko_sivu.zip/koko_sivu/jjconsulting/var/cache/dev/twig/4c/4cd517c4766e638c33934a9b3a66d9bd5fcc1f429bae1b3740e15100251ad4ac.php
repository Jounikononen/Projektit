<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_0d378a620f7d1aabfa69d8c102b940f007114c05b92ae02598a0830c8650822f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_246a9e192323f5cc2c1290dbe1813dd2c3e25d77c4b7a3d2d21361abaf0cdd8e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_246a9e192323f5cc2c1290dbe1813dd2c3e25d77c4b7a3d2d21361abaf0cdd8e->enter($__internal_246a9e192323f5cc2c1290dbe1813dd2c3e25d77c4b7a3d2d21361abaf0cdd8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_70e74d903306c55d45e62baabd6b10b7140889332f67771c2fa687eaa140f907 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_70e74d903306c55d45e62baabd6b10b7140889332f67771c2fa687eaa140f907->enter($__internal_70e74d903306c55d45e62baabd6b10b7140889332f67771c2fa687eaa140f907_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_246a9e192323f5cc2c1290dbe1813dd2c3e25d77c4b7a3d2d21361abaf0cdd8e->leave($__internal_246a9e192323f5cc2c1290dbe1813dd2c3e25d77c4b7a3d2d21361abaf0cdd8e_prof);

        
        $__internal_70e74d903306c55d45e62baabd6b10b7140889332f67771c2fa687eaa140f907->leave($__internal_70e74d903306c55d45e62baabd6b10b7140889332f67771c2fa687eaa140f907_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_dc59d2ac94acc71a9b7f40a635ef7f3734328f65f7ee6930adf1eab5669de1a5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dc59d2ac94acc71a9b7f40a635ef7f3734328f65f7ee6930adf1eab5669de1a5->enter($__internal_dc59d2ac94acc71a9b7f40a635ef7f3734328f65f7ee6930adf1eab5669de1a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_5871e59226e2475dfe04d9a779518eb0d1d84ec9eae5ec51852dd06444086460 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5871e59226e2475dfe04d9a779518eb0d1d84ec9eae5ec51852dd06444086460->enter($__internal_5871e59226e2475dfe04d9a779518eb0d1d84ec9eae5ec51852dd06444086460_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_5871e59226e2475dfe04d9a779518eb0d1d84ec9eae5ec51852dd06444086460->leave($__internal_5871e59226e2475dfe04d9a779518eb0d1d84ec9eae5ec51852dd06444086460_prof);

        
        $__internal_dc59d2ac94acc71a9b7f40a635ef7f3734328f65f7ee6930adf1eab5669de1a5->leave($__internal_dc59d2ac94acc71a9b7f40a635ef7f3734328f65f7ee6930adf1eab5669de1a5_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_942671edcaaf76ca1e724e690429f9f72020d007e3a6f9526f1873b5c2e281cc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_942671edcaaf76ca1e724e690429f9f72020d007e3a6f9526f1873b5c2e281cc->enter($__internal_942671edcaaf76ca1e724e690429f9f72020d007e3a6f9526f1873b5c2e281cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_4007e32c9300532742c37f7882323bc93addf139ffda83ba54e3c160c4ae85e4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4007e32c9300532742c37f7882323bc93addf139ffda83ba54e3c160c4ae85e4->enter($__internal_4007e32c9300532742c37f7882323bc93addf139ffda83ba54e3c160c4ae85e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_4007e32c9300532742c37f7882323bc93addf139ffda83ba54e3c160c4ae85e4->leave($__internal_4007e32c9300532742c37f7882323bc93addf139ffda83ba54e3c160c4ae85e4_prof);

        
        $__internal_942671edcaaf76ca1e724e690429f9f72020d007e3a6f9526f1873b5c2e281cc->leave($__internal_942671edcaaf76ca1e724e690429f9f72020d007e3a6f9526f1873b5c2e281cc_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
