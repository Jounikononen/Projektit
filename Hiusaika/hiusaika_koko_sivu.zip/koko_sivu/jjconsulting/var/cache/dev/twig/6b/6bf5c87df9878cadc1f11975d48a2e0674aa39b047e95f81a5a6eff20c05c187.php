<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_59129d80fe58a51e3fdefa2f9386d9ea6995e07287c843b162a13b647b5ff108 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a0a17e729a235d53751ac1b371be09e066c0a38af8dbfd064a06342ad4338342 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a0a17e729a235d53751ac1b371be09e066c0a38af8dbfd064a06342ad4338342->enter($__internal_a0a17e729a235d53751ac1b371be09e066c0a38af8dbfd064a06342ad4338342_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        $__internal_3994b27d6ccda8b553894a6126029323484a2ad8bd700b2831f66bf960a9c122 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3994b27d6ccda8b553894a6126029323484a2ad8bd700b2831f66bf960a9c122->enter($__internal_3994b27d6ccda8b553894a6126029323484a2ad8bd700b2831f66bf960a9c122_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_a0a17e729a235d53751ac1b371be09e066c0a38af8dbfd064a06342ad4338342->leave($__internal_a0a17e729a235d53751ac1b371be09e066c0a38af8dbfd064a06342ad4338342_prof);

        
        $__internal_3994b27d6ccda8b553894a6126029323484a2ad8bd700b2831f66bf960a9c122->leave($__internal_3994b27d6ccda8b553894a6126029323484a2ad8bd700b2831f66bf960a9c122_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/repeated_row.html.php");
    }
}
