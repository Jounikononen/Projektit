<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_6a31b3d879f03e1231e7c356af68af789be785211c94f8bf884dad3686bd07af extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9f01b68ec51dfc3138baeb73f85c19804ca65fd042e8d2aa81de6c47444213bb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9f01b68ec51dfc3138baeb73f85c19804ca65fd042e8d2aa81de6c47444213bb->enter($__internal_9f01b68ec51dfc3138baeb73f85c19804ca65fd042e8d2aa81de6c47444213bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_68e02ee14e5131347a309de5a28c1225662cf3ce39365db298672169e9d392e4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_68e02ee14e5131347a309de5a28c1225662cf3ce39365db298672169e9d392e4->enter($__internal_68e02ee14e5131347a309de5a28c1225662cf3ce39365db298672169e9d392e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_9f01b68ec51dfc3138baeb73f85c19804ca65fd042e8d2aa81de6c47444213bb->leave($__internal_9f01b68ec51dfc3138baeb73f85c19804ca65fd042e8d2aa81de6c47444213bb_prof);

        
        $__internal_68e02ee14e5131347a309de5a28c1225662cf3ce39365db298672169e9d392e4->leave($__internal_68e02ee14e5131347a309de5a28c1225662cf3ce39365db298672169e9d392e4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/textarea_widget.html.php");
    }
}
