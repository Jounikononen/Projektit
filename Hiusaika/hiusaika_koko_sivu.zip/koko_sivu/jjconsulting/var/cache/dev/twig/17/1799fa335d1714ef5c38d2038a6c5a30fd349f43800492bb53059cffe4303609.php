<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_f307b53c3a52eceb7ec754401dda7b8b37fe9408d076481b4d0c3f2381d251f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_777fdc49b2307cff4a5a6ba1fcb678a2cf7c6579844d077734b9be210b787e0b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_777fdc49b2307cff4a5a6ba1fcb678a2cf7c6579844d077734b9be210b787e0b->enter($__internal_777fdc49b2307cff4a5a6ba1fcb678a2cf7c6579844d077734b9be210b787e0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_0ea0e6541b06f2b8c11c135619dd70b0461498ae5ca76a00281c0c7e0eb1ed66 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ea0e6541b06f2b8c11c135619dd70b0461498ae5ca76a00281c0c7e0eb1ed66->enter($__internal_0ea0e6541b06f2b8c11c135619dd70b0461498ae5ca76a00281c0c7e0eb1ed66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_777fdc49b2307cff4a5a6ba1fcb678a2cf7c6579844d077734b9be210b787e0b->leave($__internal_777fdc49b2307cff4a5a6ba1fcb678a2cf7c6579844d077734b9be210b787e0b_prof);

        
        $__internal_0ea0e6541b06f2b8c11c135619dd70b0461498ae5ca76a00281c0c7e0eb1ed66->leave($__internal_0ea0e6541b06f2b8c11c135619dd70b0461498ae5ca76a00281c0c7e0eb1ed66_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_enctype.html.php");
    }
}
