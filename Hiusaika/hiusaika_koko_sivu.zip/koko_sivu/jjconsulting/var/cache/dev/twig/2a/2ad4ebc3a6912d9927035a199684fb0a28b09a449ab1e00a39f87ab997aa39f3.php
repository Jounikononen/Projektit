<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_a28a2cd051d57c65bcaa340c4798d25f888540be0a7f65069376f9489ee6839e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3c7943960431a2bb04620617dbde009fc364cfa03e42d628173edf9bdf71a607 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3c7943960431a2bb04620617dbde009fc364cfa03e42d628173edf9bdf71a607->enter($__internal_3c7943960431a2bb04620617dbde009fc364cfa03e42d628173edf9bdf71a607_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        $__internal_0b79c12e2c3eaf0a1b0c78d7cfa6af8d037838bda2aa9e13f1af2b6ab3ab8457 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b79c12e2c3eaf0a1b0c78d7cfa6af8d037838bda2aa9e13f1af2b6ab3ab8457->enter($__internal_0b79c12e2c3eaf0a1b0c78d7cfa6af8d037838bda2aa9e13f1af2b6ab3ab8457_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_3c7943960431a2bb04620617dbde009fc364cfa03e42d628173edf9bdf71a607->leave($__internal_3c7943960431a2bb04620617dbde009fc364cfa03e42d628173edf9bdf71a607_prof);

        
        $__internal_0b79c12e2c3eaf0a1b0c78d7cfa6af8d037838bda2aa9e13f1af2b6ab3ab8457->leave($__internal_0b79c12e2c3eaf0a1b0c78d7cfa6af8d037838bda2aa9e13f1af2b6ab3ab8457_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
", "@Framework/Form/choice_widget_expanded.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_widget_expanded.html.php");
    }
}
