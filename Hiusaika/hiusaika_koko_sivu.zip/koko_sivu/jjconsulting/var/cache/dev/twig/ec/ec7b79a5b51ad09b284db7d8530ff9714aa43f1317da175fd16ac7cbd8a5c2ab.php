<?php

/* :Dashboard:dashboard.html.twig */
class __TwigTemplate_7c4460b49e8eaa2d5462d75bc88b5b55264db4b639c8fc5d5de9f1aa01c7346a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Dashboard:dashboard.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e8c79ddbc6a0cf9f4a7264afb46e232f2ee17de719731552e52ae159a57b501a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e8c79ddbc6a0cf9f4a7264afb46e232f2ee17de719731552e52ae159a57b501a->enter($__internal_e8c79ddbc6a0cf9f4a7264afb46e232f2ee17de719731552e52ae159a57b501a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Dashboard:dashboard.html.twig"));

        $__internal_2cedc83e4804074c699f2190a6a96b9da3ca900fd031e2bd23712b2d2eb91746 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2cedc83e4804074c699f2190a6a96b9da3ca900fd031e2bd23712b2d2eb91746->enter($__internal_2cedc83e4804074c699f2190a6a96b9da3ca900fd031e2bd23712b2d2eb91746_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Dashboard:dashboard.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e8c79ddbc6a0cf9f4a7264afb46e232f2ee17de719731552e52ae159a57b501a->leave($__internal_e8c79ddbc6a0cf9f4a7264afb46e232f2ee17de719731552e52ae159a57b501a_prof);

        
        $__internal_2cedc83e4804074c699f2190a6a96b9da3ca900fd031e2bd23712b2d2eb91746->leave($__internal_2cedc83e4804074c699f2190a6a96b9da3ca900fd031e2bd23712b2d2eb91746_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_8aadd4ffdbaf51ac4ae1bc396a37d425cc543898ed192ad510d3f805a46bc79f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8aadd4ffdbaf51ac4ae1bc396a37d425cc543898ed192ad510d3f805a46bc79f->enter($__internal_8aadd4ffdbaf51ac4ae1bc396a37d425cc543898ed192ad510d3f805a46bc79f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_2d61d80ff170d5890680086261afefc982b4d1b2161624e2e967ea6e445808e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2d61d80ff170d5890680086261afefc982b4d1b2161624e2e967ea6e445808e3->enter($__internal_2d61d80ff170d5890680086261afefc982b4d1b2161624e2e967ea6e445808e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Oma tili";
        
        $__internal_2d61d80ff170d5890680086261afefc982b4d1b2161624e2e967ea6e445808e3->leave($__internal_2d61d80ff170d5890680086261afefc982b4d1b2161624e2e967ea6e445808e3_prof);

        
        $__internal_8aadd4ffdbaf51ac4ae1bc396a37d425cc543898ed192ad510d3f805a46bc79f->leave($__internal_8aadd4ffdbaf51ac4ae1bc396a37d425cc543898ed192ad510d3f805a46bc79f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_f26cb43822ec86427263eb48e8c79b6f10275677dba35af2924fc04b407a7652 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f26cb43822ec86427263eb48e8c79b6f10275677dba35af2924fc04b407a7652->enter($__internal_f26cb43822ec86427263eb48e8c79b6f10275677dba35af2924fc04b407a7652_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_2557f650a7f6cb7493dc372d1a99e5666dbc0a6b51eadf6468b68defe345c6c1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2557f650a7f6cb7493dc372d1a99e5666dbc0a6b51eadf6468b68defe345c6c1->enter($__internal_2557f650a7f6cb7493dc372d1a99e5666dbc0a6b51eadf6468b68defe345c6c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container-fluid dashboard-company-info\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-4 text-center img-container\">
                    ";
        // line 8
        if (($this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "imageName", array()) == null)) {
            // line 9
            echo "                        <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/img/logo-placeholder.png"), "html", null, true);
            echo "\" class=\"img-responsive\"></img>
                    ";
        } else {
            // line 11
            echo "                        <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Liip\ImagineBundle\Templating\ImagineExtension')->filter($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["company"] ?? $this->getContext($context, "company")), "imageFile"), "company"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "name", array()), "html", null, true);
            echo "\" class=\"img-responsive\" />
                    ";
        }
        // line 13
        echo "                </div>
                <div class=\"col-sm-8\">
                    <h2>Omat tiedot</h2>
                    <h4>";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
        echo "</h4>
                    <h4>";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "name", array()), "html", null, true);
        echo "</h4>
                    <h4>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "vatId", array()), "html", null, true);
        echo "</h4>
                    <p>
                        <a href=\"";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("dashboardImageChange");
        echo "\" class=\"btn btn-default\">Vaihda kuva</a> <a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_change_password");
        echo "\" class=\"btn btn-default\">Vaihda salasana</a><br/>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class=\"container-fluid bg-grey dashboard-company-info\">
        <div class=\"container\">
            <h2 class=\"text-center\">Yrityksen tiedot</h2>
            <div class=\"row\">
                ";
        // line 31
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
                    <div class=\"col-sm-12\">
                        <div class=\"col-sm-6 form-group\">
                            ";
        // line 34
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "address", array()), 'row');
        echo "
                        </div>
                        <div class=\"col-sm-2 form-group\">
                            ";
        // line 37
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "postcode", array()), 'row');
        echo "
                        </div>
                        <div class=\"col-sm-4 form-group\">
                            ";
        // line 40
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "city", array()), 'row');
        echo "
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            ";
        // line 43
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "phone", array()), 'row');
        echo "
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            ";
        // line 46
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "email", array()), 'row');
        echo "
                        </div>
                    </div>
                        
                    <h4 class=\"info-header\">Aukioloajat</h4>
                    
                    <div class=\"col-sm-6\">
                        <div class=\"col-sm-6 form-group\">
                            ";
        // line 54
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "openingHoursMonday", array()), 'row');
        echo "
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            ";
        // line 57
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "openingHoursTuesday", array()), 'row');
        echo "
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            ";
        // line 60
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "openingHoursWednesday", array()), 'row');
        echo "
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            ";
        // line 63
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "openingHoursThursday", array()), 'row');
        echo "
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            ";
        // line 66
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "openingHoursFriday", array()), 'row');
        echo "
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            ";
        // line 69
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "openingHoursSaturday", array()), 'row');
        echo "
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            ";
        // line 72
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "openingHoursSunday", array()), 'row');
        echo "
                        </div>
                    </div>
                        
                    <div class=\"col-sm-6\">
                        <div class=\"col-sm-12 form-group\">
                            ";
        // line 78
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'row');
        echo "
                        </div>
                    </div>
                        
                    <h4 class=\"info-header\">Palvelut ja hinnasto</h4>
                    
                    <div class=\"row\">
                        <div class=\"col-sm-6\">
                            <div class=\"col-sm-6 form-group\">
                                <div>
                                    <label for=\"default-service-add-name\">Palvelun nimi</label>
                                    <select class=\"form-control\" id=\"default-service-add-name\">
                                        ";
        // line 90
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["defaultServices"] ?? $this->getContext($context, "defaultServices")));
        foreach ($context['_seq'] as $context["_key"] => $context["service"]) {
            // line 91
            echo "                                            <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["service"], "id", array()), "html", null, true);
            echo "\"
                                            ";
            // line 92
            if (twig_in_filter($this->getAttribute($context["service"], "id", array()), ($context["selectedDefaultServices"] ?? $this->getContext($context, "selectedDefaultServices")))) {
                // line 93
                echo "                                                disabled
                                            ";
            }
            // line 95
            echo "                                            >";
            echo twig_escape_filter($this->env, $this->getAttribute($context["service"], "name", array()), "html", null, true);
            echo "</option>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['service'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 97
        echo "                                    </select>
                                </div>
                            </div>
                            <div class=\"col-sm-3 form-group\">
                                <div>
                                    <label for=\"default-service-add-priceFrom\">Hinta</label>
                                    <input type=\"text\" class=\"form-control\" id=\"default-service-add-priceFrom\">
                                </div>
                            </div>
                            <div class=\"col-sm-3 form-group\">
                                <div>
                                    <label for=\"default-service-add-priceTo\">Hinta</label>
                                    <input type=\"text\" class=\"form-control\" id=\"default-service-add-priceTo\">
                                </div>
                            </div>
                            <div class=\"col-sm-12 form-group text-danger\" id=\"default-service-add-error\">
                                
                            </div>
                            <div class=\"col-sm-12 form-group\">
                                <a href=\"#\" id=\"add-default-service\" class=\"btn btn-default\"><i class=\"fa fa-plus\" aria-hidden=\"true\"></i> Lisää peruspalvelu</a>
                            </div>
                        </div>

                        <div class=\"col-sm-6\">
                            <div class=\"col-sm-12 form-group\">
                                <table class=\"table table-hover table-responsive\" id=\"selected-services\">
                                    <thead>
                                        <tr>
                                            <th class=\"col-name\">Valitut palvelut</th>
                                            <th class=\"col-price\">Hinta</th>
                                            <th class=\"col-remove\">Poista</th>
                                        </tr>
                                    </thead>
                                    <tbody id=\"selected-default-services-collection\">
                                        ";
        // line 131
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "defaultServices", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["service"]) {
            // line 132
            echo "                                            <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "name", array()), "vars", array()), "value", array()), "html", null, true);
            echo "\">
                                                <td class=\"col-name\">
                                                    ";
            // line 134
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "name", array()), "vars", array()), "data", array()), "name", array()), "html", null, true);
            echo "
                                                    <input type=\"hidden\" id=\"";
            // line 135
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "name", array()), "vars", array()), "id", array()), "html", null, true);
            echo "\" 
                                                        name=\"";
            // line 136
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "name", array()), "vars", array()), "full_name", array()), "html", null, true);
            echo "\" 
                                                        value=\"";
            // line 137
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "name", array()), "vars", array()), "value", array()), "html", null, true);
            echo "\" />
                                                    ";
            // line 138
            $this->getAttribute($context["service"], "setRendered", array());
            // line 139
            echo "                                                    ";
            // line 140
            echo "                                                </td>
                                                <td class=\"col-price\">
                                                    ";
            // line 142
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "priceFrom", array()), "vars", array()), "value", array()), "html", null, true);
            echo " ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($context["service"], "priceFrom", array()), 'row');
            echo "
                                                    -
                                                    ";
            // line 144
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "priceTo", array()), "vars", array()), "value", array()), "html", null, true);
            echo " ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($context["service"], "priceTo", array()), 'row');
            echo "
                                                    €
                                                </td>
                                                <td class=\"col-remove\">
                                                    <a class=\"default-service-remove\" href=\"#\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></a>
                                                </td>
                                            </tr>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['service'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 152
        echo "                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-sm-6\">
                            <div class=\"col-sm-6 form-group\">
                                <div>
                                    <label for=\"service-add-name\">Palvelun nimi</label>
                                    <input type=\"text\" class=\"form-control\" id=\"service-add-name\">
                                </div>
                            </div>
                            <div class=\"col-sm-3 form-group\">
                                <div>
                                    <label for=\"service-add-priceFrom\">Hinta</label>
                                    <input type=\"text\" class=\"form-control\" id=\"service-add-priceFrom\">
                                </div>
                            </div>
                            <div class=\"col-sm-3 form-group\">
                                <div>
                                    <label for=\"service-add-priceTo\">Hinta</label>
                                    <input type=\"text\" class=\"form-control\" id=\"service-add-priceTo\">
                                </div>
                            </div>
                            <div class=\"col-sm-12 form-group text-danger\" id=\"service-add-error\">
                                
                            </div>
                            <div class=\"col-sm-12 form-group\">
                                <a href=\"#\" id=\"add-service\" class=\"btn btn-default\"><i class=\"fa fa-plus\" aria-hidden=\"true\"></i> Lisää muu palvelu</a>
                            </div>
                        </div>

                        <div class=\"col-sm-6\">
                            <div class=\"col-sm-12 form-group\">
                                <table class=\"table table-hover table-responsive\" id=\"selected-services\">
                                    <thead>
                                        <tr>
                                            <th class=\"col-name\">Muut palvelut</th>
                                            <th class=\"col-price\">Hinta</th>
                                            <th class=\"col-remove\">Poista</th>
                                        </tr>
                                    </thead>
                                    <tbody id=\"selected-services-collection\">
                                        ";
        // line 196
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "services", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["service"]) {
            // line 197
            echo "                                            <tr>
                                                <td class=\"col-name\">";
            // line 198
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "name", array()), "vars", array()), "value", array()), "html", null, true);
            echo " ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($context["service"], "name", array()), 'row');
            echo "</td>
                                                <td class=\"col-price\">
                                                    ";
            // line 200
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "priceFrom", array()), "vars", array()), "value", array()), "html", null, true);
            echo " ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($context["service"], "priceFrom", array()), 'row');
            echo "
                                                    -
                                                    ";
            // line 202
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["service"], "priceTo", array()), "vars", array()), "value", array()), "html", null, true);
            echo " ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($context["service"], "priceTo", array()), 'row');
            echo "
                                                    €
                                                </td>
                                                <td class=\"col-remove\">
                                                    <a class=\"service-remove\" href=\"#\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></a>
                                                </td>
                                            </tr>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['service'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 210
        echo "                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                                    
                    <div class=\"col-sm-12\">
                        <div class=\"col-sm-12 form-group\">
                            ";
        // line 218
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "submit", array()), 'row');
        echo "
                        </div>
                    </div>
                ";
        // line 221
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
            </div>
        </div>
    </div>
";
        
        $__internal_2557f650a7f6cb7493dc372d1a99e5666dbc0a6b51eadf6468b68defe345c6c1->leave($__internal_2557f650a7f6cb7493dc372d1a99e5666dbc0a6b51eadf6468b68defe345c6c1_prof);

        
        $__internal_f26cb43822ec86427263eb48e8c79b6f10275677dba35af2924fc04b407a7652->leave($__internal_f26cb43822ec86427263eb48e8c79b6f10275677dba35af2924fc04b407a7652_prof);

    }

    // line 227
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_f695cc4f0c7743465686f64d60121f8c6064e29c0e8ff36a19ce485e88a4a8d1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f695cc4f0c7743465686f64d60121f8c6064e29c0e8ff36a19ce485e88a4a8d1->enter($__internal_f695cc4f0c7743465686f64d60121f8c6064e29c0e8ff36a19ce485e88a4a8d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_f1e94efb20e3de7678daedd2c3bfe9060ac5150c9945a32afefd7ce42261edf7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1e94efb20e3de7678daedd2c3bfe9060ac5150c9945a32afefd7ce42261edf7->enter($__internal_f1e94efb20e3de7678daedd2c3bfe9060ac5150c9945a32afefd7ce42261edf7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 228
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/dashboard.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
";
        
        $__internal_f1e94efb20e3de7678daedd2c3bfe9060ac5150c9945a32afefd7ce42261edf7->leave($__internal_f1e94efb20e3de7678daedd2c3bfe9060ac5150c9945a32afefd7ce42261edf7_prof);

        
        $__internal_f695cc4f0c7743465686f64d60121f8c6064e29c0e8ff36a19ce485e88a4a8d1->leave($__internal_f695cc4f0c7743465686f64d60121f8c6064e29c0e8ff36a19ce485e88a4a8d1_prof);

    }

    // line 231
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_ba5e7f97507e62993a24c8bc718012e1636c38855c7ee79c2e44c4eabd033ad9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba5e7f97507e62993a24c8bc718012e1636c38855c7ee79c2e44c4eabd033ad9->enter($__internal_ba5e7f97507e62993a24c8bc718012e1636c38855c7ee79c2e44c4eabd033ad9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_995e6839f694818274b73c403058930835e6f235b2e959334b7597dffc70d512 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_995e6839f694818274b73c403058930835e6f235b2e959334b7597dffc70d512->enter($__internal_995e6839f694818274b73c403058930835e6f235b2e959334b7597dffc70d512_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 232
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 233
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/companyservicehandler.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_995e6839f694818274b73c403058930835e6f235b2e959334b7597dffc70d512->leave($__internal_995e6839f694818274b73c403058930835e6f235b2e959334b7597dffc70d512_prof);

        
        $__internal_ba5e7f97507e62993a24c8bc718012e1636c38855c7ee79c2e44c4eabd033ad9->leave($__internal_ba5e7f97507e62993a24c8bc718012e1636c38855c7ee79c2e44c4eabd033ad9_prof);

    }

    public function getTemplateName()
    {
        return ":Dashboard:dashboard.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  494 => 233,  489 => 232,  480 => 231,  467 => 228,  458 => 227,  443 => 221,  437 => 218,  427 => 210,  411 => 202,  404 => 200,  397 => 198,  394 => 197,  390 => 196,  344 => 152,  328 => 144,  321 => 142,  317 => 140,  315 => 139,  313 => 138,  309 => 137,  305 => 136,  301 => 135,  297 => 134,  291 => 132,  287 => 131,  251 => 97,  242 => 95,  238 => 93,  236 => 92,  231 => 91,  227 => 90,  212 => 78,  203 => 72,  197 => 69,  191 => 66,  185 => 63,  179 => 60,  173 => 57,  167 => 54,  156 => 46,  150 => 43,  144 => 40,  138 => 37,  132 => 34,  126 => 31,  110 => 20,  105 => 18,  101 => 17,  97 => 16,  92 => 13,  84 => 11,  78 => 9,  76 => 8,  70 => 4,  61 => 3,  43 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block title %}Oma tili{% endblock %}
{% block body %}
    <div class=\"container-fluid dashboard-company-info\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-4 text-center img-container\">
                    {% if company.imageName == null %}
                        <img src=\"{{ asset('bundles/app/img/logo-placeholder.png') }}\" class=\"img-responsive\"></img>
                    {% else %}
                        <img src=\"{{ vich_uploader_asset(company, 'imageFile') | imagine_filter('company') }}\" alt=\"{{ company.name }}\" class=\"img-responsive\" />
                    {% endif %}
                </div>
                <div class=\"col-sm-8\">
                    <h2>Omat tiedot</h2>
                    <h4>{{ app.user.username }}</h4>
                    <h4>{{ company.name }}</h4>
                    <h4>{{ company.vatId }}</h4>
                    <p>
                        <a href=\"{{ path('dashboardImageChange') }}\" class=\"btn btn-default\">Vaihda kuva</a> <a href=\"{{ path('fos_user_change_password') }}\" class=\"btn btn-default\">Vaihda salasana</a><br/>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class=\"container-fluid bg-grey dashboard-company-info\">
        <div class=\"container\">
            <h2 class=\"text-center\">Yrityksen tiedot</h2>
            <div class=\"row\">
                {{form_start(form)}}
                    <div class=\"col-sm-12\">
                        <div class=\"col-sm-6 form-group\">
                            {{form_row(form.address)}}
                        </div>
                        <div class=\"col-sm-2 form-group\">
                            {{form_row(form.postcode)}}
                        </div>
                        <div class=\"col-sm-4 form-group\">
                            {{form_row(form.city)}}
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            {{form_row(form.phone)}}
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            {{form_row(form.email)}}
                        </div>
                    </div>
                        
                    <h4 class=\"info-header\">Aukioloajat</h4>
                    
                    <div class=\"col-sm-6\">
                        <div class=\"col-sm-6 form-group\">
                            {{form_row(form.openingHoursMonday)}}
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            {{form_row(form.openingHoursTuesday)}}
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            {{form_row(form.openingHoursWednesday)}}
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            {{form_row(form.openingHoursThursday)}}
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            {{form_row(form.openingHoursFriday)}}
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            {{form_row(form.openingHoursSaturday)}}
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            {{form_row(form.openingHoursSunday)}}
                        </div>
                    </div>
                        
                    <div class=\"col-sm-6\">
                        <div class=\"col-sm-12 form-group\">
                            {{form_row(form.description)}}
                        </div>
                    </div>
                        
                    <h4 class=\"info-header\">Palvelut ja hinnasto</h4>
                    
                    <div class=\"row\">
                        <div class=\"col-sm-6\">
                            <div class=\"col-sm-6 form-group\">
                                <div>
                                    <label for=\"default-service-add-name\">Palvelun nimi</label>
                                    <select class=\"form-control\" id=\"default-service-add-name\">
                                        {% for service in defaultServices %}
                                            <option value=\"{{ service.id }}\"
                                            {% if service.id in selectedDefaultServices %}
                                                disabled
                                            {% endif %}
                                            >{{ service.name }}</option>
                                        {% endfor %}
                                    </select>
                                </div>
                            </div>
                            <div class=\"col-sm-3 form-group\">
                                <div>
                                    <label for=\"default-service-add-priceFrom\">Hinta</label>
                                    <input type=\"text\" class=\"form-control\" id=\"default-service-add-priceFrom\">
                                </div>
                            </div>
                            <div class=\"col-sm-3 form-group\">
                                <div>
                                    <label for=\"default-service-add-priceTo\">Hinta</label>
                                    <input type=\"text\" class=\"form-control\" id=\"default-service-add-priceTo\">
                                </div>
                            </div>
                            <div class=\"col-sm-12 form-group text-danger\" id=\"default-service-add-error\">
                                
                            </div>
                            <div class=\"col-sm-12 form-group\">
                                <a href=\"#\" id=\"add-default-service\" class=\"btn btn-default\"><i class=\"fa fa-plus\" aria-hidden=\"true\"></i> Lisää peruspalvelu</a>
                            </div>
                        </div>

                        <div class=\"col-sm-6\">
                            <div class=\"col-sm-12 form-group\">
                                <table class=\"table table-hover table-responsive\" id=\"selected-services\">
                                    <thead>
                                        <tr>
                                            <th class=\"col-name\">Valitut palvelut</th>
                                            <th class=\"col-price\">Hinta</th>
                                            <th class=\"col-remove\">Poista</th>
                                        </tr>
                                    </thead>
                                    <tbody id=\"selected-default-services-collection\">
                                        {% for service in form.defaultServices %}
                                            <tr data-id=\"{{ service.name.vars.value }}\">
                                                <td class=\"col-name\">
                                                    {{ service.name.vars.data.name }}
                                                    <input type=\"hidden\" id=\"{{ service.name.vars.id }}\" 
                                                        name=\"{{ service.name.vars.full_name }}\" 
                                                        value=\"{{ service.name.vars.value }}\" />
                                                    {% do service.setRendered %}
                                                    {#{{ service.name.vars.value }} {{ form_row(service.name) }}#}
                                                </td>
                                                <td class=\"col-price\">
                                                    {{ service.priceFrom.vars.value }} {{ form_row(service.priceFrom) }}
                                                    -
                                                    {{ service.priceTo.vars.value }} {{ form_row(service.priceTo) }}
                                                    €
                                                </td>
                                                <td class=\"col-remove\">
                                                    <a class=\"default-service-remove\" href=\"#\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></a>
                                                </td>
                                            </tr>
                                        {% endfor %}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-sm-6\">
                            <div class=\"col-sm-6 form-group\">
                                <div>
                                    <label for=\"service-add-name\">Palvelun nimi</label>
                                    <input type=\"text\" class=\"form-control\" id=\"service-add-name\">
                                </div>
                            </div>
                            <div class=\"col-sm-3 form-group\">
                                <div>
                                    <label for=\"service-add-priceFrom\">Hinta</label>
                                    <input type=\"text\" class=\"form-control\" id=\"service-add-priceFrom\">
                                </div>
                            </div>
                            <div class=\"col-sm-3 form-group\">
                                <div>
                                    <label for=\"service-add-priceTo\">Hinta</label>
                                    <input type=\"text\" class=\"form-control\" id=\"service-add-priceTo\">
                                </div>
                            </div>
                            <div class=\"col-sm-12 form-group text-danger\" id=\"service-add-error\">
                                
                            </div>
                            <div class=\"col-sm-12 form-group\">
                                <a href=\"#\" id=\"add-service\" class=\"btn btn-default\"><i class=\"fa fa-plus\" aria-hidden=\"true\"></i> Lisää muu palvelu</a>
                            </div>
                        </div>

                        <div class=\"col-sm-6\">
                            <div class=\"col-sm-12 form-group\">
                                <table class=\"table table-hover table-responsive\" id=\"selected-services\">
                                    <thead>
                                        <tr>
                                            <th class=\"col-name\">Muut palvelut</th>
                                            <th class=\"col-price\">Hinta</th>
                                            <th class=\"col-remove\">Poista</th>
                                        </tr>
                                    </thead>
                                    <tbody id=\"selected-services-collection\">
                                        {% for service in form.services %}
                                            <tr>
                                                <td class=\"col-name\">{{ service.name.vars.value }} {{ form_row(service.name) }}</td>
                                                <td class=\"col-price\">
                                                    {{ service.priceFrom.vars.value }} {{ form_row(service.priceFrom) }}
                                                    -
                                                    {{ service.priceTo.vars.value }} {{ form_row(service.priceTo) }}
                                                    €
                                                </td>
                                                <td class=\"col-remove\">
                                                    <a class=\"service-remove\" href=\"#\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></a>
                                                </td>
                                            </tr>
                                        {% endfor %}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                                    
                    <div class=\"col-sm-12\">
                        <div class=\"col-sm-12 form-group\">
                            {{form_row(form.submit)}}
                        </div>
                    </div>
                {{form_end(form)}}
            </div>
        </div>
    </div>
{% endblock %}

{% block stylesheets %}
    <link href=\"{{ asset('bundles/app/css/dashboard.css') }}\" rel=\"stylesheet\" />
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
    <script src=\"{{ asset('bundles/app/js/companyservicehandler.js') }}\"></script>
{% endblock %}", ":Dashboard:dashboard.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Dashboard/dashboard.html.twig");
    }
}
