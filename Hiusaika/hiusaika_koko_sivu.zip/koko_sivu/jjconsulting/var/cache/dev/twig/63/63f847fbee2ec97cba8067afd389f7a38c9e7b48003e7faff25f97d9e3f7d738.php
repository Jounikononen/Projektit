<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_06ed95bbc688f601ea913731297465e96b4f3ee557c758c230f6aeec186513af extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b2715186790156e5f9ef52b7034bd69ec013f12358ac6150ada26b18c6f7dd6d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b2715186790156e5f9ef52b7034bd69ec013f12358ac6150ada26b18c6f7dd6d->enter($__internal_b2715186790156e5f9ef52b7034bd69ec013f12358ac6150ada26b18c6f7dd6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_668d749ace3d34376b95c7cc350f3dd887fb2b81a56377bede38d844eadd5115 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_668d749ace3d34376b95c7cc350f3dd887fb2b81a56377bede38d844eadd5115->enter($__internal_668d749ace3d34376b95c7cc350f3dd887fb2b81a56377bede38d844eadd5115_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_b2715186790156e5f9ef52b7034bd69ec013f12358ac6150ada26b18c6f7dd6d->leave($__internal_b2715186790156e5f9ef52b7034bd69ec013f12358ac6150ada26b18c6f7dd6d_prof);

        
        $__internal_668d749ace3d34376b95c7cc350f3dd887fb2b81a56377bede38d844eadd5115->leave($__internal_668d749ace3d34376b95c7cc350f3dd887fb2b81a56377bede38d844eadd5115_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_widget.html.php");
    }
}
