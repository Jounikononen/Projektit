<?php

/* FOSUserBundle:Group:show.html.twig */
class __TwigTemplate_b8913199072f7cd4cb6e67b0817714ba974eb078b9a37fc31f1d64463763c870 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_55989dc4c86b004f6f3fe4ff37a299a1a4bff721428741829cc2af84dfb587ac = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_55989dc4c86b004f6f3fe4ff37a299a1a4bff721428741829cc2af84dfb587ac->enter($__internal_55989dc4c86b004f6f3fe4ff37a299a1a4bff721428741829cc2af84dfb587ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show.html.twig"));

        $__internal_f6aecb6d1856413e012f00a153a1f93b6c86f7e3ad4197b1ed8893d5ff4ce6a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f6aecb6d1856413e012f00a153a1f93b6c86f7e3ad4197b1ed8893d5ff4ce6a9->enter($__internal_f6aecb6d1856413e012f00a153a1f93b6c86f7e3ad4197b1ed8893d5ff4ce6a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_55989dc4c86b004f6f3fe4ff37a299a1a4bff721428741829cc2af84dfb587ac->leave($__internal_55989dc4c86b004f6f3fe4ff37a299a1a4bff721428741829cc2af84dfb587ac_prof);

        
        $__internal_f6aecb6d1856413e012f00a153a1f93b6c86f7e3ad4197b1ed8893d5ff4ce6a9->leave($__internal_f6aecb6d1856413e012f00a153a1f93b6c86f7e3ad4197b1ed8893d5ff4ce6a9_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_25b49139fdaab598dd9a1311ee7674d8ac3eea32587cf4e8a795f74c346dc1a7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_25b49139fdaab598dd9a1311ee7674d8ac3eea32587cf4e8a795f74c346dc1a7->enter($__internal_25b49139fdaab598dd9a1311ee7674d8ac3eea32587cf4e8a795f74c346dc1a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_addac4ee297498e5352757b8c75ca62d0ae66ff680629bf6b875a7134a258704 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_addac4ee297498e5352757b8c75ca62d0ae66ff680629bf6b875a7134a258704->enter($__internal_addac4ee297498e5352757b8c75ca62d0ae66ff680629bf6b875a7134a258704_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/show_content.html.twig", "FOSUserBundle:Group:show.html.twig", 4)->display($context);
        
        $__internal_addac4ee297498e5352757b8c75ca62d0ae66ff680629bf6b875a7134a258704->leave($__internal_addac4ee297498e5352757b8c75ca62d0ae66ff680629bf6b875a7134a258704_prof);

        
        $__internal_25b49139fdaab598dd9a1311ee7674d8ac3eea32587cf4e8a795f74c346dc1a7->leave($__internal_25b49139fdaab598dd9a1311ee7674d8ac3eea32587cf4e8a795f74c346dc1a7_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/show_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:show.html.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Group/show.html.twig");
    }
}
