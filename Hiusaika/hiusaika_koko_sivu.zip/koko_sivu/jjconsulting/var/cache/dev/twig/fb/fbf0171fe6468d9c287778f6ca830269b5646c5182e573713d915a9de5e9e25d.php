<?php

/* TwigBundle::layout.html.twig */
class __TwigTemplate_d3814371c0331a9981405942a66bb813ddde9bfeff70d214c33d88efdfabc89f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fa4b453591418d8c5f8a00ac6cc1b9b650776f25aa00b7378291febc7ce2eea7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa4b453591418d8c5f8a00ac6cc1b9b650776f25aa00b7378291febc7ce2eea7->enter($__internal_fa4b453591418d8c5f8a00ac6cc1b9b650776f25aa00b7378291febc7ce2eea7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle::layout.html.twig"));

        $__internal_be65b9901a26680931fa0f01dcb274856c1aea8c08fa006b17786a8e3abc85d6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be65b9901a26680931fa0f01dcb274856c1aea8c08fa006b17786a8e3abc85d6->enter($__internal_be65b9901a26680931fa0f01dcb274856c1aea8c08fa006b17786a8e3abc85d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle::layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 8
        echo twig_include($this->env, $context, "@Twig/images/favicon.png.base64");
        echo "\">
        <style>";
        // line 9
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "</style>
        ";
        // line 10
        $this->displayBlock('head', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">";
        // line 15
        echo twig_include($this->env, $context, "@Twig/images/symfony-logo.svg");
        echo " Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">";
        // line 19
        echo twig_include($this->env, $context, "@Twig/images/icon-book.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">";
        // line 26
        echo twig_include($this->env, $context, "@Twig/images/icon-support.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "        ";
        echo twig_include($this->env, $context, "@Twig/base_js.html.twig");
        echo "
    </body>
</html>
";
        
        $__internal_fa4b453591418d8c5f8a00ac6cc1b9b650776f25aa00b7378291febc7ce2eea7->leave($__internal_fa4b453591418d8c5f8a00ac6cc1b9b650776f25aa00b7378291febc7ce2eea7_prof);

        
        $__internal_be65b9901a26680931fa0f01dcb274856c1aea8c08fa006b17786a8e3abc85d6->leave($__internal_be65b9901a26680931fa0f01dcb274856c1aea8c08fa006b17786a8e3abc85d6_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_6ff6d8d99d03afd298c47d1e160840c825100ad844d268907da41acb31df9364 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6ff6d8d99d03afd298c47d1e160840c825100ad844d268907da41acb31df9364->enter($__internal_6ff6d8d99d03afd298c47d1e160840c825100ad844d268907da41acb31df9364_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_6a87fb6cf341799a7efbf751ae8d65d612dced1dc1dd1f1c19db74fcd309479b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6a87fb6cf341799a7efbf751ae8d65d612dced1dc1dd1f1c19db74fcd309479b->enter($__internal_6a87fb6cf341799a7efbf751ae8d65d612dced1dc1dd1f1c19db74fcd309479b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_6a87fb6cf341799a7efbf751ae8d65d612dced1dc1dd1f1c19db74fcd309479b->leave($__internal_6a87fb6cf341799a7efbf751ae8d65d612dced1dc1dd1f1c19db74fcd309479b_prof);

        
        $__internal_6ff6d8d99d03afd298c47d1e160840c825100ad844d268907da41acb31df9364->leave($__internal_6ff6d8d99d03afd298c47d1e160840c825100ad844d268907da41acb31df9364_prof);

    }

    // line 10
    public function block_head($context, array $blocks = array())
    {
        $__internal_e5aaef9b2fc3f58af76a34b86c04985d9c6a4c8aa6b2d465a058d429ee79cb52 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e5aaef9b2fc3f58af76a34b86c04985d9c6a4c8aa6b2d465a058d429ee79cb52->enter($__internal_e5aaef9b2fc3f58af76a34b86c04985d9c6a4c8aa6b2d465a058d429ee79cb52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_380b0bc31e5b488e6fd9e5fbdaecf26916cdd107ea3f96e83c289a85f7a46b5b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_380b0bc31e5b488e6fd9e5fbdaecf26916cdd107ea3f96e83c289a85f7a46b5b->enter($__internal_380b0bc31e5b488e6fd9e5fbdaecf26916cdd107ea3f96e83c289a85f7a46b5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        
        $__internal_380b0bc31e5b488e6fd9e5fbdaecf26916cdd107ea3f96e83c289a85f7a46b5b->leave($__internal_380b0bc31e5b488e6fd9e5fbdaecf26916cdd107ea3f96e83c289a85f7a46b5b_prof);

        
        $__internal_e5aaef9b2fc3f58af76a34b86c04985d9c6a4c8aa6b2d465a058d429ee79cb52->leave($__internal_e5aaef9b2fc3f58af76a34b86c04985d9c6a4c8aa6b2d465a058d429ee79cb52_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_94c9aa139e292113d1cfe3d2e75833db07af8c09cad0ab0677347686617001fa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_94c9aa139e292113d1cfe3d2e75833db07af8c09cad0ab0677347686617001fa->enter($__internal_94c9aa139e292113d1cfe3d2e75833db07af8c09cad0ab0677347686617001fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_68e2bcaa8c7a456d60145dc5c46576b3eb2052d8a958ca788a6debf92635fa82 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_68e2bcaa8c7a456d60145dc5c46576b3eb2052d8a958ca788a6debf92635fa82->enter($__internal_68e2bcaa8c7a456d60145dc5c46576b3eb2052d8a958ca788a6debf92635fa82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_68e2bcaa8c7a456d60145dc5c46576b3eb2052d8a958ca788a6debf92635fa82->leave($__internal_68e2bcaa8c7a456d60145dc5c46576b3eb2052d8a958ca788a6debf92635fa82_prof);

        
        $__internal_94c9aa139e292113d1cfe3d2e75833db07af8c09cad0ab0677347686617001fa->leave($__internal_94c9aa139e292113d1cfe3d2e75833db07af8c09cad0ab0677347686617001fa_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 33,  120 => 10,  103 => 7,  88 => 34,  86 => 33,  76 => 26,  66 => 19,  59 => 15,  53 => 11,  51 => 10,  47 => 9,  43 => 8,  39 => 7,  33 => 4,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"{{ _charset }}\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>{% block title %}{% endblock %}</title>
        <link rel=\"icon\" type=\"image/png\" href=\"{{ include('@Twig/images/favicon.png.base64') }}\">
        <style>{{ include('@Twig/exception.css.twig') }}</style>
        {% block head %}{% endblock %}
    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">{{ include('@Twig/images/symfony-logo.svg') }} Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-book.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-support.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        {% block body %}{% endblock %}
        {{ include('@Twig/base_js.html.twig') }}
    </body>
</html>
", "TwigBundle::layout.html.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/layout.html.twig");
    }
}
