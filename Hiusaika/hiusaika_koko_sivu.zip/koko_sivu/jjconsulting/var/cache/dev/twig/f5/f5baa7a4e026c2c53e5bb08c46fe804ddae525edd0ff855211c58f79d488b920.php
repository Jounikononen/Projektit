<?php

/* :Company:company.html.twig */
class __TwigTemplate_e26b54a193328bd82f02620161ed30fe9337ebdeac4fc5d07b1cd9e44a449de5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Company:company.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a310670ea237a676bc8fd0f8da6c4e348b7444e35da64576d4a4a87cba7ad696 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a310670ea237a676bc8fd0f8da6c4e348b7444e35da64576d4a4a87cba7ad696->enter($__internal_a310670ea237a676bc8fd0f8da6c4e348b7444e35da64576d4a4a87cba7ad696_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Company:company.html.twig"));

        $__internal_e6c01441822a0a310a885668e0fdf96bfa0155d70584c0f0a3be568066f36472 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e6c01441822a0a310a885668e0fdf96bfa0155d70584c0f0a3be568066f36472->enter($__internal_e6c01441822a0a310a885668e0fdf96bfa0155d70584c0f0a3be568066f36472_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Company:company.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a310670ea237a676bc8fd0f8da6c4e348b7444e35da64576d4a4a87cba7ad696->leave($__internal_a310670ea237a676bc8fd0f8da6c4e348b7444e35da64576d4a4a87cba7ad696_prof);

        
        $__internal_e6c01441822a0a310a885668e0fdf96bfa0155d70584c0f0a3be568066f36472->leave($__internal_e6c01441822a0a310a885668e0fdf96bfa0155d70584c0f0a3be568066f36472_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_cee9e783630f5bf2156bbe13c352b4000f265144d02afeed5312726eef7bc7d1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cee9e783630f5bf2156bbe13c352b4000f265144d02afeed5312726eef7bc7d1->enter($__internal_cee9e783630f5bf2156bbe13c352b4000f265144d02afeed5312726eef7bc7d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ef17dcf7b038adf26d0cc1b990aa39e66f2687900f38cde24ebd029a66bd3f35 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef17dcf7b038adf26d0cc1b990aa39e66f2687900f38cde24ebd029a66bd3f35->enter($__internal_ef17dcf7b038adf26d0cc1b990aa39e66f2687900f38cde24ebd029a66bd3f35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Yritys";
        
        $__internal_ef17dcf7b038adf26d0cc1b990aa39e66f2687900f38cde24ebd029a66bd3f35->leave($__internal_ef17dcf7b038adf26d0cc1b990aa39e66f2687900f38cde24ebd029a66bd3f35_prof);

        
        $__internal_cee9e783630f5bf2156bbe13c352b4000f265144d02afeed5312726eef7bc7d1->leave($__internal_cee9e783630f5bf2156bbe13c352b4000f265144d02afeed5312726eef7bc7d1_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_3e59765da21ee8cabbea6a850cd1afdead31bbbf7aeaf63ed0a1806c2120f417 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3e59765da21ee8cabbea6a850cd1afdead31bbbf7aeaf63ed0a1806c2120f417->enter($__internal_3e59765da21ee8cabbea6a850cd1afdead31bbbf7aeaf63ed0a1806c2120f417_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_828658790ba17bc3c5c4b21f3ac92f958c03d8f6d6236987bb9cec4a5f83ff54 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_828658790ba17bc3c5c4b21f3ac92f958c03d8f6d6236987bb9cec4a5f83ff54->enter($__internal_828658790ba17bc3c5c4b21f3ac92f958c03d8f6d6236987bb9cec4a5f83ff54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<div class=\"container-fluid text-center\">
    <div class=\"row\">
        <div class=\"col-sm-12 search-container\">
            ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Company:searchBar"));
        // line 9
        echo "
        </div>
    </div>
</div>

<div class=\"container-fluid bg-grey\">
    <div class=\"container\">
        <div class=\"row company-card\">
            <div class=\"col-sm-4 img-container\">
                ";
        // line 18
        if (($this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "imageName", array()) == null)) {
            // line 19
            echo "                    <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/img/logo-placeholder.png"), "html", null, true);
            echo "\" class=\"img-responsive\"></img>
                ";
        } else {
            // line 21
            echo "                    <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Liip\ImagineBundle\Templating\ImagineExtension')->filter($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["company"] ?? $this->getContext($context, "company")), "imageFile"), "company"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "name", array()), "html", null, true);
            echo "\" class=\"img-responsive\" />
                ";
        }
        // line 23
        echo "            </div>

            <div class=\"col-sm-8 company-card-infos\">
                <div>
                    <h2>";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "name", array()), "html", null, true);
        echo "</h2>
                </div>
                <div>
                    <h5>";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "vatId", array()), "html", null, true);
        echo "</h5>
                </div>
                <div>
                    <h5><i class=\"fa fa-map-marker\" aria-hidden=\"true\"></i> <label id=\"address\">";
        // line 33
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "address", array()), "html", null, true);
        echo "</label>, <label id=\"postcode\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "postcode", array()), "html", null, true);
        echo "</label> <label id=\"city\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "city", array()), "html", null, true);
        echo "</label></h5>
                </div>
                <div>
                    <h5><i class=\"fa fa-phone\" aria-hidden=\"true\"></i> ";
        // line 36
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "phone", array()), "html", null, true);
        echo "</h5>
                </div>
                <div>
                    <h5><i class=\"fa fa-envelope\" aria-hidden=\"true\"></i> ";
        // line 39
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "email", array()), "html", null, true);
        echo "</h5>
                </div>
                <div>
                    <h5><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> ";
        // line 42
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "getCurrentOpeningHours", array(), "method"), "html", null, true);
        echo "</h5>
                </div>
                <div>
                    <h5><i class=\"fa fa-eur\" aria-hidden=\"true\"></i> ";
        // line 45
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "getLowestPrice", array(), "method"), "html", null, true);
        echo "</h5>
                </div>
                <div class=\"company-card-description\">
                    <p>";
        // line 48
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "description", array()), "html", null, true);
        echo "</p>
                </div>
            </div>
        </div>
        <div class=\"row company-card\">
            <div class=\"col-sm-4\">
                <h4>Aukioloajat</h4>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        Maanantai
                    </div>
                    <div class=\"col-sm-6\">
                        ";
        // line 60
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "openingHoursMonday", array()), "html", null, true);
        echo "
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        Tiistai
                    </div>
                    <div class=\"col-sm-6\">
                        ";
        // line 68
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "openingHoursTuesday", array()), "html", null, true);
        echo "
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        Keskiviikko
                    </div>
                    <div class=\"col-sm-6\">
                        ";
        // line 76
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "openingHoursWednesday", array()), "html", null, true);
        echo "
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        Torstai
                    </div>
                    <div class=\"col-sm-6\">
                        ";
        // line 84
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "openingHoursThursday", array()), "html", null, true);
        echo "
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        Perjantai
                    </div>
                    <div class=\"col-sm-6\">
                        ";
        // line 92
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "openingHoursFriday", array()), "html", null, true);
        echo "
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        Lauantai
                    </div>
                    <div class=\"col-sm-6\">
                        ";
        // line 100
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "openingHoursSaturday", array()), "html", null, true);
        echo "
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        Sunnuntai
                    </div>
                    <div class=\"col-sm-6\">
                        ";
        // line 108
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "openingHoursSunday", array()), "html", null, true);
        echo "
                    </div>
                </div>
            </div>
            <div class=\"col-sm-4\">
                <h4>Palvelut ja hinnasto</h4>
                <div class=\"row\">
                    <div class=\"col-sm-12\" id=\"company-services-container\">
                        ";
        // line 116
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "defaultServices", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["defaultService"]) {
            // line 117
            echo "                            <div class=\"row\">
                                <div class=\"col-sm-6 company-service-name\">";
            // line 118
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["defaultService"], "name", array()), "name", array()), "html", null, true);
            echo "</div>
                                <div class=\"col-sm-6 company-service-price\">";
            // line 119
            echo twig_escape_filter($this->env, $this->getAttribute($context["defaultService"], "priceFrom", array()), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["defaultService"], "priceTo", array()), "html", null, true);
            echo "€</div>
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['defaultService'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 122
        echo "                        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "services", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["service"]) {
            // line 123
            echo "                            <div class=\"row\">
                                <div class=\"col-sm-6 company-service-name\">";
            // line 124
            echo twig_escape_filter($this->env, $this->getAttribute($context["service"], "name", array()), "html", null, true);
            echo "</div>
                                <div class=\"col-sm-6 company-service-price\">";
            // line 125
            echo twig_escape_filter($this->env, $this->getAttribute($context["service"], "priceFrom", array()), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["service"], "priceTo", array()), "html", null, true);
            echo "€</div>
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['service'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 128
        echo "                    </div>
                </div>
            </div>
            <div class=\"col-sm-4\">
                <h4>Sijainti</h4>
                
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <div id=\"company-map\"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

";
        
        $__internal_828658790ba17bc3c5c4b21f3ac92f958c03d8f6d6236987bb9cec4a5f83ff54->leave($__internal_828658790ba17bc3c5c4b21f3ac92f958c03d8f6d6236987bb9cec4a5f83ff54_prof);

        
        $__internal_3e59765da21ee8cabbea6a850cd1afdead31bbbf7aeaf63ed0a1806c2120f417->leave($__internal_3e59765da21ee8cabbea6a850cd1afdead31bbbf7aeaf63ed0a1806c2120f417_prof);

    }

    // line 146
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_133ecfd6f58d124e48b43f88fc8f2570ffa3d01a9fd7d1353c48b712feef1f76 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_133ecfd6f58d124e48b43f88fc8f2570ffa3d01a9fd7d1353c48b712feef1f76->enter($__internal_133ecfd6f58d124e48b43f88fc8f2570ffa3d01a9fd7d1353c48b712feef1f76_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_754dd6e8bb4bd8c112b7dbe757cc2fc8e426320511389321f7339a893f63a44b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_754dd6e8bb4bd8c112b7dbe757cc2fc8e426320511389321f7339a893f63a44b->enter($__internal_754dd6e8bb4bd8c112b7dbe757cc2fc8e426320511389321f7339a893f63a44b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_754dd6e8bb4bd8c112b7dbe757cc2fc8e426320511389321f7339a893f63a44b->leave($__internal_754dd6e8bb4bd8c112b7dbe757cc2fc8e426320511389321f7339a893f63a44b_prof);

        
        $__internal_133ecfd6f58d124e48b43f88fc8f2570ffa3d01a9fd7d1353c48b712feef1f76->leave($__internal_133ecfd6f58d124e48b43f88fc8f2570ffa3d01a9fd7d1353c48b712feef1f76_prof);

    }

    // line 149
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_909683af08fdcf1ddb450e22372d44742a093e79520660aaa46a9030455b6259 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_909683af08fdcf1ddb450e22372d44742a093e79520660aaa46a9030455b6259->enter($__internal_909683af08fdcf1ddb450e22372d44742a093e79520660aaa46a9030455b6259_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_4e0e74abb4b778ab5c47a3cb069d750a248193eb9102c50a906f256f94575df1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e0e74abb4b778ab5c47a3cb069d750a248193eb9102c50a906f256f94575df1->enter($__internal_4e0e74abb4b778ab5c47a3cb069d750a248193eb9102c50a906f256f94575df1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 150
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/company-map.js"), "html", null, true);
        echo "\"></script>
    <script src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyCevyWnSN7BgRT0r0RlOCNqpSEUcdV3_qs&language=fi&region=FI&callback=initMap\" async defer></script>
    <script src=\"";
        // line 152
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_4e0e74abb4b778ab5c47a3cb069d750a248193eb9102c50a906f256f94575df1->leave($__internal_4e0e74abb4b778ab5c47a3cb069d750a248193eb9102c50a906f256f94575df1_prof);

        
        $__internal_909683af08fdcf1ddb450e22372d44742a093e79520660aaa46a9030455b6259->leave($__internal_909683af08fdcf1ddb450e22372d44742a093e79520660aaa46a9030455b6259_prof);

    }

    public function getTemplateName()
    {
        return ":Company:company.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  351 => 152,  345 => 150,  336 => 149,  319 => 146,  293 => 128,  282 => 125,  278 => 124,  275 => 123,  270 => 122,  259 => 119,  255 => 118,  252 => 117,  248 => 116,  237 => 108,  226 => 100,  215 => 92,  204 => 84,  193 => 76,  182 => 68,  171 => 60,  156 => 48,  150 => 45,  144 => 42,  138 => 39,  132 => 36,  122 => 33,  116 => 30,  110 => 27,  104 => 23,  96 => 21,  90 => 19,  88 => 18,  77 => 9,  75 => 7,  70 => 4,  61 => 3,  43 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block title %}Yritys{% endblock %}
{% block body %}
<div class=\"container-fluid text-center\">
    <div class=\"row\">
        <div class=\"col-sm-12 search-container\">
            {{ render(controller(
                'AppBundle:Company:searchBar'
            )) }}
        </div>
    </div>
</div>

<div class=\"container-fluid bg-grey\">
    <div class=\"container\">
        <div class=\"row company-card\">
            <div class=\"col-sm-4 img-container\">
                {% if company.imageName == null %}
                    <img src=\"{{ asset('bundles/app/img/logo-placeholder.png') }}\" class=\"img-responsive\"></img>
                {% else %}
                    <img src=\"{{ vich_uploader_asset(company, 'imageFile') | imagine_filter('company') }}\" alt=\"{{ company.name }}\" class=\"img-responsive\" />
                {% endif %}
            </div>

            <div class=\"col-sm-8 company-card-infos\">
                <div>
                    <h2>{{ company.name }}</h2>
                </div>
                <div>
                    <h5>{{ company.vatId }}</h5>
                </div>
                <div>
                    <h5><i class=\"fa fa-map-marker\" aria-hidden=\"true\"></i> <label id=\"address\">{{ company.address }}</label>, <label id=\"postcode\">{{ company.postcode }}</label> <label id=\"city\">{{ company.city }}</label></h5>
                </div>
                <div>
                    <h5><i class=\"fa fa-phone\" aria-hidden=\"true\"></i> {{ company.phone }}</h5>
                </div>
                <div>
                    <h5><i class=\"fa fa-envelope\" aria-hidden=\"true\"></i> {{ company.email }}</h5>
                </div>
                <div>
                    <h5><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> {{ company.getCurrentOpeningHours() }}</h5>
                </div>
                <div>
                    <h5><i class=\"fa fa-eur\" aria-hidden=\"true\"></i> {{ company.getLowestPrice() }}</h5>
                </div>
                <div class=\"company-card-description\">
                    <p>{{ company.description }}</p>
                </div>
            </div>
        </div>
        <div class=\"row company-card\">
            <div class=\"col-sm-4\">
                <h4>Aukioloajat</h4>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        Maanantai
                    </div>
                    <div class=\"col-sm-6\">
                        {{ company.openingHoursMonday }}
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        Tiistai
                    </div>
                    <div class=\"col-sm-6\">
                        {{ company.openingHoursTuesday }}
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        Keskiviikko
                    </div>
                    <div class=\"col-sm-6\">
                        {{ company.openingHoursWednesday }}
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        Torstai
                    </div>
                    <div class=\"col-sm-6\">
                        {{ company.openingHoursThursday }}
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        Perjantai
                    </div>
                    <div class=\"col-sm-6\">
                        {{ company.openingHoursFriday }}
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        Lauantai
                    </div>
                    <div class=\"col-sm-6\">
                        {{ company.openingHoursSaturday }}
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-6\">
                        Sunnuntai
                    </div>
                    <div class=\"col-sm-6\">
                        {{ company.openingHoursSunday }}
                    </div>
                </div>
            </div>
            <div class=\"col-sm-4\">
                <h4>Palvelut ja hinnasto</h4>
                <div class=\"row\">
                    <div class=\"col-sm-12\" id=\"company-services-container\">
                        {% for defaultService in company.defaultServices %}
                            <div class=\"row\">
                                <div class=\"col-sm-6 company-service-name\">{{ defaultService.name.name }}</div>
                                <div class=\"col-sm-6 company-service-price\">{{ defaultService.priceFrom}} - {{ defaultService.priceTo }}€</div>
                            </div>
                        {% endfor %}
                        {% for service in company.services %}
                            <div class=\"row\">
                                <div class=\"col-sm-6 company-service-name\">{{ service.name }}</div>
                                <div class=\"col-sm-6 company-service-price\">{{ service.priceFrom}} - {{ service.priceTo }}€</div>
                            </div>
                        {% endfor %}
                    </div>
                </div>
            </div>
            <div class=\"col-sm-4\">
                <h4>Sijainti</h4>
                
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <div id=\"company-map\"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{% endblock %}

{% block stylesheets %}
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/company-map.js') }}\"></script>
    <script src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyCevyWnSN7BgRT0r0RlOCNqpSEUcdV3_qs&language=fi&region=FI&callback=initMap\" async defer></script>
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
{% endblock %}
", ":Company:company.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Company/company.html.twig");
    }
}
