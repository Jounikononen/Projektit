<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_f10d0655eaa0b259b7930866c9a2b4e4dc553fed4b7e9c7978634ff4fd99b4d1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_59a35a82d19da0ddd254ded82699f8baa34ee112b64380780d1b8478216455d7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_59a35a82d19da0ddd254ded82699f8baa34ee112b64380780d1b8478216455d7->enter($__internal_59a35a82d19da0ddd254ded82699f8baa34ee112b64380780d1b8478216455d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_7ae366f937b5662871ef463375efe92e4ca7fd31ad501f1b8472091d94a0f0e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7ae366f937b5662871ef463375efe92e4ca7fd31ad501f1b8472091d94a0f0e6->enter($__internal_7ae366f937b5662871ef463375efe92e4ca7fd31ad501f1b8472091d94a0f0e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_59a35a82d19da0ddd254ded82699f8baa34ee112b64380780d1b8478216455d7->leave($__internal_59a35a82d19da0ddd254ded82699f8baa34ee112b64380780d1b8478216455d7_prof);

        
        $__internal_7ae366f937b5662871ef463375efe92e4ca7fd31ad501f1b8472091d94a0f0e6->leave($__internal_7ae366f937b5662871ef463375efe92e4ca7fd31ad501f1b8472091d94a0f0e6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/password_widget.html.php");
    }
}
