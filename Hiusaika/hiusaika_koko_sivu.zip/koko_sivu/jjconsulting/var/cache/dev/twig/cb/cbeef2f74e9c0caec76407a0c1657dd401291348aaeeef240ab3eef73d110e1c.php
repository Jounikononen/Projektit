<?php

/* TwigBundle:Exception:error.xml.twig */
class __TwigTemplate_be38b3290309d08add04cef973f04e5f3f0f8b6a6e6a37d00b08a105cc8df649 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c617ea2f16a22658dc00a525765849493a08c5897eb39c8e569813f5b830d73a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c617ea2f16a22658dc00a525765849493a08c5897eb39c8e569813f5b830d73a->enter($__internal_c617ea2f16a22658dc00a525765849493a08c5897eb39c8e569813f5b830d73a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.xml.twig"));

        $__internal_ec93e1e1e9ddc738aaa6d301591cdefeb2a99206b13697433cc203bf4fceb788 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ec93e1e1e9ddc738aaa6d301591cdefeb2a99206b13697433cc203bf4fceb788->enter($__internal_ec93e1e1e9ddc738aaa6d301591cdefeb2a99206b13697433cc203bf4fceb788_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.xml.twig"));

        // line 1
        echo "<?xml version=\"1.0\" encoding=\"";
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" ?>

<error code=\"";
        // line 3
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo "\" message=\"";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo "\" />
";
        
        $__internal_c617ea2f16a22658dc00a525765849493a08c5897eb39c8e569813f5b830d73a->leave($__internal_c617ea2f16a22658dc00a525765849493a08c5897eb39c8e569813f5b830d73a_prof);

        
        $__internal_ec93e1e1e9ddc738aaa6d301591cdefeb2a99206b13697433cc203bf4fceb788->leave($__internal_ec93e1e1e9ddc738aaa6d301591cdefeb2a99206b13697433cc203bf4fceb788_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 3,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?xml version=\"1.0\" encoding=\"{{ _charset }}\" ?>

<error code=\"{{ status_code }}\" message=\"{{ status_text }}\" />
", "TwigBundle:Exception:error.xml.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.xml.twig");
    }
}
