<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_ee6021a69ff81b5a2e3a0cbc9d59783fc61a191a1f3e4fbd2d83dee838aa4142 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8be724d32735b9c30a6a4e61021aaa02979e7b2d71811ee4c24bd6b7c5d33365 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8be724d32735b9c30a6a4e61021aaa02979e7b2d71811ee4c24bd6b7c5d33365->enter($__internal_8be724d32735b9c30a6a4e61021aaa02979e7b2d71811ee4c24bd6b7c5d33365_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_36c24ed4132060a460aaab0bc6dce0676c5a189282261305dd38752f0a120ffd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36c24ed4132060a460aaab0bc6dce0676c5a189282261305dd38752f0a120ffd->enter($__internal_36c24ed4132060a460aaab0bc6dce0676c5a189282261305dd38752f0a120ffd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_8be724d32735b9c30a6a4e61021aaa02979e7b2d71811ee4c24bd6b7c5d33365->leave($__internal_8be724d32735b9c30a6a4e61021aaa02979e7b2d71811ee4c24bd6b7c5d33365_prof);

        
        $__internal_36c24ed4132060a460aaab0bc6dce0676c5a189282261305dd38752f0a120ffd->leave($__internal_36c24ed4132060a460aaab0bc6dce0676c5a189282261305dd38752f0a120ffd_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.atom.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
