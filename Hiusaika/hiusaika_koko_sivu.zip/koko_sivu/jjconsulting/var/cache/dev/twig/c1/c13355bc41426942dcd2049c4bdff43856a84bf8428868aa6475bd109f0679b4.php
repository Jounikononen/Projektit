<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_aba35c79d05cddf23ae77507ab88f86d4b986da884823f962708b4498b3d93e2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f1efb0bf06ce8d28eaee30c9659cd889a03a890d8fc60aedf16c072b51a882d2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f1efb0bf06ce8d28eaee30c9659cd889a03a890d8fc60aedf16c072b51a882d2->enter($__internal_f1efb0bf06ce8d28eaee30c9659cd889a03a890d8fc60aedf16c072b51a882d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_aaa38f171d3ace9eafd14e8590a40c28aeb1d6e8c2c19ac88c820c5b94b3c6c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aaa38f171d3ace9eafd14e8590a40c28aeb1d6e8c2c19ac88c820c5b94b3c6c5->enter($__internal_aaa38f171d3ace9eafd14e8590a40c28aeb1d6e8c2c19ac88c820c5b94b3c6c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_f1efb0bf06ce8d28eaee30c9659cd889a03a890d8fc60aedf16c072b51a882d2->leave($__internal_f1efb0bf06ce8d28eaee30c9659cd889a03a890d8fc60aedf16c072b51a882d2_prof);

        
        $__internal_aaa38f171d3ace9eafd14e8590a40c28aeb1d6e8c2c19ac88c820c5b94b3c6c5->leave($__internal_aaa38f171d3ace9eafd14e8590a40c28aeb1d6e8c2c19ac88c820c5b94b3c6c5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_label.html.php");
    }
}
