<?php

/* @Framework/Form/widget_container_attributes.html.php */
class __TwigTemplate_1b08baa6d1614bfe0a8907eaa22c4f324ea8385c8eed10d60e8e023165516ee2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_63bf0a128637a83618ec45c69d015f7421d071bb6f8b6476cfccaa6d6824b552 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_63bf0a128637a83618ec45c69d015f7421d071bb6f8b6476cfccaa6d6824b552->enter($__internal_63bf0a128637a83618ec45c69d015f7421d071bb6f8b6476cfccaa6d6824b552_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        $__internal_e4ce545e0db19d79ace1e9f886cba8484712eae18e01c2b50cd168e8bab0b7f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e4ce545e0db19d79ace1e9f886cba8484712eae18e01c2b50cd168e8bab0b7f8->enter($__internal_e4ce545e0db19d79ace1e9f886cba8484712eae18e01c2b50cd168e8bab0b7f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        // line 1
        echo "<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_63bf0a128637a83618ec45c69d015f7421d071bb6f8b6476cfccaa6d6824b552->leave($__internal_63bf0a128637a83618ec45c69d015f7421d071bb6f8b6476cfccaa6d6824b552_prof);

        
        $__internal_e4ce545e0db19d79ace1e9f886cba8484712eae18e01c2b50cd168e8bab0b7f8->leave($__internal_e4ce545e0db19d79ace1e9f886cba8484712eae18e01c2b50cd168e8bab0b7f8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_container_attributes.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/widget_container_attributes.html.php");
    }
}
