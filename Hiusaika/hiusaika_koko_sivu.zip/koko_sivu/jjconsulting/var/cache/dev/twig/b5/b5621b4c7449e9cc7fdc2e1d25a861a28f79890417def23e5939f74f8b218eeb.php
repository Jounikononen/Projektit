<?php

/* Layout/searchBar.html.twig */
class __TwigTemplate_bde1d5184dc7ead926f87d9e01ac8e8697a4f4a3bd7afcf7bb221a70ff72d850 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_902d0e8269943f291c34fcb73897505199c8ed0d53792baf74c37851e04be2e4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_902d0e8269943f291c34fcb73897505199c8ed0d53792baf74c37851e04be2e4->enter($__internal_902d0e8269943f291c34fcb73897505199c8ed0d53792baf74c37851e04be2e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Layout/searchBar.html.twig"));

        $__internal_3775c4816521853d990ad7201ee28479342690db1d148023a9c8ca3fbd4b697e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3775c4816521853d990ad7201ee28479342690db1d148023a9c8ca3fbd4b697e->enter($__internal_3775c4816521853d990ad7201ee28479342690db1d148023a9c8ca3fbd4b697e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Layout/searchBar.html.twig"));

        // line 1
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("searchCompany"))));
        // line 3
        echo "
    <div class=\"input-group\">
        ";
        // line 5
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "q", array()), 'widget');
        echo "
        <div class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-danger\">Hae</button>
        </div>
    </div>
";
        // line 10
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        
        $__internal_902d0e8269943f291c34fcb73897505199c8ed0d53792baf74c37851e04be2e4->leave($__internal_902d0e8269943f291c34fcb73897505199c8ed0d53792baf74c37851e04be2e4_prof);

        
        $__internal_3775c4816521853d990ad7201ee28479342690db1d148023a9c8ca3fbd4b697e->leave($__internal_3775c4816521853d990ad7201ee28479342690db1d148023a9c8ca3fbd4b697e_prof);

    }

    public function getTemplateName()
    {
        return "Layout/searchBar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  39 => 10,  31 => 5,  27 => 3,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{form_start(form, {
    'attr': {'action': path('searchCompany')}
}) }}
    <div class=\"input-group\">
        {{ form_widget(form.q) }}
        <div class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-danger\">Hae</button>
        </div>
    </div>
{{form_end(form)}}", "Layout/searchBar.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Layout/searchBar.html.twig");
    }
}
