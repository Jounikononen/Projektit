<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_80e6e1ffb40c27a39044545fb0d8507f9a5d1fee353c92bed6ee40e18208c438 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6ff79de223e532246674db3bffcc306dbeba247d985ce1a258539b62295ac9b3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6ff79de223e532246674db3bffcc306dbeba247d985ce1a258539b62295ac9b3->enter($__internal_6ff79de223e532246674db3bffcc306dbeba247d985ce1a258539b62295ac9b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_f28428cbe1b4b8047aa476bf769b8988c61fd2f824f267e7a3e2f8853e5e1f8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f28428cbe1b4b8047aa476bf769b8988c61fd2f824f267e7a3e2f8853e5e1f8d->enter($__internal_f28428cbe1b4b8047aa476bf769b8988c61fd2f824f267e7a3e2f8853e5e1f8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_6ff79de223e532246674db3bffcc306dbeba247d985ce1a258539b62295ac9b3->leave($__internal_6ff79de223e532246674db3bffcc306dbeba247d985ce1a258539b62295ac9b3_prof);

        
        $__internal_f28428cbe1b4b8047aa476bf769b8988c61fd2f824f267e7a3e2f8853e5e1f8d->leave($__internal_f28428cbe1b4b8047aa476bf769b8988c61fd2f824f267e7a3e2f8853e5e1f8d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form.html.php");
    }
}
