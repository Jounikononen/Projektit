<?php

/* :Emails:registrationAdminNotification.html.twig */
class __TwigTemplate_8d2ac7926795c6a6ca7eb59713f7ee77cf8b4f7d1c16c1095336663a1b95dfc9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2fd5bdbada97b0e989841a155592d52968314f25edca634033e0859b69e66359 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2fd5bdbada97b0e989841a155592d52968314f25edca634033e0859b69e66359->enter($__internal_2fd5bdbada97b0e989841a155592d52968314f25edca634033e0859b69e66359_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Emails:registrationAdminNotification.html.twig"));

        $__internal_e82b13938afe6e9504b1ee7e2df4fd30e0a905d5b05246f2306b76c2f6286bb1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e82b13938afe6e9504b1ee7e2df4fd30e0a905d5b05246f2306b76c2f6286bb1->enter($__internal_e82b13938afe6e9504b1ee7e2df4fd30e0a905d5b05246f2306b76c2f6286bb1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Emails:registrationAdminNotification.html.twig"));

        // line 1
        echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
    <title>Uusi yritys rekisteröity</title>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"/>
</head>
<body>
    <h1>Uusi yritys on rekisteröitynyt palveluun</h1>
    
    <h2>Yrityksen tiedot</h2>
    <ul>
        <li>Nimi: ";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "name", array()), "html", null, true);
        echo "</li>
        <li>Y-tunnus: ";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "vatId", array()), "html", null, true);
        echo "</li>
    </ul>
    
    <p>
        Ylläpitäjän on vahvistettava yritys hallintapaneelin kautta.
    </p>
    <p>
        Kirjaudu sisään hallintapaneeliin <a href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
        echo "\">tästä</a>.
    </p>
</body>
</html>";
        
        $__internal_2fd5bdbada97b0e989841a155592d52968314f25edca634033e0859b69e66359->leave($__internal_2fd5bdbada97b0e989841a155592d52968314f25edca634033e0859b69e66359_prof);

        
        $__internal_e82b13938afe6e9504b1ee7e2df4fd30e0a905d5b05246f2306b76c2f6286bb1->leave($__internal_e82b13938afe6e9504b1ee7e2df4fd30e0a905d5b05246f2306b76c2f6286bb1_prof);

    }

    public function getTemplateName()
    {
        return ":Emails:registrationAdminNotification.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 21,  43 => 14,  39 => 13,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
    <title>Uusi yritys rekisteröity</title>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"/>
</head>
<body>
    <h1>Uusi yritys on rekisteröitynyt palveluun</h1>
    
    <h2>Yrityksen tiedot</h2>
    <ul>
        <li>Nimi: {{ company.name }}</li>
        <li>Y-tunnus: {{ company.vatId }}</li>
    </ul>
    
    <p>
        Ylläpitäjän on vahvistettava yritys hallintapaneelin kautta.
    </p>
    <p>
        Kirjaudu sisään hallintapaneeliin <a href=\"{{ path('fos_user_security_login') }}\">tästä</a>.
    </p>
</body>
</html>", ":Emails:registrationAdminNotification.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Emails/registrationAdminNotification.html.twig");
    }
}
