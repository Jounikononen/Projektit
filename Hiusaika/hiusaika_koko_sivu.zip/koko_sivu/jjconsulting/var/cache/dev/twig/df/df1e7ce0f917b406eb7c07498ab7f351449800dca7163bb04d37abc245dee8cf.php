<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_a021f285d1f1cd236676004b4ada535474730fc4a8ee2efc3f190aa995688513 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8ddbceb6cf460512673ca192d57b7a533b24593b398920034230dc87532151f5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8ddbceb6cf460512673ca192d57b7a533b24593b398920034230dc87532151f5->enter($__internal_8ddbceb6cf460512673ca192d57b7a533b24593b398920034230dc87532151f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        $__internal_faa1691285a28a25cda0056b31a303f26b57cdc5e1eee5609568b281c35ee118 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_faa1691285a28a25cda0056b31a303f26b57cdc5e1eee5609568b281c35ee118->enter($__internal_faa1691285a28a25cda0056b31a303f26b57cdc5e1eee5609568b281c35ee118_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_8ddbceb6cf460512673ca192d57b7a533b24593b398920034230dc87532151f5->leave($__internal_8ddbceb6cf460512673ca192d57b7a533b24593b398920034230dc87532151f5_prof);

        
        $__internal_faa1691285a28a25cda0056b31a303f26b57cdc5e1eee5609568b281c35ee118->leave($__internal_faa1691285a28a25cda0056b31a303f26b57cdc5e1eee5609568b281c35ee118_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.css.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.css.twig");
    }
}
