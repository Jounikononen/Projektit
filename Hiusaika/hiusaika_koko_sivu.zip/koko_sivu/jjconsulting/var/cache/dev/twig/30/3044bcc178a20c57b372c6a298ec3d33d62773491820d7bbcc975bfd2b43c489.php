<?php

/* :Company:search.html.twig */
class __TwigTemplate_844dfffb5ceaadf20173ff48da4ae53c9bb7ad297c6c00d3eda7b2dd022f2be0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Company:search.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'pagination' => array($this, 'block_pagination'),
            'resultCount' => array($this, 'block_resultCount'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c3e021e741ef2a06ccdb20dc44e1290e490793c43ce05cf842b02e7a9c449932 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c3e021e741ef2a06ccdb20dc44e1290e490793c43ce05cf842b02e7a9c449932->enter($__internal_c3e021e741ef2a06ccdb20dc44e1290e490793c43ce05cf842b02e7a9c449932_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Company:search.html.twig"));

        $__internal_27369b5acadb6f9f54b1316034a21d4a372d6f9f26546a7264223c5deef247bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_27369b5acadb6f9f54b1316034a21d4a372d6f9f26546a7264223c5deef247bb->enter($__internal_27369b5acadb6f9f54b1316034a21d4a372d6f9f26546a7264223c5deef247bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Company:search.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c3e021e741ef2a06ccdb20dc44e1290e490793c43ce05cf842b02e7a9c449932->leave($__internal_c3e021e741ef2a06ccdb20dc44e1290e490793c43ce05cf842b02e7a9c449932_prof);

        
        $__internal_27369b5acadb6f9f54b1316034a21d4a372d6f9f26546a7264223c5deef247bb->leave($__internal_27369b5acadb6f9f54b1316034a21d4a372d6f9f26546a7264223c5deef247bb_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_03ff699090d07da10286e9b04f8cb1e705f1a51f77526340a28bcc5eccb98b91 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_03ff699090d07da10286e9b04f8cb1e705f1a51f77526340a28bcc5eccb98b91->enter($__internal_03ff699090d07da10286e9b04f8cb1e705f1a51f77526340a28bcc5eccb98b91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_918d2f7246169840460704220b31dbc01cc7851c7bd3990b6fbd313e6e64d473 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_918d2f7246169840460704220b31dbc01cc7851c7bd3990b6fbd313e6e64d473->enter($__internal_918d2f7246169840460704220b31dbc01cc7851c7bd3990b6fbd313e6e64d473_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Yrityshaku";
        
        $__internal_918d2f7246169840460704220b31dbc01cc7851c7bd3990b6fbd313e6e64d473->leave($__internal_918d2f7246169840460704220b31dbc01cc7851c7bd3990b6fbd313e6e64d473_prof);

        
        $__internal_03ff699090d07da10286e9b04f8cb1e705f1a51f77526340a28bcc5eccb98b91->leave($__internal_03ff699090d07da10286e9b04f8cb1e705f1a51f77526340a28bcc5eccb98b91_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_897537705f6bae70a957769c210f1ebb2777181fb36b9dda6b2e3a5e8fcd4d2d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_897537705f6bae70a957769c210f1ebb2777181fb36b9dda6b2e3a5e8fcd4d2d->enter($__internal_897537705f6bae70a957769c210f1ebb2777181fb36b9dda6b2e3a5e8fcd4d2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_768aeedadb2e8cf58dd7e9173fd5d36549518bf19492c3dbf9b3f033b301f78d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_768aeedadb2e8cf58dd7e9173fd5d36549518bf19492c3dbf9b3f033b301f78d->enter($__internal_768aeedadb2e8cf58dd7e9173fd5d36549518bf19492c3dbf9b3f033b301f78d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container-fluid text-center\">
        <div class=\"row\">
            <div class=\"col-sm-12 search-container\">
                <h2>Yrityshaku</h2>
                ";
        // line 8
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Company:searchBar", array("q" =>         // line 10
($context["keyword"] ?? $this->getContext($context, "keyword")))));
        // line 11
        echo "
                
                ";
        // line 23
        echo "            </div>
        </div>
    </div>

    <div class=\"container-fluid bg-grey\">
        <div class=\"container\">
            ";
        // line 29
        if (twig_test_empty(($context["pagination"] ?? $this->getContext($context, "pagination")))) {
            // line 30
            echo "                <div class=\"row\">
                    <div class=\"col-sm-12 text-center\">
                        <p>Ei tuloksia</p>
                    </div>
                </div>
            ";
        } else {
            // line 36
            echo "                ";
            $this->displayBlock("pagination", $context, $blocks);
            echo "
                ";
            // line 37
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["pagination"] ?? $this->getContext($context, "pagination")));
            foreach ($context['_seq'] as $context["_key"] => $context["company"]) {
                // line 38
                echo "                    <div class=\"row\">
                        <div class=\"col-sm-8 col-sm-offset-2\">
                            <a href=\"";
                // line 40
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("viewCompany", array("hashId" => $this->env->getExtension('AppBundle\Extension\TwigExtensions')->urlIdHasherEncode($this->getAttribute($context["company"], "id", array())))), "html", null, true);
                echo "\">
                                <div class=\"row search-result\">
                                    <div class=\"col-sm-4 text-center img-container\">
                                        ";
                // line 43
                if (($this->getAttribute($context["company"], "imageName", array()) == null)) {
                    // line 44
                    echo "                                            <img src=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/img/logo-placeholder.png"), "html", null, true);
                    echo "\" class=\"img-responsive\"></img>
                                        ";
                } else {
                    // line 46
                    echo "                                            <img src=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Liip\ImagineBundle\Templating\ImagineExtension')->filter($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset($context["company"], "imageFile"), "company_thumb"), "html", null, true);
                    echo "\" alt=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "name", array()), "html", null, true);
                    echo "\" class=\"img-responsive\" />
                                        ";
                }
                // line 48
                echo "                                    </div>

                                    <div class=\"col-sm-8 search-card-infos\">
                                        <div>
                                            <h3>";
                // line 52
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "name", array()), "html", null, true);
                echo " </h3>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-map-marker\" aria-hidden=\"true\"></i> ";
                // line 55
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "address", array()), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "postcode", array()), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "city", array()), "html", null, true);
                echo "</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-phone\" aria-hidden=\"true\"></i> ";
                // line 58
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "phone", array()), "html", null, true);
                echo "</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-envelope\" aria-hidden=\"true\"></i> ";
                // line 61
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "email", array()), "html", null, true);
                echo "</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> ";
                // line 64
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "getCurrentOpeningHours", array(), "method"), "html", null, true);
                echo "</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-eur\" aria-hidden=\"true\"></i> ";
                // line 67
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "getLowestPrice", array(), "method"), "html", null, true);
                echo "</h5>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['company'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 75
            echo "                ";
            $this->displayBlock("pagination", $context, $blocks);
            echo "
            ";
        }
        // line 77
        echo "        </div>
    </div>
";
        
        $__internal_768aeedadb2e8cf58dd7e9173fd5d36549518bf19492c3dbf9b3f033b301f78d->leave($__internal_768aeedadb2e8cf58dd7e9173fd5d36549518bf19492c3dbf9b3f033b301f78d_prof);

        
        $__internal_897537705f6bae70a957769c210f1ebb2777181fb36b9dda6b2e3a5e8fcd4d2d->leave($__internal_897537705f6bae70a957769c210f1ebb2777181fb36b9dda6b2e3a5e8fcd4d2d_prof);

    }

    // line 81
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_3d34a8661837fa32e1dde9e1b9b378de1a9adb2d2e84ee191d65a795d0d3d789 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3d34a8661837fa32e1dde9e1b9b378de1a9adb2d2e84ee191d65a795d0d3d789->enter($__internal_3d34a8661837fa32e1dde9e1b9b378de1a9adb2d2e84ee191d65a795d0d3d789_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_755e7a66a9055278fa71394d90a7c4ab2c92494061c18deaf37bde458c3db23e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_755e7a66a9055278fa71394d90a7c4ab2c92494061c18deaf37bde458c3db23e->enter($__internal_755e7a66a9055278fa71394d90a7c4ab2c92494061c18deaf37bde458c3db23e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_755e7a66a9055278fa71394d90a7c4ab2c92494061c18deaf37bde458c3db23e->leave($__internal_755e7a66a9055278fa71394d90a7c4ab2c92494061c18deaf37bde458c3db23e_prof);

        
        $__internal_3d34a8661837fa32e1dde9e1b9b378de1a9adb2d2e84ee191d65a795d0d3d789->leave($__internal_3d34a8661837fa32e1dde9e1b9b378de1a9adb2d2e84ee191d65a795d0d3d789_prof);

    }

    // line 84
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_6d72a8d4ac6de33a7a4d12fe9a77dad4efc44f8c25cb236106b3c9b1e159970b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6d72a8d4ac6de33a7a4d12fe9a77dad4efc44f8c25cb236106b3c9b1e159970b->enter($__internal_6d72a8d4ac6de33a7a4d12fe9a77dad4efc44f8c25cb236106b3c9b1e159970b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_e5d0299cdae22cfabac06d5fc5ef639882519047e1dba865ed5356d23b7a2f8f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e5d0299cdae22cfabac06d5fc5ef639882519047e1dba865ed5356d23b7a2f8f->enter($__internal_e5d0299cdae22cfabac06d5fc5ef639882519047e1dba865ed5356d23b7a2f8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 85
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_e5d0299cdae22cfabac06d5fc5ef639882519047e1dba865ed5356d23b7a2f8f->leave($__internal_e5d0299cdae22cfabac06d5fc5ef639882519047e1dba865ed5356d23b7a2f8f_prof);

        
        $__internal_6d72a8d4ac6de33a7a4d12fe9a77dad4efc44f8c25cb236106b3c9b1e159970b->leave($__internal_6d72a8d4ac6de33a7a4d12fe9a77dad4efc44f8c25cb236106b3c9b1e159970b_prof);

    }

    // line 88
    public function block_pagination($context, array $blocks = array())
    {
        $__internal_22ced11c67638128b080832fd9cee8248c9ddca66d3f9d8e7b834c71ddaf3594 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_22ced11c67638128b080832fd9cee8248c9ddca66d3f9d8e7b834c71ddaf3594->enter($__internal_22ced11c67638128b080832fd9cee8248c9ddca66d3f9d8e7b834c71ddaf3594_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "pagination"));

        $__internal_79f8ff3c84dbe29efa9f1c7d0ffaf8d600d00073937e205deb67d530fd7cab8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_79f8ff3c84dbe29efa9f1c7d0ffaf8d600d00073937e205deb67d530fd7cab8d->enter($__internal_79f8ff3c84dbe29efa9f1c7d0ffaf8d600d00073937e205deb67d530fd7cab8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "pagination"));

        // line 89
        echo "    <div class=\"row\">
        <div class=\"col-sm-12 text-center\">
            ";
        // line 91
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, ($context["pagination"] ?? $this->getContext($context, "pagination")));
        echo "
        </div>
    </div>
";
        
        $__internal_79f8ff3c84dbe29efa9f1c7d0ffaf8d600d00073937e205deb67d530fd7cab8d->leave($__internal_79f8ff3c84dbe29efa9f1c7d0ffaf8d600d00073937e205deb67d530fd7cab8d_prof);

        
        $__internal_22ced11c67638128b080832fd9cee8248c9ddca66d3f9d8e7b834c71ddaf3594->leave($__internal_22ced11c67638128b080832fd9cee8248c9ddca66d3f9d8e7b834c71ddaf3594_prof);

    }

    // line 96
    public function block_resultCount($context, array $blocks = array())
    {
        $__internal_b25a738ba3b9f048f5dcf3fac14de7651859dc89683d17b4bfdcef0f18dc37aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b25a738ba3b9f048f5dcf3fac14de7651859dc89683d17b4bfdcef0f18dc37aa->enter($__internal_b25a738ba3b9f048f5dcf3fac14de7651859dc89683d17b4bfdcef0f18dc37aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "resultCount"));

        $__internal_191bdbb0024a968f576faea3fea9a3062783aed1ae0717a3a9e6f65db9bf60ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_191bdbb0024a968f576faea3fea9a3062783aed1ae0717a3a9e6f65db9bf60ff->enter($__internal_191bdbb0024a968f576faea3fea9a3062783aed1ae0717a3a9e6f65db9bf60ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "resultCount"));

        // line 97
        echo "    <div class=\"col-sm-12 text-center\">
        ";
        // line 98
        if (($this->getAttribute(($context["pagination"] ?? $this->getContext($context, "pagination")), "getTotalItemCount", array(), "method") != 0)) {
            // line 99
            echo "            <span>Näytetään /";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["pagination"] ?? $this->getContext($context, "pagination")), "getTotalItemCount", array()), "html", null, true);
            echo " yrityksestä</span>
        ";
        }
        // line 101
        echo "    </div>
";
        
        $__internal_191bdbb0024a968f576faea3fea9a3062783aed1ae0717a3a9e6f65db9bf60ff->leave($__internal_191bdbb0024a968f576faea3fea9a3062783aed1ae0717a3a9e6f65db9bf60ff_prof);

        
        $__internal_b25a738ba3b9f048f5dcf3fac14de7651859dc89683d17b4bfdcef0f18dc37aa->leave($__internal_b25a738ba3b9f048f5dcf3fac14de7651859dc89683d17b4bfdcef0f18dc37aa_prof);

    }

    public function getTemplateName()
    {
        return ":Company:search.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  296 => 101,  290 => 99,  288 => 98,  285 => 97,  276 => 96,  262 => 91,  258 => 89,  249 => 88,  236 => 85,  227 => 84,  210 => 81,  198 => 77,  192 => 75,  178 => 67,  172 => 64,  166 => 61,  160 => 58,  150 => 55,  144 => 52,  138 => 48,  130 => 46,  124 => 44,  122 => 43,  116 => 40,  112 => 38,  108 => 37,  103 => 36,  95 => 30,  93 => 29,  85 => 23,  81 => 11,  79 => 10,  78 => 8,  72 => 4,  63 => 3,  45 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block title %}Yrityshaku{% endblock %}
{% block body %}
    <div class=\"container-fluid text-center\">
        <div class=\"row\">
            <div class=\"col-sm-12 search-container\">
                <h2>Yrityshaku</h2>
                {{ render(controller(
                    'AppBundle:Company:searchBar',
                    { 'q' : keyword }
                )) }}
                
                {#{% if keyword is not null %} 
                    <div class=\"row\">
                        <div class=\"col-sm-12 text-center\">
                            <label class=\"search-keyword\">{{ keyword }}
                            <a href=\"{{ path('searchCompany') }}\">
                                 <i class=\"fa fa-times\"></i></label>
                            </a>
                        </div>
                    </div>
                {% endif %}#}
            </div>
        </div>
    </div>

    <div class=\"container-fluid bg-grey\">
        <div class=\"container\">
            {% if pagination is empty %}
                <div class=\"row\">
                    <div class=\"col-sm-12 text-center\">
                        <p>Ei tuloksia</p>
                    </div>
                </div>
            {% else %}
                {{ block('pagination') }}
                {% for company in pagination %}
                    <div class=\"row\">
                        <div class=\"col-sm-8 col-sm-offset-2\">
                            <a href=\"{{ path('viewCompany', {'hashId': url_id_hasher_encode(company.id) }) }}\">
                                <div class=\"row search-result\">
                                    <div class=\"col-sm-4 text-center img-container\">
                                        {% if company.imageName == null %}
                                            <img src=\"{{ asset('bundles/app/img/logo-placeholder.png') }}\" class=\"img-responsive\"></img>
                                        {% else %}
                                            <img src=\"{{ vich_uploader_asset(company, 'imageFile') | imagine_filter('company_thumb') }}\" alt=\"{{ company.name }}\" class=\"img-responsive\" />
                                        {% endif %}
                                    </div>

                                    <div class=\"col-sm-8 search-card-infos\">
                                        <div>
                                            <h3>{{ company.name }} </h3>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-map-marker\" aria-hidden=\"true\"></i> {{ company.address }}, {{ company.postcode }} {{ company.city }}</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-phone\" aria-hidden=\"true\"></i> {{ company.phone }}</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-envelope\" aria-hidden=\"true\"></i> {{ company.email }}</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> {{ company.getCurrentOpeningHours() }}</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-eur\" aria-hidden=\"true\"></i> {{ company.getLowestPrice() }}</h5>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                {% endfor %}
                {{ block('pagination') }}
            {% endif %}
        </div>
    </div>
{% endblock %}

{% block stylesheets %}
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
{% endblock %}

{% block pagination %}
    <div class=\"row\">
        <div class=\"col-sm-12 text-center\">
            {{ knp_pagination_render(pagination) }}
        </div>
    </div>
{% endblock %}

{% block resultCount %}
    <div class=\"col-sm-12 text-center\">
        {% if pagination.getTotalItemCount() != 0 %}
            <span>Näytetään /{{ pagination.getTotalItemCount }} yrityksestä</span>
        {% endif %}
    </div>
{% endblock %}", ":Company:search.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Company/search.html.twig");
    }
}
