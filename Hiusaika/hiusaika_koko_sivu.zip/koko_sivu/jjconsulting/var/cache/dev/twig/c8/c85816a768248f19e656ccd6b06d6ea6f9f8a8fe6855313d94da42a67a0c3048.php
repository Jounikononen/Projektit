<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_d21a07fbea0927098fabed7ab127e33d1ef869d00125ec2b072f0e4600a33b4c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f3ae0f9b28837921c2bce6a97cf0774c83a4efa133e2219e706ed1a57d2d1b65 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f3ae0f9b28837921c2bce6a97cf0774c83a4efa133e2219e706ed1a57d2d1b65->enter($__internal_f3ae0f9b28837921c2bce6a97cf0774c83a4efa133e2219e706ed1a57d2d1b65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        $__internal_3cfbf6de9e1c26d4d830cfabcf866e7a137ccf33f5fddb744d0b9b865c14a017 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3cfbf6de9e1c26d4d830cfabcf866e7a137ccf33f5fddb744d0b9b865c14a017->enter($__internal_3cfbf6de9e1c26d4d830cfabcf866e7a137ccf33f5fddb744d0b9b865c14a017_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_f3ae0f9b28837921c2bce6a97cf0774c83a4efa133e2219e706ed1a57d2d1b65->leave($__internal_f3ae0f9b28837921c2bce6a97cf0774c83a4efa133e2219e706ed1a57d2d1b65_prof);

        
        $__internal_3cfbf6de9e1c26d4d830cfabcf866e7a137ccf33f5fddb744d0b9b865c14a017->leave($__internal_3cfbf6de9e1c26d4d830cfabcf866e7a137ccf33f5fddb744d0b9b865c14a017_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "TwigBundle:Exception:exception.js.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.js.twig");
    }
}
