<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_366a21bac71bc41cce1b352c39ddb41daa9c8e5a1b04d9010816c967b4ffa859 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e8e67d0ccdef4035754f69bb0ea71526beb3a8d5e5674ad24a7a09a9890dc2eb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e8e67d0ccdef4035754f69bb0ea71526beb3a8d5e5674ad24a7a09a9890dc2eb->enter($__internal_e8e67d0ccdef4035754f69bb0ea71526beb3a8d5e5674ad24a7a09a9890dc2eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        $__internal_34e0d21352002247fdc4da17983c7ea90ccd1ee1b098db093155d015ce7243bc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_34e0d21352002247fdc4da17983c7ea90ccd1ee1b098db093155d015ce7243bc->enter($__internal_34e0d21352002247fdc4da17983c7ea90ccd1ee1b098db093155d015ce7243bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes'); ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form); ?>
        </td>
    </tr>
    <?php endif; ?>
    <?php echo \$view['form']->block(\$form, 'form_rows'); ?>
    <?php echo \$view['form']->rest(\$form); ?>
</table>
";
        
        $__internal_e8e67d0ccdef4035754f69bb0ea71526beb3a8d5e5674ad24a7a09a9890dc2eb->leave($__internal_e8e67d0ccdef4035754f69bb0ea71526beb3a8d5e5674ad24a7a09a9890dc2eb_prof);

        
        $__internal_34e0d21352002247fdc4da17983c7ea90ccd1ee1b098db093155d015ce7243bc->leave($__internal_34e0d21352002247fdc4da17983c7ea90ccd1ee1b098db093155d015ce7243bc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes'); ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form); ?>
        </td>
    </tr>
    <?php endif; ?>
    <?php echo \$view['form']->block(\$form, 'form_rows'); ?>
    <?php echo \$view['form']->rest(\$form); ?>
</table>
", "@Framework/FormTable/form_widget_compound.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/form_widget_compound.html.php");
    }
}
