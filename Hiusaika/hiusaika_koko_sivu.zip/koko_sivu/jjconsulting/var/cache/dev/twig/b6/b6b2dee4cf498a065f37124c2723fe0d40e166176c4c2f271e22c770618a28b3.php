<?php

/* :Admin:index.html.twig */
class __TwigTemplate_2ad2d702351451eb91c1af5628aac511a059c432c62d4126392356431325c1b5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Admin:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4183ee5f9c064e48a1ce9e96ac1eac5f4a3d7dff65a7228a6d8839a52e548725 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4183ee5f9c064e48a1ce9e96ac1eac5f4a3d7dff65a7228a6d8839a52e548725->enter($__internal_4183ee5f9c064e48a1ce9e96ac1eac5f4a3d7dff65a7228a6d8839a52e548725_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:index.html.twig"));

        $__internal_d9054dc6dcc1bdcf0099ae4f0588516bbf35fa9530d93b7d322451678834febf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d9054dc6dcc1bdcf0099ae4f0588516bbf35fa9530d93b7d322451678834febf->enter($__internal_d9054dc6dcc1bdcf0099ae4f0588516bbf35fa9530d93b7d322451678834febf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4183ee5f9c064e48a1ce9e96ac1eac5f4a3d7dff65a7228a6d8839a52e548725->leave($__internal_4183ee5f9c064e48a1ce9e96ac1eac5f4a3d7dff65a7228a6d8839a52e548725_prof);

        
        $__internal_d9054dc6dcc1bdcf0099ae4f0588516bbf35fa9530d93b7d322451678834febf->leave($__internal_d9054dc6dcc1bdcf0099ae4f0588516bbf35fa9530d93b7d322451678834febf_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_d9908279a80fdd59dd34d70bb12b88c4c8482ddd3c00e7b815f8295362fbfd4a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d9908279a80fdd59dd34d70bb12b88c4c8482ddd3c00e7b815f8295362fbfd4a->enter($__internal_d9908279a80fdd59dd34d70bb12b88c4c8482ddd3c00e7b815f8295362fbfd4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e7055210135efe6e1edb460190fb7261fce026dc9041583017e1f28f0eb8cafe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e7055210135efe6e1edb460190fb7261fce026dc9041583017e1f28f0eb8cafe->enter($__internal_e7055210135efe6e1edb460190fb7261fce026dc9041583017e1f28f0eb8cafe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Hallintapaneeli";
        
        $__internal_e7055210135efe6e1edb460190fb7261fce026dc9041583017e1f28f0eb8cafe->leave($__internal_e7055210135efe6e1edb460190fb7261fce026dc9041583017e1f28f0eb8cafe_prof);

        
        $__internal_d9908279a80fdd59dd34d70bb12b88c4c8482ddd3c00e7b815f8295362fbfd4a->leave($__internal_d9908279a80fdd59dd34d70bb12b88c4c8482ddd3c00e7b815f8295362fbfd4a_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_ba6e7a035b3aea6817d2ebf30e9fb039c2224a0623519757409994ce2d015e53 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba6e7a035b3aea6817d2ebf30e9fb039c2224a0623519757409994ce2d015e53->enter($__internal_ba6e7a035b3aea6817d2ebf30e9fb039c2224a0623519757409994ce2d015e53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_8d9f02c962bd78fdffd26988f8d4bae13a694c281559cca6a82b8b19544e23e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d9f02c962bd78fdffd26988f8d4bae13a694c281559cca6a82b8b19544e23e6->enter($__internal_8d9f02c962bd78fdffd26988f8d4bae13a694c281559cca6a82b8b19544e23e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container-fluid\">
        <div class=\"container\">\t
            <h2>Hallintapaneeli</h2>
            <ul  class=\"nav nav-tabs\">
                <li class=\"active\">
                    <a href=\"#unconfirmed\" data-toggle=\"tab\">Vahvistamattomat yritykset</a>
                </li>
                <li>
                    <a href=\"#all-companies\" data-toggle=\"tab\">Kaikki yritykset</a>
                </li>
            </ul>

            <div class=\"tab-content clearfix\">
                <div class=\"tab-pane active\" id=\"unconfirmed\">
                    <table class=\"table table-hover\">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nimi</th>
                                <th>Y-tunnus</th>
                                <th>Sähköposti</th>
                                <th>Tila</th>
                            </tr>
                        </thead>
                        <tbody>
                        ";
        // line 29
        if (twig_test_empty(($context["unconfirmed"] ?? $this->getContext($context, "unconfirmed")))) {
            // line 30
            echo "                            <tr>
                                <td colspan=\"5\" class=\"text-center\">Ei vahvistamattomia yrityksiä</td>
                            </tr>
                        ";
        } else {
            // line 34
            echo "                            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["unconfirmed"] ?? $this->getContext($context, "unconfirmed")));
            foreach ($context['_seq'] as $context["_key"] => $context["company"]) {
                // line 35
                echo "                                <tr class=\"company-row\" data-href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("adminCompanyEdit", array("id" => $this->getAttribute($context["company"], "id", array()))), "html", null, true);
                echo "\">
                                    <td>";
                // line 36
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "id", array()), "html", null, true);
                echo "</td>
                                    <td>";
                // line 37
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "name", array()), "html", null, true);
                echo "</td>
                                    <td>";
                // line 38
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "vatId", array()), "html", null, true);
                echo "</td>
                                    <td>";
                // line 39
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["company"], "user", array()), "email", array()), "html", null, true);
                echo "</td>
                                    <td>
                                        ";
                // line 41
                if ($this->getAttribute($this->getAttribute($context["company"], "user", array()), "confirmed", array())) {
                    // line 42
                    echo "                                            <span class=\"label label-success\">Vahvistettu</span>
                                        ";
                } else {
                    // line 44
                    echo "                                            <span class=\"label label-warning\">Vahvistamaton</span></td>
                                        ";
                }
                // line 46
                echo "                                </tr>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['company'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 48
            echo "                        ";
        }
        // line 49
        echo "                        </tbody>
                    </table>
                </div>
                <div class=\"tab-pane\" id=\"all-companies\">
                    <table class=\"table table-hover\">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nimi</th>
                                <th>Y-tunnus</th>
                                <th>Sähköposti</th>
                                <th>Tila</th>
                            </tr>
                        </thead>
                        <tbody>
                        ";
        // line 64
        if (twig_test_empty(($context["companies"] ?? $this->getContext($context, "companies")))) {
            // line 65
            echo "                            <tr>
                                <td colspan=\"5\" class=\"text-center\">Ei tuloksia</td>
                            </tr>
                        ";
        } else {
            // line 69
            echo "                            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["companies"] ?? $this->getContext($context, "companies")));
            foreach ($context['_seq'] as $context["_key"] => $context["company"]) {
                // line 70
                echo "                                <tr class=\"company-row\" data-href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("adminCompanyEdit", array("id" => $this->getAttribute($context["company"], "id", array()))), "html", null, true);
                echo "\">
                                    <td>";
                // line 71
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "id", array()), "html", null, true);
                echo "</td>
                                    <td>";
                // line 72
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "name", array()), "html", null, true);
                echo "</td>
                                    <td>";
                // line 73
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "vatId", array()), "html", null, true);
                echo "</td>
                                    <td>";
                // line 74
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["company"], "user", array()), "email", array()), "html", null, true);
                echo "</td>
                                    <td>
                                        ";
                // line 76
                if ($this->getAttribute($this->getAttribute($context["company"], "user", array()), "confirmed", array())) {
                    // line 77
                    echo "                                            <span class=\"label label-success\">Vahvistettu</span>
                                        ";
                } else {
                    // line 79
                    echo "                                            <span class=\"label label-warning\">Vahvistamaton</span></td>
                                        ";
                }
                // line 81
                echo "                                </tr>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['company'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 83
            echo "                        ";
        }
        // line 84
        echo "                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
";
        
        $__internal_8d9f02c962bd78fdffd26988f8d4bae13a694c281559cca6a82b8b19544e23e6->leave($__internal_8d9f02c962bd78fdffd26988f8d4bae13a694c281559cca6a82b8b19544e23e6_prof);

        
        $__internal_ba6e7a035b3aea6817d2ebf30e9fb039c2224a0623519757409994ce2d015e53->leave($__internal_ba6e7a035b3aea6817d2ebf30e9fb039c2224a0623519757409994ce2d015e53_prof);

    }

    // line 93
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d77eefd6065a4870c4f872f44456be89ecba8787021b4544d3379fd2e68bfd18 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d77eefd6065a4870c4f872f44456be89ecba8787021b4544d3379fd2e68bfd18->enter($__internal_d77eefd6065a4870c4f872f44456be89ecba8787021b4544d3379fd2e68bfd18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_5ebd352fd688fd77091ae27a5c2a372fedb6a7c6c12f54d86f03eea7ed190fe1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5ebd352fd688fd77091ae27a5c2a372fedb6a7c6c12f54d86f03eea7ed190fe1->enter($__internal_5ebd352fd688fd77091ae27a5c2a372fedb6a7c6c12f54d86f03eea7ed190fe1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 94
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/admin.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
";
        
        $__internal_5ebd352fd688fd77091ae27a5c2a372fedb6a7c6c12f54d86f03eea7ed190fe1->leave($__internal_5ebd352fd688fd77091ae27a5c2a372fedb6a7c6c12f54d86f03eea7ed190fe1_prof);

        
        $__internal_d77eefd6065a4870c4f872f44456be89ecba8787021b4544d3379fd2e68bfd18->leave($__internal_d77eefd6065a4870c4f872f44456be89ecba8787021b4544d3379fd2e68bfd18_prof);

    }

    // line 97
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_1843a904482e6b946007268fb4b4862ea5b3bc002c956eea1d56c03b977207a7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1843a904482e6b946007268fb4b4862ea5b3bc002c956eea1d56c03b977207a7->enter($__internal_1843a904482e6b946007268fb4b4862ea5b3bc002c956eea1d56c03b977207a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_9ef8abc3667b166a8a85fbf3e23375315827013d294f7e6e6c5e545020f1e74a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9ef8abc3667b166a8a85fbf3e23375315827013d294f7e6e6c5e545020f1e74a->enter($__internal_9ef8abc3667b166a8a85fbf3e23375315827013d294f7e6e6c5e545020f1e74a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 98
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 99
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/admin.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_9ef8abc3667b166a8a85fbf3e23375315827013d294f7e6e6c5e545020f1e74a->leave($__internal_9ef8abc3667b166a8a85fbf3e23375315827013d294f7e6e6c5e545020f1e74a_prof);

        
        $__internal_1843a904482e6b946007268fb4b4862ea5b3bc002c956eea1d56c03b977207a7->leave($__internal_1843a904482e6b946007268fb4b4862ea5b3bc002c956eea1d56c03b977207a7_prof);

    }

    public function getTemplateName()
    {
        return ":Admin:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  277 => 99,  272 => 98,  263 => 97,  250 => 94,  241 => 93,  224 => 84,  221 => 83,  214 => 81,  210 => 79,  206 => 77,  204 => 76,  199 => 74,  195 => 73,  191 => 72,  187 => 71,  182 => 70,  177 => 69,  171 => 65,  169 => 64,  152 => 49,  149 => 48,  142 => 46,  138 => 44,  134 => 42,  132 => 41,  127 => 39,  123 => 38,  119 => 37,  115 => 36,  110 => 35,  105 => 34,  99 => 30,  97 => 29,  70 => 4,  61 => 3,  43 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block title %}Hallintapaneeli{% endblock %}
{% block body %}
    <div class=\"container-fluid\">
        <div class=\"container\">\t
            <h2>Hallintapaneeli</h2>
            <ul  class=\"nav nav-tabs\">
                <li class=\"active\">
                    <a href=\"#unconfirmed\" data-toggle=\"tab\">Vahvistamattomat yritykset</a>
                </li>
                <li>
                    <a href=\"#all-companies\" data-toggle=\"tab\">Kaikki yritykset</a>
                </li>
            </ul>

            <div class=\"tab-content clearfix\">
                <div class=\"tab-pane active\" id=\"unconfirmed\">
                    <table class=\"table table-hover\">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nimi</th>
                                <th>Y-tunnus</th>
                                <th>Sähköposti</th>
                                <th>Tila</th>
                            </tr>
                        </thead>
                        <tbody>
                        {% if unconfirmed is empty %}
                            <tr>
                                <td colspan=\"5\" class=\"text-center\">Ei vahvistamattomia yrityksiä</td>
                            </tr>
                        {% else %}
                            {% for company in unconfirmed %}
                                <tr class=\"company-row\" data-href=\"{{ path('adminCompanyEdit', {'id': company.id }) }}\">
                                    <td>{{ company.id }}</td>
                                    <td>{{ company.name }}</td>
                                    <td>{{ company.vatId }}</td>
                                    <td>{{ company.user.email }}</td>
                                    <td>
                                        {% if company.user.confirmed %}
                                            <span class=\"label label-success\">Vahvistettu</span>
                                        {% else %}
                                            <span class=\"label label-warning\">Vahvistamaton</span></td>
                                        {% endif %}
                                </tr>
                            {% endfor %}
                        {% endif %}
                        </tbody>
                    </table>
                </div>
                <div class=\"tab-pane\" id=\"all-companies\">
                    <table class=\"table table-hover\">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nimi</th>
                                <th>Y-tunnus</th>
                                <th>Sähköposti</th>
                                <th>Tila</th>
                            </tr>
                        </thead>
                        <tbody>
                        {% if companies is empty %}
                            <tr>
                                <td colspan=\"5\" class=\"text-center\">Ei tuloksia</td>
                            </tr>
                        {% else %}
                            {% for company in companies %}
                                <tr class=\"company-row\" data-href=\"{{ path('adminCompanyEdit', {'id': company.id }) }}\">
                                    <td>{{ company.id }}</td>
                                    <td>{{ company.name }}</td>
                                    <td>{{ company.vatId }}</td>
                                    <td>{{ company.user.email }}</td>
                                    <td>
                                        {% if company.user.confirmed %}
                                            <span class=\"label label-success\">Vahvistettu</span>
                                        {% else %}
                                            <span class=\"label label-warning\">Vahvistamaton</span></td>
                                        {% endif %}
                                </tr>
                            {% endfor %}
                        {% endif %}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
{% endblock %}

{% block stylesheets %}
    <link href=\"{{ asset('bundles/app/css/admin.css') }}\" rel=\"stylesheet\" />
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
    <script src=\"{{ asset('bundles/app/js/admin.js') }}\"></script>
{% endblock %}", ":Admin:index.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Admin/index.html.twig");
    }
}
