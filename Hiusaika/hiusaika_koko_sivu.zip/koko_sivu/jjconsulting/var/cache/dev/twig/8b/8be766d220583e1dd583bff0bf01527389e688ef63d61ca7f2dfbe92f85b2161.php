<?php

/* base.html.twig */
class __TwigTemplate_35e37a9c80d24e4ddcd021648657e5f5785a3fde02267bf9184ee082c1724050 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3af3159a838938f13210919abd1f49b5d68c021f37ef92bf8ea53de17862ddcb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3af3159a838938f13210919abd1f49b5d68c021f37ef92bf8ea53de17862ddcb->enter($__internal_3af3159a838938f13210919abd1f49b5d68c021f37ef92bf8ea53de17862ddcb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_c36cedd53aa89fb81fde2e24ae5dd6d207f50051f2a466292438ab87a943531a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c36cedd53aa89fb81fde2e24ae5dd6d207f50051f2a466292438ab87a943531a->enter($__internal_c36cedd53aa89fb81fde2e24ae5dd6d207f50051f2a466292438ab87a943531a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\" />
    <title>J&J Consulting Ky - ";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    <link href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
    <link href=\"https://fonts.googleapis.com/css?family=Montserrat\" rel=\"stylesheet\" type=\"text/css\">
    <link href=\"https://fonts.googleapis.com/css?family=Lato\" rel=\"stylesheet\" type=\"text/css\">
    <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
    <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/main.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
    <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/toastr.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
    ";
        // line 13
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 14
        echo "
    <script src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/jquery-3.2.1.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/toastr.min.js"), "html", null, true);
        echo "\"></script>
    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
</head>
<body>
    <!-- Navigation -->
    <nav class=\"navbar navbar-default navbar-fixed-top\" >
        <div class=\"container\">
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#myNavbar\">
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>                        
                </button>
                <a class=\"navbar-brand\" href=\"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">Logo</a>
            </div>
            <div class=\"collapse navbar-collapse\" id=\"myNavbar\">
                <ul class=\"nav navbar-nav navbar-right\">
                    <li><a href=\"";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("searchCompany");
        echo "\">Yritykset</a></li>
                    <li><a href=\"";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("about");
        echo "\">Tietoa meistä</a></li>
                        ";
        // line 36
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 37
            echo "                            ";
            if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
                // line 38
                echo "                                <li><a href=\"";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("adminIndex");
                echo "\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> Hallintapaneeli</a></li>
                            ";
            } else {
                // line 40
                echo "                                <li><a href=\"";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("dashboard");
                echo "\"><i class=\"fa fa-user\" aria-hidden=\"true\"></i> Oma tili</a></li>
                            ";
            }
            // line 42
            echo "                            <li><a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Kirjaudu ulos</a></li>
                        ";
        }
        // line 44
        echo "                </ul>
            </div>
        </div>
    </nav>
    <div class=\"main-container\">
        ";
        // line 49
        $this->displayBlock('body', $context, $blocks);
        // line 50
        echo "    </div>

    <footer>
        <div class=\"text-center bg-grey\">
            <a href=\"#top\" title=\"To Top\">
                <span class=\"glyphicon glyphicon-chevron-up\"></span>
            </a>
            <p>
                Copyright &copy; J&J Consulting Ky - 2017<br/>
                ";
        // line 59
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 60
            echo "                    <a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Kirjaudu ulos</a>
                ";
        } else {
            // line 62
            echo "                   <a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
            echo "\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Kirjaudu sisään</a>
                ";
        }
        // line 63
        echo "    
            </p>
        </div>
    </footer>
            
    <script>
        \$(document).ready(function() {
            toastr.options = {
                \"closeButton\": true,
                \"debug\": false,
                \"newestOnTop\": false,
                \"progressBar\": true,
                \"positionClass\": \"toast-top-right\",
                \"preventDuplicates\": false,
                \"onclick\": null,
                \"showDuration\": \"300\",
                \"hideDuration\": \"1000\",
                \"timeOut\": \"5000\",
                \"extendedTimeOut\": \"1000\",
                \"showEasing\": \"swing\",
                \"hideEasing\": \"linear\",
                \"showMethod\": \"fadeIn\",
                \"hideMethod\": \"fadeOut\"
            };
            
            ";
        // line 88
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "flashes", array(0 => "success"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 89
            echo "                toastr.success('";
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "');
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 91
        echo "
            ";
        // line 92
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "flashes", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 93
            echo "                toastr.error('";
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "');
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 95
        echo "
            ";
        // line 96
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "flashes", array(0 => "info"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 97
            echo "                toastr.info('";
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "');
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 99
        echo "        });
    </script>
    ";
        // line 101
        $this->displayBlock('javascripts', $context, $blocks);
        // line 102
        echo "</body>
</html>
";
        
        $__internal_3af3159a838938f13210919abd1f49b5d68c021f37ef92bf8ea53de17862ddcb->leave($__internal_3af3159a838938f13210919abd1f49b5d68c021f37ef92bf8ea53de17862ddcb_prof);

        
        $__internal_c36cedd53aa89fb81fde2e24ae5dd6d207f50051f2a466292438ab87a943531a->leave($__internal_c36cedd53aa89fb81fde2e24ae5dd6d207f50051f2a466292438ab87a943531a_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_faacf97261269db6bf2eb5c6c47009c96503e349df7b1f6e743f97a62e37f97f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_faacf97261269db6bf2eb5c6c47009c96503e349df7b1f6e743f97a62e37f97f->enter($__internal_faacf97261269db6bf2eb5c6c47009c96503e349df7b1f6e743f97a62e37f97f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_40b0ca5a70a5d9e869f89775c6ccf270660168c46d1e8001276e298acdcbfb4d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_40b0ca5a70a5d9e869f89775c6ccf270660168c46d1e8001276e298acdcbfb4d->enter($__internal_40b0ca5a70a5d9e869f89775c6ccf270660168c46d1e8001276e298acdcbfb4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_40b0ca5a70a5d9e869f89775c6ccf270660168c46d1e8001276e298acdcbfb4d->leave($__internal_40b0ca5a70a5d9e869f89775c6ccf270660168c46d1e8001276e298acdcbfb4d_prof);

        
        $__internal_faacf97261269db6bf2eb5c6c47009c96503e349df7b1f6e743f97a62e37f97f->leave($__internal_faacf97261269db6bf2eb5c6c47009c96503e349df7b1f6e743f97a62e37f97f_prof);

    }

    // line 13
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_cc35e00d0a7fca453982eeaaa95f5d174bf5f9355b9c711b81ae69b7d9c73813 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cc35e00d0a7fca453982eeaaa95f5d174bf5f9355b9c711b81ae69b7d9c73813->enter($__internal_cc35e00d0a7fca453982eeaaa95f5d174bf5f9355b9c711b81ae69b7d9c73813_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_fc4176ccbe78082d07956f66203f367d80f7709d989c9b3371aa14ac779aa775 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc4176ccbe78082d07956f66203f367d80f7709d989c9b3371aa14ac779aa775->enter($__internal_fc4176ccbe78082d07956f66203f367d80f7709d989c9b3371aa14ac779aa775_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_fc4176ccbe78082d07956f66203f367d80f7709d989c9b3371aa14ac779aa775->leave($__internal_fc4176ccbe78082d07956f66203f367d80f7709d989c9b3371aa14ac779aa775_prof);

        
        $__internal_cc35e00d0a7fca453982eeaaa95f5d174bf5f9355b9c711b81ae69b7d9c73813->leave($__internal_cc35e00d0a7fca453982eeaaa95f5d174bf5f9355b9c711b81ae69b7d9c73813_prof);

    }

    // line 49
    public function block_body($context, array $blocks = array())
    {
        $__internal_92941836ebe2ccd05df522698bed9e49aa6bca73c9766cfe51562ee77d00f5d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_92941836ebe2ccd05df522698bed9e49aa6bca73c9766cfe51562ee77d00f5d3->enter($__internal_92941836ebe2ccd05df522698bed9e49aa6bca73c9766cfe51562ee77d00f5d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_3665ca870eca481870f5469c646c0079aeb7a29cc96794742f4358a9e4bd933c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3665ca870eca481870f5469c646c0079aeb7a29cc96794742f4358a9e4bd933c->enter($__internal_3665ca870eca481870f5469c646c0079aeb7a29cc96794742f4358a9e4bd933c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_3665ca870eca481870f5469c646c0079aeb7a29cc96794742f4358a9e4bd933c->leave($__internal_3665ca870eca481870f5469c646c0079aeb7a29cc96794742f4358a9e4bd933c_prof);

        
        $__internal_92941836ebe2ccd05df522698bed9e49aa6bca73c9766cfe51562ee77d00f5d3->leave($__internal_92941836ebe2ccd05df522698bed9e49aa6bca73c9766cfe51562ee77d00f5d3_prof);

    }

    // line 101
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_219db9ca052f5d1aacd80621e251bd690d949a1042b43123ede9fb4c118b0d87 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_219db9ca052f5d1aacd80621e251bd690d949a1042b43123ede9fb4c118b0d87->enter($__internal_219db9ca052f5d1aacd80621e251bd690d949a1042b43123ede9fb4c118b0d87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_669c7860fcd7afd0b2aa05821e7e12f16182356b951819c907464a28498b2418 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_669c7860fcd7afd0b2aa05821e7e12f16182356b951819c907464a28498b2418->enter($__internal_669c7860fcd7afd0b2aa05821e7e12f16182356b951819c907464a28498b2418_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_669c7860fcd7afd0b2aa05821e7e12f16182356b951819c907464a28498b2418->leave($__internal_669c7860fcd7afd0b2aa05821e7e12f16182356b951819c907464a28498b2418_prof);

        
        $__internal_219db9ca052f5d1aacd80621e251bd690d949a1042b43123ede9fb4c118b0d87->leave($__internal_219db9ca052f5d1aacd80621e251bd690d949a1042b43123ede9fb4c118b0d87_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  303 => 101,  286 => 49,  269 => 13,  252 => 5,  240 => 102,  238 => 101,  234 => 99,  225 => 97,  221 => 96,  218 => 95,  209 => 93,  205 => 92,  202 => 91,  193 => 89,  189 => 88,  162 => 63,  156 => 62,  150 => 60,  148 => 59,  137 => 50,  135 => 49,  128 => 44,  122 => 42,  116 => 40,  110 => 38,  107 => 37,  105 => 36,  101 => 35,  97 => 34,  90 => 30,  75 => 18,  71 => 17,  67 => 16,  63 => 15,  60 => 14,  58 => 13,  54 => 12,  50 => 11,  46 => 10,  40 => 7,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\" />
    <title>J&J Consulting Ky - {% block title %}{% endblock %}</title>

    <link href=\"{{ asset('bundles/app/css/bootstrap.min.css') }}\" rel=\"stylesheet\" />
    <link href=\"https://fonts.googleapis.com/css?family=Montserrat\" rel=\"stylesheet\" type=\"text/css\">
    <link href=\"https://fonts.googleapis.com/css?family=Lato\" rel=\"stylesheet\" type=\"text/css\">
    <link href=\"{{ asset('bundles/app/css/font-awesome.min.css') }}\" rel=\"stylesheet\" />
    <link href=\"{{ asset('bundles/app/css/main.css') }}\" rel=\"stylesheet\" />
    <link href=\"{{ asset('bundles/app/css/toastr.min.css') }}\" rel=\"stylesheet\" />
    {% block stylesheets %}{% endblock %}

    <script src=\"{{ asset('bundles/app/js/jquery-3.2.1.min.js') }}\"></script>
    <script src=\"{{ asset('bundles/app/js/bootstrap.min.js') }}\"></script>
    <script src=\"{{ asset('bundles/app/js/toastr.min.js') }}\"></script>
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
</head>
<body>
    <!-- Navigation -->
    <nav class=\"navbar navbar-default navbar-fixed-top\" >
        <div class=\"container\">
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#myNavbar\">
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>                        
                </button>
                <a class=\"navbar-brand\" href=\"{{ path('homepage') }}\">Logo</a>
            </div>
            <div class=\"collapse navbar-collapse\" id=\"myNavbar\">
                <ul class=\"nav navbar-nav navbar-right\">
                    <li><a href=\"{{ path('searchCompany') }}\">Yritykset</a></li>
                    <li><a href=\"{{ path('about') }}\">Tietoa meistä</a></li>
                        {% if is_granted('IS_AUTHENTICATED_FULLY') %}
                            {% if is_granted('ROLE_ADMIN') %}
                                <li><a href=\"{{ path('adminIndex') }}\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> Hallintapaneeli</a></li>
                            {% else %}
                                <li><a href=\"{{ path('dashboard') }}\"><i class=\"fa fa-user\" aria-hidden=\"true\"></i> Oma tili</a></li>
                            {% endif %}
                            <li><a href=\"{{ path('fos_user_security_logout') }}\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Kirjaudu ulos</a></li>
                        {% endif %}
                </ul>
            </div>
        </div>
    </nav>
    <div class=\"main-container\">
        {% block body %}{% endblock %}
    </div>

    <footer>
        <div class=\"text-center bg-grey\">
            <a href=\"#top\" title=\"To Top\">
                <span class=\"glyphicon glyphicon-chevron-up\"></span>
            </a>
            <p>
                Copyright &copy; J&J Consulting Ky - 2017<br/>
                {% if is_granted('IS_AUTHENTICATED_FULLY') %}
                    <a href=\"{{ path('fos_user_security_logout') }}\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Kirjaudu ulos</a>
                {% else %}
                   <a href=\"{{ path('fos_user_security_login') }}\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Kirjaudu sisään</a>
                {% endif %}    
            </p>
        </div>
    </footer>
            
    <script>
        \$(document).ready(function() {
            toastr.options = {
                \"closeButton\": true,
                \"debug\": false,
                \"newestOnTop\": false,
                \"progressBar\": true,
                \"positionClass\": \"toast-top-right\",
                \"preventDuplicates\": false,
                \"onclick\": null,
                \"showDuration\": \"300\",
                \"hideDuration\": \"1000\",
                \"timeOut\": \"5000\",
                \"extendedTimeOut\": \"1000\",
                \"showEasing\": \"swing\",
                \"hideEasing\": \"linear\",
                \"showMethod\": \"fadeIn\",
                \"hideMethod\": \"fadeOut\"
            };
            
            {% for flashMessage in app.flashes('success') %}
                toastr.success('{{ flashMessage }}');
            {% endfor %}

            {% for flashMessage in app.flashes('error') %}
                toastr.error('{{ flashMessage }}');
            {% endfor %}

            {% for flashMessage in app.flashes('info') %}
                toastr.info('{{ flashMessage }}');
            {% endfor %}
        });
    </script>
    {% block javascripts %}{% endblock %}
</body>
</html>
", "base.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/base.html.twig");
    }
}
