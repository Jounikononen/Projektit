<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_ed9e04b95e9c7b7b7119a16b1e7e8e8ea04e51699bbcec6788ff98ef093b7e11 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f7947e9d463f352e080d58d4899bd32d3b6e0de6246721b8d9f18fc43e2f1afe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f7947e9d463f352e080d58d4899bd32d3b6e0de6246721b8d9f18fc43e2f1afe->enter($__internal_f7947e9d463f352e080d58d4899bd32d3b6e0de6246721b8d9f18fc43e2f1afe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        $__internal_f607c4b357d44164e0b5b7b89a6b1a88e5e869907d3d26348de13deb84c55b86 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f607c4b357d44164e0b5b7b89a6b1a88e5e869907d3d26348de13deb84c55b86->enter($__internal_f607c4b357d44164e0b5b7b89a6b1a88e5e869907d3d26348de13deb84c55b86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_f7947e9d463f352e080d58d4899bd32d3b6e0de6246721b8d9f18fc43e2f1afe->leave($__internal_f7947e9d463f352e080d58d4899bd32d3b6e0de6246721b8d9f18fc43e2f1afe_prof);

        
        $__internal_f607c4b357d44164e0b5b7b89a6b1a88e5e869907d3d26348de13deb84c55b86->leave($__internal_f607c4b357d44164e0b5b7b89a6b1a88e5e869907d3d26348de13deb84c55b86_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
", "@Framework/Form/form_widget_compound.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_widget_compound.html.php");
    }
}
