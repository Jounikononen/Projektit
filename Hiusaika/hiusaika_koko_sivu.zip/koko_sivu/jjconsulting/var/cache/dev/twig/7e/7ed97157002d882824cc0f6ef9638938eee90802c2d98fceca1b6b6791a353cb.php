<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_4d91f5e15864bf1c829c3c20435138f204d06491c0cdf90323a41e168ea85f15 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3594f49388c2c805b9275972d04ce2ba9f60a47ddbab08f16f4dfa5537047037 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3594f49388c2c805b9275972d04ce2ba9f60a47ddbab08f16f4dfa5537047037->enter($__internal_3594f49388c2c805b9275972d04ce2ba9f60a47ddbab08f16f4dfa5537047037_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        $__internal_14e7ac645bceb1e41db8f191554c8495233f4074bb11e0e89df56bddf15f2de9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_14e7ac645bceb1e41db8f191554c8495233f4074bb11e0e89df56bddf15f2de9->enter($__internal_14e7ac645bceb1e41db8f191554c8495233f4074bb11e0e89df56bddf15f2de9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_3594f49388c2c805b9275972d04ce2ba9f60a47ddbab08f16f4dfa5537047037->leave($__internal_3594f49388c2c805b9275972d04ce2ba9f60a47ddbab08f16f4dfa5537047037_prof);

        
        $__internal_14e7ac645bceb1e41db8f191554c8495233f4074bb11e0e89df56bddf15f2de9->leave($__internal_14e7ac645bceb1e41db8f191554c8495233f4074bb11e0e89df56bddf15f2de9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/container_attributes.html.php");
    }
}
