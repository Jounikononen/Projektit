<?php

/* FOSUserBundle:ChangePassword:change_password.html.twig */
class __TwigTemplate_52cdc3fbb6606aede3fc8b77e53e256dfc11a9482971061be8f04a79d683516e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:ChangePassword:change_password.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_03a1a445b9318c06574f693aab8c99db0d4546530c758739eea1e2b9faa6e8ad = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_03a1a445b9318c06574f693aab8c99db0d4546530c758739eea1e2b9faa6e8ad->enter($__internal_03a1a445b9318c06574f693aab8c99db0d4546530c758739eea1e2b9faa6e8ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:ChangePassword:change_password.html.twig"));

        $__internal_5480fedb2df4f6225ed2487883601bc935d650958c58aba3047523801bd9f923 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5480fedb2df4f6225ed2487883601bc935d650958c58aba3047523801bd9f923->enter($__internal_5480fedb2df4f6225ed2487883601bc935d650958c58aba3047523801bd9f923_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:ChangePassword:change_password.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_03a1a445b9318c06574f693aab8c99db0d4546530c758739eea1e2b9faa6e8ad->leave($__internal_03a1a445b9318c06574f693aab8c99db0d4546530c758739eea1e2b9faa6e8ad_prof);

        
        $__internal_5480fedb2df4f6225ed2487883601bc935d650958c58aba3047523801bd9f923->leave($__internal_5480fedb2df4f6225ed2487883601bc935d650958c58aba3047523801bd9f923_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_b4801274cc8fe7e7442c27c01d99551bd5df00944bb07a6f9060bf64299862b6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b4801274cc8fe7e7442c27c01d99551bd5df00944bb07a6f9060bf64299862b6->enter($__internal_b4801274cc8fe7e7442c27c01d99551bd5df00944bb07a6f9060bf64299862b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_5a2447497962d03524ddc5de642e6f54080775460890b40f53575478250be23c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a2447497962d03524ddc5de642e6f54080775460890b40f53575478250be23c->enter($__internal_5a2447497962d03524ddc5de642e6f54080775460890b40f53575478250be23c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/ChangePassword/change_password_content.html.twig", "FOSUserBundle:ChangePassword:change_password.html.twig", 4)->display($context);
        
        $__internal_5a2447497962d03524ddc5de642e6f54080775460890b40f53575478250be23c->leave($__internal_5a2447497962d03524ddc5de642e6f54080775460890b40f53575478250be23c_prof);

        
        $__internal_b4801274cc8fe7e7442c27c01d99551bd5df00944bb07a6f9060bf64299862b6->leave($__internal_b4801274cc8fe7e7442c27c01d99551bd5df00944bb07a6f9060bf64299862b6_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:ChangePassword:change_password.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/ChangePassword/change_password_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:ChangePassword:change_password.html.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/ChangePassword/change_password.html.twig");
    }
}
