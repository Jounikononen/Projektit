<?php

/* :Default:404.html.twig */
class __TwigTemplate_ab19b602c219c735213aa0d02bb328824d34a31fd449a360b4c68715419c8c81 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Default:404.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_208b4fc9bb25ac028a43e33561d4cce38aaa3105e03a7a052ec60987e8a52cb4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_208b4fc9bb25ac028a43e33561d4cce38aaa3105e03a7a052ec60987e8a52cb4->enter($__internal_208b4fc9bb25ac028a43e33561d4cce38aaa3105e03a7a052ec60987e8a52cb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Default:404.html.twig"));

        $__internal_8d19fd71dc454e9bcbfb4d6ff7a07101fe4f2fd9660b018f90ce36e32ccf6e96 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d19fd71dc454e9bcbfb4d6ff7a07101fe4f2fd9660b018f90ce36e32ccf6e96->enter($__internal_8d19fd71dc454e9bcbfb4d6ff7a07101fe4f2fd9660b018f90ce36e32ccf6e96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Default:404.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_208b4fc9bb25ac028a43e33561d4cce38aaa3105e03a7a052ec60987e8a52cb4->leave($__internal_208b4fc9bb25ac028a43e33561d4cce38aaa3105e03a7a052ec60987e8a52cb4_prof);

        
        $__internal_8d19fd71dc454e9bcbfb4d6ff7a07101fe4f2fd9660b018f90ce36e32ccf6e96->leave($__internal_8d19fd71dc454e9bcbfb4d6ff7a07101fe4f2fd9660b018f90ce36e32ccf6e96_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_51ee92ebb0a6c6c63fe2136a021b07fc435bb1837068a56ee64298c1253eb885 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_51ee92ebb0a6c6c63fe2136a021b07fc435bb1837068a56ee64298c1253eb885->enter($__internal_51ee92ebb0a6c6c63fe2136a021b07fc435bb1837068a56ee64298c1253eb885_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e3ba8c7556c1d725443c5a80ed3cb34f987e3a0cd210c2edb6fba0e4c7bd9a6f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e3ba8c7556c1d725443c5a80ed3cb34f987e3a0cd210c2edb6fba0e4c7bd9a6f->enter($__internal_e3ba8c7556c1d725443c5a80ed3cb34f987e3a0cd210c2edb6fba0e4c7bd9a6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Sivua ei löytynyt";
        
        $__internal_e3ba8c7556c1d725443c5a80ed3cb34f987e3a0cd210c2edb6fba0e4c7bd9a6f->leave($__internal_e3ba8c7556c1d725443c5a80ed3cb34f987e3a0cd210c2edb6fba0e4c7bd9a6f_prof);

        
        $__internal_51ee92ebb0a6c6c63fe2136a021b07fc435bb1837068a56ee64298c1253eb885->leave($__internal_51ee92ebb0a6c6c63fe2136a021b07fc435bb1837068a56ee64298c1253eb885_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_e238acbf6ae8da64990a908f7f11337105cbd795c89a8fac479194f618ed97bf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e238acbf6ae8da64990a908f7f11337105cbd795c89a8fac479194f618ed97bf->enter($__internal_e238acbf6ae8da64990a908f7f11337105cbd795c89a8fac479194f618ed97bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d255515140ea9a93e29a37ee813faa03fb61d21d418ee30d8d48514c7a8f66cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d255515140ea9a93e29a37ee813faa03fb61d21d418ee30d8d48514c7a8f66cc->enter($__internal_d255515140ea9a93e29a37ee813faa03fb61d21d418ee30d8d48514c7a8f66cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div id=\"about\" class=\"container-fluid text-center\">
        <div class=\"row\">
            <div class=\"col-sm-12\">
                <h2>Hakemaasi sivua ei löytynyt <i class=\"fa fa-frown-o\" aria-hidden=\"true\"></i></h2><br>
                <p><a href=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">Palaa etusivulle</a></p>
            </div>
        </div>
    </div>
";
        
        $__internal_d255515140ea9a93e29a37ee813faa03fb61d21d418ee30d8d48514c7a8f66cc->leave($__internal_d255515140ea9a93e29a37ee813faa03fb61d21d418ee30d8d48514c7a8f66cc_prof);

        
        $__internal_e238acbf6ae8da64990a908f7f11337105cbd795c89a8fac479194f618ed97bf->leave($__internal_e238acbf6ae8da64990a908f7f11337105cbd795c89a8fac479194f618ed97bf_prof);

    }

    // line 14
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d8d078abf02fae8bd6b6fb41370f9311ddc89af66ca8c92ae815160a05bbf3af = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d8d078abf02fae8bd6b6fb41370f9311ddc89af66ca8c92ae815160a05bbf3af->enter($__internal_d8d078abf02fae8bd6b6fb41370f9311ddc89af66ca8c92ae815160a05bbf3af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_c2336bad9963b90e042148ee93777b731c74f8545dadd4d318318db9744dfb1c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2336bad9963b90e042148ee93777b731c74f8545dadd4d318318db9744dfb1c->enter($__internal_c2336bad9963b90e042148ee93777b731c74f8545dadd4d318318db9744dfb1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_c2336bad9963b90e042148ee93777b731c74f8545dadd4d318318db9744dfb1c->leave($__internal_c2336bad9963b90e042148ee93777b731c74f8545dadd4d318318db9744dfb1c_prof);

        
        $__internal_d8d078abf02fae8bd6b6fb41370f9311ddc89af66ca8c92ae815160a05bbf3af->leave($__internal_d8d078abf02fae8bd6b6fb41370f9311ddc89af66ca8c92ae815160a05bbf3af_prof);

    }

    // line 17
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_052650c5b7fc5cca8f72a0cbf5c990072c383516debc227e320415be1bac2c0e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_052650c5b7fc5cca8f72a0cbf5c990072c383516debc227e320415be1bac2c0e->enter($__internal_052650c5b7fc5cca8f72a0cbf5c990072c383516debc227e320415be1bac2c0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_19634dcbd3d8330bd44a309efa8d78b330d6ec904e2169da347ddb8cea253388 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_19634dcbd3d8330bd44a309efa8d78b330d6ec904e2169da347ddb8cea253388->enter($__internal_19634dcbd3d8330bd44a309efa8d78b330d6ec904e2169da347ddb8cea253388_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 18
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_19634dcbd3d8330bd44a309efa8d78b330d6ec904e2169da347ddb8cea253388->leave($__internal_19634dcbd3d8330bd44a309efa8d78b330d6ec904e2169da347ddb8cea253388_prof);

        
        $__internal_052650c5b7fc5cca8f72a0cbf5c990072c383516debc227e320415be1bac2c0e->leave($__internal_052650c5b7fc5cca8f72a0cbf5c990072c383516debc227e320415be1bac2c0e_prof);

    }

    public function getTemplateName()
    {
        return ":Default:404.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 18,  108 => 17,  91 => 14,  76 => 8,  70 => 4,  61 => 3,  43 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block title %}Sivua ei löytynyt{% endblock %}
{% block body %}
    <div id=\"about\" class=\"container-fluid text-center\">
        <div class=\"row\">
            <div class=\"col-sm-12\">
                <h2>Hakemaasi sivua ei löytynyt <i class=\"fa fa-frown-o\" aria-hidden=\"true\"></i></h2><br>
                <p><a href=\"{{ path('homepage') }}\">Palaa etusivulle</a></p>
            </div>
        </div>
    </div>
{% endblock %}

{% block stylesheets %}
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
{% endblock %}", ":Default:404.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Default/404.html.twig");
    }
}
