<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_b2e563651b50e4757ff00b685dc85e83f69f898c17c940ae85c6adbec1d32c18 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_610d94d694819fc1ba020473bac6c2fa531ed8c32b7be0b04e2eef7d74024d30 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_610d94d694819fc1ba020473bac6c2fa531ed8c32b7be0b04e2eef7d74024d30->enter($__internal_610d94d694819fc1ba020473bac6c2fa531ed8c32b7be0b04e2eef7d74024d30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_11204116ee4587f01defb29c37f3783bbcbf40916adfb273674e17717f569e6f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_11204116ee4587f01defb29c37f3783bbcbf40916adfb273674e17717f569e6f->enter($__internal_11204116ee4587f01defb29c37f3783bbcbf40916adfb273674e17717f569e6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_610d94d694819fc1ba020473bac6c2fa531ed8c32b7be0b04e2eef7d74024d30->leave($__internal_610d94d694819fc1ba020473bac6c2fa531ed8c32b7be0b04e2eef7d74024d30_prof);

        
        $__internal_11204116ee4587f01defb29c37f3783bbcbf40916adfb273674e17717f569e6f->leave($__internal_11204116ee4587f01defb29c37f3783bbcbf40916adfb273674e17717f569e6f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_row.html.php");
    }
}
