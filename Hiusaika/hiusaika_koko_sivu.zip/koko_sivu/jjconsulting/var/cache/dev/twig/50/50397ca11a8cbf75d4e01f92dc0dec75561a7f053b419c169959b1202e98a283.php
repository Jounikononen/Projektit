<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_5240f01391bef30397fb1280b3a4c1fa4f5a2ce07fa2c33823e73dd0e6f591d2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0e9b333b07dce830d5d0492ac9f4b0a017a47e1024a42c683563cbc9ff3f3ed7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0e9b333b07dce830d5d0492ac9f4b0a017a47e1024a42c683563cbc9ff3f3ed7->enter($__internal_0e9b333b07dce830d5d0492ac9f4b0a017a47e1024a42c683563cbc9ff3f3ed7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $__internal_ffa33d938432034bccdef4f9e7142f22a9980bd7b9a55adf7b42f19767543751 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ffa33d938432034bccdef4f9e7142f22a9980bd7b9a55adf7b42f19767543751->enter($__internal_ffa33d938432034bccdef4f9e7142f22a9980bd7b9a55adf7b42f19767543751_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0e9b333b07dce830d5d0492ac9f4b0a017a47e1024a42c683563cbc9ff3f3ed7->leave($__internal_0e9b333b07dce830d5d0492ac9f4b0a017a47e1024a42c683563cbc9ff3f3ed7_prof);

        
        $__internal_ffa33d938432034bccdef4f9e7142f22a9980bd7b9a55adf7b42f19767543751->leave($__internal_ffa33d938432034bccdef4f9e7142f22a9980bd7b9a55adf7b42f19767543751_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_b222e37fd758394a20abcf91fe55bfd3a4410a1a8c8a05b87c4e2f421e327c40 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b222e37fd758394a20abcf91fe55bfd3a4410a1a8c8a05b87c4e2f421e327c40->enter($__internal_b222e37fd758394a20abcf91fe55bfd3a4410a1a8c8a05b87c4e2f421e327c40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_212963ba9526ebc67c7d0adc88cc1d56c8c7a268f713c13f7b60e9569392f4fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_212963ba9526ebc67c7d0adc88cc1d56c8c7a268f713c13f7b60e9569392f4fc->enter($__internal_212963ba9526ebc67c7d0adc88cc1d56c8c7a268f713c13f7b60e9569392f4fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Registration/register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_212963ba9526ebc67c7d0adc88cc1d56c8c7a268f713c13f7b60e9569392f4fc->leave($__internal_212963ba9526ebc67c7d0adc88cc1d56c8c7a268f713c13f7b60e9569392f4fc_prof);

        
        $__internal_b222e37fd758394a20abcf91fe55bfd3a4410a1a8c8a05b87c4e2f421e327c40->leave($__internal_b222e37fd758394a20abcf91fe55bfd3a4410a1a8c8a05b87c4e2f421e327c40_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Registration/register_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:register.html.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Registration/register.html.twig");
    }
}
