<?php

/* :Default:about.html.twig */
class __TwigTemplate_da4dfc77b6d630d15b84e3e45af9203e6c54f65fa1e2bcdf9f3648b115cc6bc1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Default:about.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e0d6a5324883a423f4eef4028ee8b039d71db4f0741d4696fccd95f9abaf94bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e0d6a5324883a423f4eef4028ee8b039d71db4f0741d4696fccd95f9abaf94bd->enter($__internal_e0d6a5324883a423f4eef4028ee8b039d71db4f0741d4696fccd95f9abaf94bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Default:about.html.twig"));

        $__internal_d37498717e4fcd73e74b46b149c9f3e256cf09faa67a89383500e6fbbd738dde = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d37498717e4fcd73e74b46b149c9f3e256cf09faa67a89383500e6fbbd738dde->enter($__internal_d37498717e4fcd73e74b46b149c9f3e256cf09faa67a89383500e6fbbd738dde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Default:about.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e0d6a5324883a423f4eef4028ee8b039d71db4f0741d4696fccd95f9abaf94bd->leave($__internal_e0d6a5324883a423f4eef4028ee8b039d71db4f0741d4696fccd95f9abaf94bd_prof);

        
        $__internal_d37498717e4fcd73e74b46b149c9f3e256cf09faa67a89383500e6fbbd738dde->leave($__internal_d37498717e4fcd73e74b46b149c9f3e256cf09faa67a89383500e6fbbd738dde_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_cc2fefd4be567d5380ef73a1344575e209695dfcddd7040b2606abfa3b1f8765 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cc2fefd4be567d5380ef73a1344575e209695dfcddd7040b2606abfa3b1f8765->enter($__internal_cc2fefd4be567d5380ef73a1344575e209695dfcddd7040b2606abfa3b1f8765_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_4a6dd96ec9ea107107878887520458fe819e06c0805f6ae91ed5bb531e6dae37 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4a6dd96ec9ea107107878887520458fe819e06c0805f6ae91ed5bb531e6dae37->enter($__internal_4a6dd96ec9ea107107878887520458fe819e06c0805f6ae91ed5bb531e6dae37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Tietoja meistä";
        
        $__internal_4a6dd96ec9ea107107878887520458fe819e06c0805f6ae91ed5bb531e6dae37->leave($__internal_4a6dd96ec9ea107107878887520458fe819e06c0805f6ae91ed5bb531e6dae37_prof);

        
        $__internal_cc2fefd4be567d5380ef73a1344575e209695dfcddd7040b2606abfa3b1f8765->leave($__internal_cc2fefd4be567d5380ef73a1344575e209695dfcddd7040b2606abfa3b1f8765_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_1f263285c6e69f3ef055f86ae9d5dc26d094b628d825572bbe066e7b22fab674 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1f263285c6e69f3ef055f86ae9d5dc26d094b628d825572bbe066e7b22fab674->enter($__internal_1f263285c6e69f3ef055f86ae9d5dc26d094b628d825572bbe066e7b22fab674_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_a20a374b2357b998bb7ef35478023d17d1933515da6932ec3f84667595257cb5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a20a374b2357b998bb7ef35478023d17d1933515da6932ec3f84667595257cb5->enter($__internal_a20a374b2357b998bb7ef35478023d17d1933515da6932ec3f84667595257cb5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-sm-8\">
                <h2>Tietoa meistä</h2><br>
                <h4>Tekstiä</h4><br>
                <p>Lisää tekstiä</p>
            </div>
            <div class=\"col-sm-4 text-center\">
                <span class=\"glyphicon glyphicon-flag logo\"></span>
            </div>
        </div>
    </div>

    <div class=\"container-fluid bg-grey\">
        <div class=\"row\">
            <div class=\"col-sm-4 text-center\">
                <span class=\"glyphicon glyphicon-globe logo\"></span>
            </div>
            <div class=\"col-sm-8\">
                <h2>Tavoitteemme</h2><br>
                <h4>Tekstiä</h4><br>
                <p>Lisää tekstiä</p>
            </div>


        </div>
    </div>
    
    <div class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-sm-8\">
                <h2>Miksi rekisteröityä palveluumme</h2><br>
                <h4>Tekstiä! </h4><br>
                <p>Lisää tekstiä</p><br>
                ";
        // line 38
        if ( !$this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 39
            echo "                    <a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_registration_register");
            echo "\" class=\"btn btn-default btn-lg\">Rekisteröidy</a>
                    <a href=\"";
            // line 40
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
            echo "\" class=\"btn btn-default btn-lg\">Kirjaudu sisään</a><br/>
                ";
        }
        // line 42
        echo "            </div>
            <div class=\"col-sm-4 text-center\">
                <span class=\"glyphicon glyphicon-signal logo\"></span>
            </div>
        </div>
    </div>
            
    <div class=\"container-fluid bg-grey text-center\">
        <h2>Palvelumme</h2>
        <h4>Mitä tarjoamme</h4>
        <br>
        <div class=\"row slideanim\">
            <div class=\"col-sm-4\">
                <span class=\"glyphicon glyphicon-stats logo-small\"></span>
                <h4>Näkyvyyttä</h4>
                <p>Yritykset saavat sivuiltamme näkyvyyttä täysin ilmaiseksi. Yhä useammat yritykset löytävät asiakkaansa netistä.</p>
            </div>
            <div class=\"col-sm-4\">
                <span class=\"glyphicon glyphicon-thumbs-up logo-small\"></span>
                <h4>2</h4>
                <p>Tekstiä</p>
            </div>
            <div class=\"col-sm-4\">
                <span class=\"glyphicon glyphicon-list-alt logo-small\"></span>
                <h4>3</h4>
                <p>Tekstiä</p>
            </div>
        </div>
    </div>

    <div class=\"container-fluid text-center\">
        <h2>Asiakkaittemme kommentteja</h2>
        <div id=\"myCarousel\" class=\"carousel slide text-center\" data-ride=\"carousel\">
            <!--Indikaattorit-->
            <ol class=\"carousel-indicators\">
                <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>
                <li data-target=\"#myCarousel\" data-slide-to=\"1\"></li>
            </ol>

            <div class=\"carousel-inner\" role=\"listbox\">
                <div class=\"item active\">
                    <h4>\"tekstiä\"<br><span>Jaana, yrittäjä</span></h4>
                </div>
                <div class=\"item\">
                    <h4>\"Tekstiä\"<br><span>Niina, yrittäjä</span></h4>
                </div>
            </div>

            <a class=\"left carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"prev\">
                <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">takaisin</span>
            </a>
            <a class=\"right carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"next\">
                <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">Seuraava</span>
            </a>
        </div>
    </div>
            
    <div class=\"container-fluid\">
        <h2 class=\"text-center\">Lähetä palautetta</h2>
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <p>Vastaamme palautteisiin 24 tunnin kuluessa</p>
                <p><i class=\"fa fa-phone\" aria-hidden=\"true\"></i> 040 778 4649</p>
                <p><i class=\"fa fa-envelope\" aria-hidden=\"true\"></i> jouni.kononen@gmail.com</p>
            </div>
            <div class=\"col-sm-8 slideanim\">
                <div class=\"row\">
                    ";
        // line 111
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["contactForm"] ?? $this->getContext($context, "contactForm")), 'form_start');
        echo "
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 113
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["contactForm"] ?? $this->getContext($context, "contactForm")), "name", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 116
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["contactForm"] ?? $this->getContext($context, "contactForm")), "email", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-12 form-group\">
                        ";
        // line 119
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["contactForm"] ?? $this->getContext($context, "contactForm")), "message", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-12 form-group\">
                        ";
        // line 122
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["contactForm"] ?? $this->getContext($context, "contactForm")), "submit", array()), 'row');
        echo "
                    </div>
                    ";
        // line 124
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["contactForm"] ?? $this->getContext($context, "contactForm")), 'form_end');
        echo "
                </div>
            </div>
        </div>
    </div>

";
        
        $__internal_a20a374b2357b998bb7ef35478023d17d1933515da6932ec3f84667595257cb5->leave($__internal_a20a374b2357b998bb7ef35478023d17d1933515da6932ec3f84667595257cb5_prof);

        
        $__internal_1f263285c6e69f3ef055f86ae9d5dc26d094b628d825572bbe066e7b22fab674->leave($__internal_1f263285c6e69f3ef055f86ae9d5dc26d094b628d825572bbe066e7b22fab674_prof);

    }

    // line 132
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_32fa41edf74d8fe100ddf953fdd13b9031ae31d29cc5b606d22494b4c2a55d7b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_32fa41edf74d8fe100ddf953fdd13b9031ae31d29cc5b606d22494b4c2a55d7b->enter($__internal_32fa41edf74d8fe100ddf953fdd13b9031ae31d29cc5b606d22494b4c2a55d7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_01cf4f90f1baf7992d8cd233988d4625d25f1c218e8e47d3f9d969b3e17fb34a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_01cf4f90f1baf7992d8cd233988d4625d25f1c218e8e47d3f9d969b3e17fb34a->enter($__internal_01cf4f90f1baf7992d8cd233988d4625d25f1c218e8e47d3f9d969b3e17fb34a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_01cf4f90f1baf7992d8cd233988d4625d25f1c218e8e47d3f9d969b3e17fb34a->leave($__internal_01cf4f90f1baf7992d8cd233988d4625d25f1c218e8e47d3f9d969b3e17fb34a_prof);

        
        $__internal_32fa41edf74d8fe100ddf953fdd13b9031ae31d29cc5b606d22494b4c2a55d7b->leave($__internal_32fa41edf74d8fe100ddf953fdd13b9031ae31d29cc5b606d22494b4c2a55d7b_prof);

    }

    // line 135
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_e6c325ff5e384158c82762873491a55bbc82d8080614f3e20fb67b4a47a7698d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e6c325ff5e384158c82762873491a55bbc82d8080614f3e20fb67b4a47a7698d->enter($__internal_e6c325ff5e384158c82762873491a55bbc82d8080614f3e20fb67b4a47a7698d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_f8bea4d6ed87e4d922d2a240f52c36cf559cd7c5206b670089232050f1269ba9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f8bea4d6ed87e4d922d2a240f52c36cf559cd7c5206b670089232050f1269ba9->enter($__internal_f8bea4d6ed87e4d922d2a240f52c36cf559cd7c5206b670089232050f1269ba9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 136
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_f8bea4d6ed87e4d922d2a240f52c36cf559cd7c5206b670089232050f1269ba9->leave($__internal_f8bea4d6ed87e4d922d2a240f52c36cf559cd7c5206b670089232050f1269ba9_prof);

        
        $__internal_e6c325ff5e384158c82762873491a55bbc82d8080614f3e20fb67b4a47a7698d->leave($__internal_e6c325ff5e384158c82762873491a55bbc82d8080614f3e20fb67b4a47a7698d_prof);

    }

    public function getTemplateName()
    {
        return ":Default:about.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  260 => 136,  251 => 135,  234 => 132,  217 => 124,  212 => 122,  206 => 119,  200 => 116,  194 => 113,  189 => 111,  118 => 42,  113 => 40,  108 => 39,  106 => 38,  70 => 4,  61 => 3,  43 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block title %}Tietoja meistä{% endblock %}
{% block body %}
    <div class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-sm-8\">
                <h2>Tietoa meistä</h2><br>
                <h4>Tekstiä</h4><br>
                <p>Lisää tekstiä</p>
            </div>
            <div class=\"col-sm-4 text-center\">
                <span class=\"glyphicon glyphicon-flag logo\"></span>
            </div>
        </div>
    </div>

    <div class=\"container-fluid bg-grey\">
        <div class=\"row\">
            <div class=\"col-sm-4 text-center\">
                <span class=\"glyphicon glyphicon-globe logo\"></span>
            </div>
            <div class=\"col-sm-8\">
                <h2>Tavoitteemme</h2><br>
                <h4>Tekstiä</h4><br>
                <p>Lisää tekstiä</p>
            </div>


        </div>
    </div>
    
    <div class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-sm-8\">
                <h2>Miksi rekisteröityä palveluumme</h2><br>
                <h4>Tekstiä! </h4><br>
                <p>Lisää tekstiä</p><br>
                {% if not is_granted('IS_AUTHENTICATED_FULLY') %}
                    <a href=\"{{ path('fos_user_registration_register') }}\" class=\"btn btn-default btn-lg\">Rekisteröidy</a>
                    <a href=\"{{ path('fos_user_security_login') }}\" class=\"btn btn-default btn-lg\">Kirjaudu sisään</a><br/>
                {% endif %}
            </div>
            <div class=\"col-sm-4 text-center\">
                <span class=\"glyphicon glyphicon-signal logo\"></span>
            </div>
        </div>
    </div>
            
    <div class=\"container-fluid bg-grey text-center\">
        <h2>Palvelumme</h2>
        <h4>Mitä tarjoamme</h4>
        <br>
        <div class=\"row slideanim\">
            <div class=\"col-sm-4\">
                <span class=\"glyphicon glyphicon-stats logo-small\"></span>
                <h4>Näkyvyyttä</h4>
                <p>Yritykset saavat sivuiltamme näkyvyyttä täysin ilmaiseksi. Yhä useammat yritykset löytävät asiakkaansa netistä.</p>
            </div>
            <div class=\"col-sm-4\">
                <span class=\"glyphicon glyphicon-thumbs-up logo-small\"></span>
                <h4>2</h4>
                <p>Tekstiä</p>
            </div>
            <div class=\"col-sm-4\">
                <span class=\"glyphicon glyphicon-list-alt logo-small\"></span>
                <h4>3</h4>
                <p>Tekstiä</p>
            </div>
        </div>
    </div>

    <div class=\"container-fluid text-center\">
        <h2>Asiakkaittemme kommentteja</h2>
        <div id=\"myCarousel\" class=\"carousel slide text-center\" data-ride=\"carousel\">
            <!--Indikaattorit-->
            <ol class=\"carousel-indicators\">
                <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>
                <li data-target=\"#myCarousel\" data-slide-to=\"1\"></li>
            </ol>

            <div class=\"carousel-inner\" role=\"listbox\">
                <div class=\"item active\">
                    <h4>\"tekstiä\"<br><span>Jaana, yrittäjä</span></h4>
                </div>
                <div class=\"item\">
                    <h4>\"Tekstiä\"<br><span>Niina, yrittäjä</span></h4>
                </div>
            </div>

            <a class=\"left carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"prev\">
                <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">takaisin</span>
            </a>
            <a class=\"right carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"next\">
                <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">Seuraava</span>
            </a>
        </div>
    </div>
            
    <div class=\"container-fluid\">
        <h2 class=\"text-center\">Lähetä palautetta</h2>
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <p>Vastaamme palautteisiin 24 tunnin kuluessa</p>
                <p><i class=\"fa fa-phone\" aria-hidden=\"true\"></i> 040 778 4649</p>
                <p><i class=\"fa fa-envelope\" aria-hidden=\"true\"></i> jouni.kononen@gmail.com</p>
            </div>
            <div class=\"col-sm-8 slideanim\">
                <div class=\"row\">
                    {{form_start(contactForm)}}
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(contactForm.name)}}
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(contactForm.email)}}
                    </div>
                    <div class=\"col-sm-12 form-group\">
                        {{form_row(contactForm.message)}}
                    </div>
                    <div class=\"col-sm-12 form-group\">
                        {{form_row(contactForm.submit)}}
                    </div>
                    {{form_end(contactForm)}}
                </div>
            </div>
        </div>
    </div>

{% endblock %}

{% block stylesheets %}
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
{% endblock %}", ":Default:about.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Default/about.html.twig");
    }
}
