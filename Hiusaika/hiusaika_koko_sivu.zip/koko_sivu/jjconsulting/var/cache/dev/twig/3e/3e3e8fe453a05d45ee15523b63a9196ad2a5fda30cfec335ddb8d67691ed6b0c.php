<?php

/* FOSUserBundle:Resetting:reset.html.twig */
class __TwigTemplate_dc30476a601aed2a8c12a35d5cf2851a096d404a28f0176f746aadf5022e6bc2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8507aec723023c62c18f5a9e3528151d128088a31d85dc86d5be10d5deb27108 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8507aec723023c62c18f5a9e3528151d128088a31d85dc86d5be10d5deb27108->enter($__internal_8507aec723023c62c18f5a9e3528151d128088a31d85dc86d5be10d5deb27108_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset.html.twig"));

        $__internal_9cb51dacf91596a049bfab8e9f3f04e34a34ef2a5ba460fbcb40d3ea68f3fa8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9cb51dacf91596a049bfab8e9f3f04e34a34ef2a5ba460fbcb40d3ea68f3fa8d->enter($__internal_9cb51dacf91596a049bfab8e9f3f04e34a34ef2a5ba460fbcb40d3ea68f3fa8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8507aec723023c62c18f5a9e3528151d128088a31d85dc86d5be10d5deb27108->leave($__internal_8507aec723023c62c18f5a9e3528151d128088a31d85dc86d5be10d5deb27108_prof);

        
        $__internal_9cb51dacf91596a049bfab8e9f3f04e34a34ef2a5ba460fbcb40d3ea68f3fa8d->leave($__internal_9cb51dacf91596a049bfab8e9f3f04e34a34ef2a5ba460fbcb40d3ea68f3fa8d_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f4c938feee938ae617fafba8fc3941c50dda5aebf32fd080723a63d631df9025 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f4c938feee938ae617fafba8fc3941c50dda5aebf32fd080723a63d631df9025->enter($__internal_f4c938feee938ae617fafba8fc3941c50dda5aebf32fd080723a63d631df9025_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_b3ebfa0a5f029f8adf9568cf7bcc0f852076be23ff2bc2f2a861b085d2fdd92c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3ebfa0a5f029f8adf9568cf7bcc0f852076be23ff2bc2f2a861b085d2fdd92c->enter($__internal_b3ebfa0a5f029f8adf9568cf7bcc0f852076be23ff2bc2f2a861b085d2fdd92c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Resetting/reset_content.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 4)->display($context);
        
        $__internal_b3ebfa0a5f029f8adf9568cf7bcc0f852076be23ff2bc2f2a861b085d2fdd92c->leave($__internal_b3ebfa0a5f029f8adf9568cf7bcc0f852076be23ff2bc2f2a861b085d2fdd92c_prof);

        
        $__internal_f4c938feee938ae617fafba8fc3941c50dda5aebf32fd080723a63d631df9025->leave($__internal_f4c938feee938ae617fafba8fc3941c50dda5aebf32fd080723a63d631df9025_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Resetting/reset_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Resetting:reset.html.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Resetting/reset.html.twig");
    }
}
