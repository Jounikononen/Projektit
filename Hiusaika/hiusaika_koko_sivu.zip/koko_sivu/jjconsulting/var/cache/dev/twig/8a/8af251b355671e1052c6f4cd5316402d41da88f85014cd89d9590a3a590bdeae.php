<?php

/* @Framework/Form/button_attributes.html.php */
class __TwigTemplate_2dd1fdb5c8cfbe70546bd6dc6a2b167363f1203ab1be3d93acd7fe80ad70ff3d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fef443cbed21553d24d8cdbe4c06f7c07c1427a9106e8221aa66e1cc5e8b63ec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fef443cbed21553d24d8cdbe4c06f7c07c1427a9106e8221aa66e1cc5e8b63ec->enter($__internal_fef443cbed21553d24d8cdbe4c06f7c07c1427a9106e8221aa66e1cc5e8b63ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_attributes.html.php"));

        $__internal_176fce217c3905a6429860057278549776588eb03ab38ecaebf2d6dab48b80f3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_176fce217c3905a6429860057278549776588eb03ab38ecaebf2d6dab48b80f3->enter($__internal_176fce217c3905a6429860057278549776588eb03ab38ecaebf2d6dab48b80f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_fef443cbed21553d24d8cdbe4c06f7c07c1427a9106e8221aa66e1cc5e8b63ec->leave($__internal_fef443cbed21553d24d8cdbe4c06f7c07c1427a9106e8221aa66e1cc5e8b63ec_prof);

        
        $__internal_176fce217c3905a6429860057278549776588eb03ab38ecaebf2d6dab48b80f3->leave($__internal_176fce217c3905a6429860057278549776588eb03ab38ecaebf2d6dab48b80f3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/button_attributes.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_attributes.html.php");
    }
}
