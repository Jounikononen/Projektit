<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_3652944cf3ed4cb19b00a97b38f048bbf92ba4621490d77c2bc8f42a1da0578a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_386a78403773183ab84aad761fbf4bfb769abe934c7b0cf9ac33e59fd73d35cb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_386a78403773183ab84aad761fbf4bfb769abe934c7b0cf9ac33e59fd73d35cb->enter($__internal_386a78403773183ab84aad761fbf4bfb769abe934c7b0cf9ac33e59fd73d35cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_7118f60af37cfd4de6ee776a1781de35ebb90bd5dcb1ed61289d63f305e7f2fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7118f60af37cfd4de6ee776a1781de35ebb90bd5dcb1ed61289d63f305e7f2fc->enter($__internal_7118f60af37cfd4de6ee776a1781de35ebb90bd5dcb1ed61289d63f305e7f2fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_386a78403773183ab84aad761fbf4bfb769abe934c7b0cf9ac33e59fd73d35cb->leave($__internal_386a78403773183ab84aad761fbf4bfb769abe934c7b0cf9ac33e59fd73d35cb_prof);

        
        $__internal_7118f60af37cfd4de6ee776a1781de35ebb90bd5dcb1ed61289d63f305e7f2fc->leave($__internal_7118f60af37cfd4de6ee776a1781de35ebb90bd5dcb1ed61289d63f305e7f2fc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/hidden_row.html.php");
    }
}
