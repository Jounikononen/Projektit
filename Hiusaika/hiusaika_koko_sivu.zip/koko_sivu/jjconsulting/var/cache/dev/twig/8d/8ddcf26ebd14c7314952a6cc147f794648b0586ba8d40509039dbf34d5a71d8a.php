<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_11e4e1cc2dbbaa4a5af2dd6f57912d04fb8b68df6aafbdeefdd6a5ff038a6e28 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f6de6c40c1ef7ed2728db222af41ae8ed73be4f43063fad12ab56fa6a3e0dcbe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f6de6c40c1ef7ed2728db222af41ae8ed73be4f43063fad12ab56fa6a3e0dcbe->enter($__internal_f6de6c40c1ef7ed2728db222af41ae8ed73be4f43063fad12ab56fa6a3e0dcbe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_173fd0ec2b3b74f15851d3dcd831404aaa658991934310fcb712a09848fb5655 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_173fd0ec2b3b74f15851d3dcd831404aaa658991934310fcb712a09848fb5655->enter($__internal_173fd0ec2b3b74f15851d3dcd831404aaa658991934310fcb712a09848fb5655_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_f6de6c40c1ef7ed2728db222af41ae8ed73be4f43063fad12ab56fa6a3e0dcbe->leave($__internal_f6de6c40c1ef7ed2728db222af41ae8ed73be4f43063fad12ab56fa6a3e0dcbe_prof);

        
        $__internal_173fd0ec2b3b74f15851d3dcd831404aaa658991934310fcb712a09848fb5655->leave($__internal_173fd0ec2b3b74f15851d3dcd831404aaa658991934310fcb712a09848fb5655_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/radio_widget.html.php");
    }
}
