<?php

/* FOSUserBundle:Group:new.html.twig */
class __TwigTemplate_916fe1984a74bec5bb3039231cf34901e1c912c3e2a5c46d80b581a0e8830e06 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:new.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3fb303fa646c4b67fe313794de85acdf6185f36432a2f0727a3ff0e183efe010 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3fb303fa646c4b67fe313794de85acdf6185f36432a2f0727a3ff0e183efe010->enter($__internal_3fb303fa646c4b67fe313794de85acdf6185f36432a2f0727a3ff0e183efe010_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new.html.twig"));

        $__internal_9bfd3a82b168707dba08d321d55c1f43c4a2812c26848e878f54ebe082ebc9bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9bfd3a82b168707dba08d321d55c1f43c4a2812c26848e878f54ebe082ebc9bb->enter($__internal_9bfd3a82b168707dba08d321d55c1f43c4a2812c26848e878f54ebe082ebc9bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3fb303fa646c4b67fe313794de85acdf6185f36432a2f0727a3ff0e183efe010->leave($__internal_3fb303fa646c4b67fe313794de85acdf6185f36432a2f0727a3ff0e183efe010_prof);

        
        $__internal_9bfd3a82b168707dba08d321d55c1f43c4a2812c26848e878f54ebe082ebc9bb->leave($__internal_9bfd3a82b168707dba08d321d55c1f43c4a2812c26848e878f54ebe082ebc9bb_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_5985dd5ed4b3dab4c688af6eba923014170a0a5efafbf0c899b6218d9e5cae08 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5985dd5ed4b3dab4c688af6eba923014170a0a5efafbf0c899b6218d9e5cae08->enter($__internal_5985dd5ed4b3dab4c688af6eba923014170a0a5efafbf0c899b6218d9e5cae08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_8ad55bdb6005429958c775fafce76fa1922165cfae35b97603bfde21d1d9ac6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ad55bdb6005429958c775fafce76fa1922165cfae35b97603bfde21d1d9ac6a->enter($__internal_8ad55bdb6005429958c775fafce76fa1922165cfae35b97603bfde21d1d9ac6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/new_content.html.twig", "FOSUserBundle:Group:new.html.twig", 4)->display($context);
        
        $__internal_8ad55bdb6005429958c775fafce76fa1922165cfae35b97603bfde21d1d9ac6a->leave($__internal_8ad55bdb6005429958c775fafce76fa1922165cfae35b97603bfde21d1d9ac6a_prof);

        
        $__internal_5985dd5ed4b3dab4c688af6eba923014170a0a5efafbf0c899b6218d9e5cae08->leave($__internal_5985dd5ed4b3dab4c688af6eba923014170a0a5efafbf0c899b6218d9e5cae08_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/new_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:new.html.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Group/new.html.twig");
    }
}
