<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_6b638f208865159eb85ec0f6823f0c17190eae6df8ef23ab2f6c95fc8b5483cf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b914dcbe8f3015e01348ead65449c241a62e0bbb99d229065fdbb63196c81c20 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b914dcbe8f3015e01348ead65449c241a62e0bbb99d229065fdbb63196c81c20->enter($__internal_b914dcbe8f3015e01348ead65449c241a62e0bbb99d229065fdbb63196c81c20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $__internal_d258bf2e26b2f6b69dfeea9f7aeabaa7b45b98c61135f9e45a479e1c265bd130 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d258bf2e26b2f6b69dfeea9f7aeabaa7b45b98c61135f9e45a479e1c265bd130->enter($__internal_d258bf2e26b2f6b69dfeea9f7aeabaa7b45b98c61135f9e45a479e1c265bd130_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b914dcbe8f3015e01348ead65449c241a62e0bbb99d229065fdbb63196c81c20->leave($__internal_b914dcbe8f3015e01348ead65449c241a62e0bbb99d229065fdbb63196c81c20_prof);

        
        $__internal_d258bf2e26b2f6b69dfeea9f7aeabaa7b45b98c61135f9e45a479e1c265bd130->leave($__internal_d258bf2e26b2f6b69dfeea9f7aeabaa7b45b98c61135f9e45a479e1c265bd130_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_a14d5eadac3a23365d559059f574383f0c64ebd626ab26a4972c13a37852ccad = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a14d5eadac3a23365d559059f574383f0c64ebd626ab26a4972c13a37852ccad->enter($__internal_a14d5eadac3a23365d559059f574383f0c64ebd626ab26a4972c13a37852ccad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_e63d1a30e8ff09cc5ccc5544514846b6acd165027f02b3fab2a245ca7575322b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e63d1a30e8ff09cc5ccc5544514846b6acd165027f02b3fab2a245ca7575322b->enter($__internal_e63d1a30e8ff09cc5ccc5544514846b6acd165027f02b3fab2a245ca7575322b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
";
        
        $__internal_e63d1a30e8ff09cc5ccc5544514846b6acd165027f02b3fab2a245ca7575322b->leave($__internal_e63d1a30e8ff09cc5ccc5544514846b6acd165027f02b3fab2a245ca7575322b_prof);

        
        $__internal_a14d5eadac3a23365d559059f574383f0c64ebd626ab26a4972c13a37852ccad->leave($__internal_a14d5eadac3a23365d559059f574383f0c64ebd626ab26a4972c13a37852ccad_prof);

    }

    // line 136
    public function block_title($context, array $blocks = array())
    {
        $__internal_12b62de72dce64a687d18b107daa4c94ac205798f4fd93304bfc6d9ed180aeee = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12b62de72dce64a687d18b107daa4c94ac205798f4fd93304bfc6d9ed180aeee->enter($__internal_12b62de72dce64a687d18b107daa4c94ac205798f4fd93304bfc6d9ed180aeee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_3bd44624547a544494d13c347c5a6ae4b0f4267583039394384f92495ea3b027 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3bd44624547a544494d13c347c5a6ae4b0f4267583039394384f92495ea3b027->enter($__internal_3bd44624547a544494d13c347c5a6ae4b0f4267583039394384f92495ea3b027_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 137
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_3bd44624547a544494d13c347c5a6ae4b0f4267583039394384f92495ea3b027->leave($__internal_3bd44624547a544494d13c347c5a6ae4b0f4267583039394384f92495ea3b027_prof);

        
        $__internal_12b62de72dce64a687d18b107daa4c94ac205798f4fd93304bfc6d9ed180aeee->leave($__internal_12b62de72dce64a687d18b107daa4c94ac205798f4fd93304bfc6d9ed180aeee_prof);

    }

    // line 140
    public function block_body($context, array $blocks = array())
    {
        $__internal_d9973222eb8ba14bb70ed1c33d467121eae9ef2edc05fdf052712f29be8956f9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d9973222eb8ba14bb70ed1c33d467121eae9ef2edc05fdf052712f29be8956f9->enter($__internal_d9973222eb8ba14bb70ed1c33d467121eae9ef2edc05fdf052712f29be8956f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_73f0ae3850e7df07c89dd41da4941763724f879b3b183df4e61bd44323c0f01b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73f0ae3850e7df07c89dd41da4941763724f879b3b183df4e61bd44323c0f01b->enter($__internal_73f0ae3850e7df07c89dd41da4941763724f879b3b183df4e61bd44323c0f01b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 141
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 141)->display($context);
        
        $__internal_73f0ae3850e7df07c89dd41da4941763724f879b3b183df4e61bd44323c0f01b->leave($__internal_73f0ae3850e7df07c89dd41da4941763724f879b3b183df4e61bd44323c0f01b_prof);

        
        $__internal_d9973222eb8ba14bb70ed1c33d467121eae9ef2edc05fdf052712f29be8956f9->leave($__internal_d9973222eb8ba14bb70ed1c33d467121eae9ef2edc05fdf052712f29be8956f9_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 141,  217 => 140,  200 => 137,  191 => 136,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception_full.html.twig");
    }
}
