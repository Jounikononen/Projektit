<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_e892369a05b59bf5c3fd31acfd765415cb3e98ef837352462e68840b2378683e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af15737ff770d56d9a392378818b0d208e7fef80c7523d305875b8a6e3ae49d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_af15737ff770d56d9a392378818b0d208e7fef80c7523d305875b8a6e3ae49d4->enter($__internal_af15737ff770d56d9a392378818b0d208e7fef80c7523d305875b8a6e3ae49d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_35ceb1964efbcc483c9df4af1fc4ac42c0aefc66aef8c3f22f914b09b7f43511 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_35ceb1964efbcc483c9df4af1fc4ac42c0aefc66aef8c3f22f914b09b7f43511->enter($__internal_35ceb1964efbcc483c9df4af1fc4ac42c0aefc66aef8c3f22f914b09b7f43511_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_af15737ff770d56d9a392378818b0d208e7fef80c7523d305875b8a6e3ae49d4->leave($__internal_af15737ff770d56d9a392378818b0d208e7fef80c7523d305875b8a6e3ae49d4_prof);

        
        $__internal_35ceb1964efbcc483c9df4af1fc4ac42c0aefc66aef8c3f22f914b09b7f43511->leave($__internal_35ceb1964efbcc483c9df4af1fc4ac42c0aefc66aef8c3f22f914b09b7f43511_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.rdf.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
