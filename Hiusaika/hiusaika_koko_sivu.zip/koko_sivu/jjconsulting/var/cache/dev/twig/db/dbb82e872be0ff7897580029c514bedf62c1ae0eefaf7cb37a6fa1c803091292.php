<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_2b0a23abfea2ef5a89470fcb1ba7ebc5d810438b65ce2aeddcb3c8546febc040 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8375534d1ffa2c66dd964bbf9e7dd8834d7127fc5b55583c0a851fb568e40212 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8375534d1ffa2c66dd964bbf9e7dd8834d7127fc5b55583c0a851fb568e40212->enter($__internal_8375534d1ffa2c66dd964bbf9e7dd8834d7127fc5b55583c0a851fb568e40212_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        $__internal_0449a0f065aecfc32d85b7fcbeab2a77272da0e2e5708ee6f44d99a8c8d110d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0449a0f065aecfc32d85b7fcbeab2a77272da0e2e5708ee6f44d99a8c8d110d5->enter($__internal_0449a0f065aecfc32d85b7fcbeab2a77272da0e2e5708ee6f44d99a8c8d110d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_8375534d1ffa2c66dd964bbf9e7dd8834d7127fc5b55583c0a851fb568e40212->leave($__internal_8375534d1ffa2c66dd964bbf9e7dd8834d7127fc5b55583c0a851fb568e40212_prof);

        
        $__internal_0449a0f065aecfc32d85b7fcbeab2a77272da0e2e5708ee6f44d99a8c8d110d5->leave($__internal_0449a0f065aecfc32d85b7fcbeab2a77272da0e2e5708ee6f44d99a8c8d110d5_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.js.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.js.twig");
    }
}
