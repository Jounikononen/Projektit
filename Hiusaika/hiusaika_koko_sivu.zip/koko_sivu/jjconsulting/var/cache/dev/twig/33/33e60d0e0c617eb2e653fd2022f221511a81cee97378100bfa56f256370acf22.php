<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_872c5d32cbcd1943c1f697302c91eb71fbee7f5aadd2e6e00d676245e8520e13 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_058e7e7c2f5741f5f850ca7bfd46342d42bcdae1b96083d85cd10217aec2e958 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_058e7e7c2f5741f5f850ca7bfd46342d42bcdae1b96083d85cd10217aec2e958->enter($__internal_058e7e7c2f5741f5f850ca7bfd46342d42bcdae1b96083d85cd10217aec2e958_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        $__internal_6e204c3b5e84955be68a558b3b7e405587c9962ae3fde99f3dc698be15fd9e78 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6e204c3b5e84955be68a558b3b7e405587c9962ae3fde99f3dc698be15fd9e78->enter($__internal_6e204c3b5e84955be68a558b3b7e405587c9962ae3fde99f3dc698be15fd9e78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo ($context["status_code"] ?? $this->getContext($context, "status_code"));
        echo " ";
        echo ($context["status_text"] ?? $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_058e7e7c2f5741f5f850ca7bfd46342d42bcdae1b96083d85cd10217aec2e958->leave($__internal_058e7e7c2f5741f5f850ca7bfd46342d42bcdae1b96083d85cd10217aec2e958_prof);

        
        $__internal_6e204c3b5e84955be68a558b3b7e405587c9962ae3fde99f3dc698be15fd9e78->leave($__internal_6e204c3b5e84955be68a558b3b7e405587c9962ae3fde99f3dc698be15fd9e78_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "TwigBundle:Exception:error.txt.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.txt.twig");
    }
}
