<?php

/* FOSUserBundle:Security:login.html.twig */
class __TwigTemplate_8d5e5482369b292e19f8b0305fff08dd7aacfba5bd60bcf7004de5995b19e3fb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Security:login.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_573721a128b6b67188d11079536b80d5c3d4ca80b36723ed15558f3863e64cf2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_573721a128b6b67188d11079536b80d5c3d4ca80b36723ed15558f3863e64cf2->enter($__internal_573721a128b6b67188d11079536b80d5c3d4ca80b36723ed15558f3863e64cf2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Security:login.html.twig"));

        $__internal_37a6e2a80de1bbdc547e693c9e3f8f53b89e573bf7ca3e6cf7d2c1e77195db56 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_37a6e2a80de1bbdc547e693c9e3f8f53b89e573bf7ca3e6cf7d2c1e77195db56->enter($__internal_37a6e2a80de1bbdc547e693c9e3f8f53b89e573bf7ca3e6cf7d2c1e77195db56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Security:login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_573721a128b6b67188d11079536b80d5c3d4ca80b36723ed15558f3863e64cf2->leave($__internal_573721a128b6b67188d11079536b80d5c3d4ca80b36723ed15558f3863e64cf2_prof);

        
        $__internal_37a6e2a80de1bbdc547e693c9e3f8f53b89e573bf7ca3e6cf7d2c1e77195db56->leave($__internal_37a6e2a80de1bbdc547e693c9e3f8f53b89e573bf7ca3e6cf7d2c1e77195db56_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f10118c6400fdfa81fabbf666ad083d20593f5a9b84baff340a31da80d39408f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f10118c6400fdfa81fabbf666ad083d20593f5a9b84baff340a31da80d39408f->enter($__internal_f10118c6400fdfa81fabbf666ad083d20593f5a9b84baff340a31da80d39408f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_38264abf012b9042f52b83ec273df02020e2cf7eb87f63103281076d65066077 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_38264abf012b9042f52b83ec273df02020e2cf7eb87f63103281076d65066077->enter($__internal_38264abf012b9042f52b83ec273df02020e2cf7eb87f63103281076d65066077_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        echo "    ";
        echo twig_include($this->env, $context, "@FOSUser/Security/login_content.html.twig");
        echo "
";
        
        $__internal_38264abf012b9042f52b83ec273df02020e2cf7eb87f63103281076d65066077->leave($__internal_38264abf012b9042f52b83ec273df02020e2cf7eb87f63103281076d65066077_prof);

        
        $__internal_f10118c6400fdfa81fabbf666ad083d20593f5a9b84baff340a31da80d39408f->leave($__internal_f10118c6400fdfa81fabbf666ad083d20593f5a9b84baff340a31da80d39408f_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Security:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
    {{ include('@FOSUser/Security/login_content.html.twig') }}
{% endblock fos_user_content %}
", "FOSUserBundle:Security:login.html.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Security/login.html.twig");
    }
}
