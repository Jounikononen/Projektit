<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_0658da990b78dcdba433e2ba6bd66055e357a3d79eb6440a3961dad1760fc61a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3ecdd9a708e7dbcfbf03ced6a37538ce4dbf398ad91b6221b7cc76022b8cb29a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3ecdd9a708e7dbcfbf03ced6a37538ce4dbf398ad91b6221b7cc76022b8cb29a->enter($__internal_3ecdd9a708e7dbcfbf03ced6a37538ce4dbf398ad91b6221b7cc76022b8cb29a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        $__internal_855f3bb80442c86d7cf1583aa85bd352302f7adad11e83a3417fc6c5eaf007b2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_855f3bb80442c86d7cf1583aa85bd352302f7adad11e83a3417fc6c5eaf007b2->enter($__internal_855f3bb80442c86d7cf1583aa85bd352302f7adad11e83a3417fc6c5eaf007b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_3ecdd9a708e7dbcfbf03ced6a37538ce4dbf398ad91b6221b7cc76022b8cb29a->leave($__internal_3ecdd9a708e7dbcfbf03ced6a37538ce4dbf398ad91b6221b7cc76022b8cb29a_prof);

        
        $__internal_855f3bb80442c86d7cf1583aa85bd352302f7adad11e83a3417fc6c5eaf007b2->leave($__internal_855f3bb80442c86d7cf1583aa85bd352302f7adad11e83a3417fc6c5eaf007b2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_row.html.php");
    }
}
