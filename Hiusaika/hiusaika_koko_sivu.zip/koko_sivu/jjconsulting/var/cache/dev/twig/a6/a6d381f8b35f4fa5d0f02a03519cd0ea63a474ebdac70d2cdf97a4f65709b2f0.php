<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_baa0dece006d7406066cdd09d1feba570b576ddfd943809706e3c919d3aa9846 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f9d4799a152cc42cc177523a0f8a3a62ba2f93274631d818998a755b45b470f5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f9d4799a152cc42cc177523a0f8a3a62ba2f93274631d818998a755b45b470f5->enter($__internal_f9d4799a152cc42cc177523a0f8a3a62ba2f93274631d818998a755b45b470f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_cb911a93ac65637f389a544b32c9f7bf3a461e1168eb1529b8a0044d9161b011 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cb911a93ac65637f389a544b32c9f7bf3a461e1168eb1529b8a0044d9161b011->enter($__internal_cb911a93ac65637f389a544b32c9f7bf3a461e1168eb1529b8a0044d9161b011_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_f9d4799a152cc42cc177523a0f8a3a62ba2f93274631d818998a755b45b470f5->leave($__internal_f9d4799a152cc42cc177523a0f8a3a62ba2f93274631d818998a755b45b470f5_prof);

        
        $__internal_cb911a93ac65637f389a544b32c9f7bf3a461e1168eb1529b8a0044d9161b011->leave($__internal_cb911a93ac65637f389a544b32c9f7bf3a461e1168eb1529b8a0044d9161b011_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_row.html.php");
    }
}
