<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_72aba2dc2a7c71bbf53f34baf138349fa7888b0da016728e81b86005828f7676 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d662b2d84cd5545432465f7570e3643301b45bb82e9e86adc5818d1c9a934cbf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d662b2d84cd5545432465f7570e3643301b45bb82e9e86adc5818d1c9a934cbf->enter($__internal_d662b2d84cd5545432465f7570e3643301b45bb82e9e86adc5818d1c9a934cbf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_5a28b1c79116d18504e72073b9756afb116cfd54bb0295335629a2fa7d3f710b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a28b1c79116d18504e72073b9756afb116cfd54bb0295335629a2fa7d3f710b->enter($__internal_5a28b1c79116d18504e72073b9756afb116cfd54bb0295335629a2fa7d3f710b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_d662b2d84cd5545432465f7570e3643301b45bb82e9e86adc5818d1c9a934cbf->leave($__internal_d662b2d84cd5545432465f7570e3643301b45bb82e9e86adc5818d1c9a934cbf_prof);

        
        $__internal_5a28b1c79116d18504e72073b9756afb116cfd54bb0295335629a2fa7d3f710b->leave($__internal_5a28b1c79116d18504e72073b9756afb116cfd54bb0295335629a2fa7d3f710b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_options.html.php");
    }
}
