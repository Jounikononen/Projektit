<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_547666a8d3788b5130a1459c6c577165f61d6913950b6cbc6a193684549f2545 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3205a1a67cf8f37e15032b91da6206b23cf49f09404d70db318e53e3c205f055 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3205a1a67cf8f37e15032b91da6206b23cf49f09404d70db318e53e3c205f055->enter($__internal_3205a1a67cf8f37e15032b91da6206b23cf49f09404d70db318e53e3c205f055_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        $__internal_54662ee67a7f1dadaf914ad4cf48fcce8ffbdf8d2426856155bbea1bf062f046 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54662ee67a7f1dadaf914ad4cf48fcce8ffbdf8d2426856155bbea1bf062f046->enter($__internal_54662ee67a7f1dadaf914ad4cf48fcce8ffbdf8d2426856155bbea1bf062f046_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_3205a1a67cf8f37e15032b91da6206b23cf49f09404d70db318e53e3c205f055->leave($__internal_3205a1a67cf8f37e15032b91da6206b23cf49f09404d70db318e53e3c205f055_prof);

        
        $__internal_54662ee67a7f1dadaf914ad4cf48fcce8ffbdf8d2426856155bbea1bf062f046->leave($__internal_54662ee67a7f1dadaf914ad4cf48fcce8ffbdf8d2426856155bbea1bf062f046_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_end.html.php");
    }
}
