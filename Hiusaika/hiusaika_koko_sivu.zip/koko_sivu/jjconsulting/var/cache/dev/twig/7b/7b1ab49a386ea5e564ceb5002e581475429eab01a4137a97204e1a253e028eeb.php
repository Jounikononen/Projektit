<?php

/* Company/search.html.twig */
class __TwigTemplate_3950064ee3cc0e2eb3733f914cd8debb677624a6e9dd2e048a0f664fd7c8065a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "Company/search.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'pagination' => array($this, 'block_pagination'),
            'resultCount' => array($this, 'block_resultCount'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_85da38832b1e20c41ec0cadce0399d13424cb23dee33e3c7ebe8c9f72a2fcda6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_85da38832b1e20c41ec0cadce0399d13424cb23dee33e3c7ebe8c9f72a2fcda6->enter($__internal_85da38832b1e20c41ec0cadce0399d13424cb23dee33e3c7ebe8c9f72a2fcda6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Company/search.html.twig"));

        $__internal_e66bfc50f8a7a12a4e138f34d55e0ff361f412c5204eabe24918f7d2361b6bc9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e66bfc50f8a7a12a4e138f34d55e0ff361f412c5204eabe24918f7d2361b6bc9->enter($__internal_e66bfc50f8a7a12a4e138f34d55e0ff361f412c5204eabe24918f7d2361b6bc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Company/search.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_85da38832b1e20c41ec0cadce0399d13424cb23dee33e3c7ebe8c9f72a2fcda6->leave($__internal_85da38832b1e20c41ec0cadce0399d13424cb23dee33e3c7ebe8c9f72a2fcda6_prof);

        
        $__internal_e66bfc50f8a7a12a4e138f34d55e0ff361f412c5204eabe24918f7d2361b6bc9->leave($__internal_e66bfc50f8a7a12a4e138f34d55e0ff361f412c5204eabe24918f7d2361b6bc9_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_813649e5e3a4d20bb2561a2029a9e8d79c46637b31f6a81ac890d01f2e3897f0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_813649e5e3a4d20bb2561a2029a9e8d79c46637b31f6a81ac890d01f2e3897f0->enter($__internal_813649e5e3a4d20bb2561a2029a9e8d79c46637b31f6a81ac890d01f2e3897f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_f9a9557ef775a5c7dfbf92d35cc5e99c32e5a6025d7fcd9a2c827a35bb088a48 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9a9557ef775a5c7dfbf92d35cc5e99c32e5a6025d7fcd9a2c827a35bb088a48->enter($__internal_f9a9557ef775a5c7dfbf92d35cc5e99c32e5a6025d7fcd9a2c827a35bb088a48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Yrityshaku";
        
        $__internal_f9a9557ef775a5c7dfbf92d35cc5e99c32e5a6025d7fcd9a2c827a35bb088a48->leave($__internal_f9a9557ef775a5c7dfbf92d35cc5e99c32e5a6025d7fcd9a2c827a35bb088a48_prof);

        
        $__internal_813649e5e3a4d20bb2561a2029a9e8d79c46637b31f6a81ac890d01f2e3897f0->leave($__internal_813649e5e3a4d20bb2561a2029a9e8d79c46637b31f6a81ac890d01f2e3897f0_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_70cd3e0b55403b5e0e7633f007a2c2033029a3a915c72b4ab3bf86811caf7796 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_70cd3e0b55403b5e0e7633f007a2c2033029a3a915c72b4ab3bf86811caf7796->enter($__internal_70cd3e0b55403b5e0e7633f007a2c2033029a3a915c72b4ab3bf86811caf7796_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_3772818930a85ed7c42900fde26741f8cb5202266d0567ebab091ba94ee4b87f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3772818930a85ed7c42900fde26741f8cb5202266d0567ebab091ba94ee4b87f->enter($__internal_3772818930a85ed7c42900fde26741f8cb5202266d0567ebab091ba94ee4b87f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container-fluid text-center\">
        <div class=\"row\">
            <div class=\"col-sm-12 search-container\">
                <h2>Yrityshaku</h2>
                ";
        // line 8
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Company:searchBar", array("q" =>         // line 10
(isset($context["keyword"]) ? $context["keyword"] : $this->getContext($context, "keyword")))));
        // line 11
        echo "
                
                ";
        // line 23
        echo "            </div>
            ";
        // line 24
        if ( !twig_test_empty((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")))) {
            // line 25
            echo "                <div class=\"col-sm-12\">
                    ";
            // line 26
            $this->displayBlock("resultCount", $context, $blocks);
            echo "
                </div>
            ";
        }
        // line 29
        echo "        </div>
    </div>

    <div class=\"container-fluid bg-grey\">
        <div class=\"container\">
            ";
        // line 34
        if (twig_test_empty((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")))) {
            // line 35
            echo "                <div class=\"row\">
                    <div class=\"col-sm-12 text-center\">
                        <p>Ei tuloksia</p>
                    </div>
                </div>
            ";
        } else {
            // line 41
            echo "                ";
            $this->displayBlock("pagination", $context, $blocks);
            echo "
                ";
            // line 42
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
            foreach ($context['_seq'] as $context["_key"] => $context["company"]) {
                // line 43
                echo "                    <div class=\"row\">
                        <div class=\"col-sm-8 col-sm-offset-2\">
                            <a href=\"";
                // line 45
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("viewCompany", array("hashId" => $this->env->getExtension('AppBundle\Extension\TwigExtensions')->urlIdHasherEncode($this->getAttribute($context["company"], "id", array())))), "html", null, true);
                echo "\">
                                <div class=\"row search-result\">
                                    <div class=\"col-sm-4 text-center img-container\">
                                        ";
                // line 48
                if (($this->getAttribute($context["company"], "imageName", array()) == null)) {
                    // line 49
                    echo "                                            <img src=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/img/logo-placeholder.png"), "html", null, true);
                    echo "\" class=\"img-responsive\"></img>
                                        ";
                } else {
                    // line 51
                    echo "                                            <img src=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Liip\ImagineBundle\Templating\ImagineExtension')->filter($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset($context["company"], "imageFile"), "company_thumb"), "html", null, true);
                    echo "\" alt=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "name", array()), "html", null, true);
                    echo "\" class=\"img-responsive\" />
                                        ";
                }
                // line 53
                echo "                                    </div>

                                    <div class=\"col-sm-8 search-card-infos\">
                                        <div>
                                            <h3>";
                // line 57
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "name", array()), "html", null, true);
                echo " </h3>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-map-marker\" aria-hidden=\"true\"></i> ";
                // line 60
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "address", array()), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "postcode", array()), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "city", array()), "html", null, true);
                echo "</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-phone\" aria-hidden=\"true\"></i> ";
                // line 63
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "phone", array()), "html", null, true);
                echo "</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-envelope\" aria-hidden=\"true\"></i> ";
                // line 66
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "email", array()), "html", null, true);
                echo "</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> ";
                // line 69
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "getCurrentOpeningHours", array(), "method"), "html", null, true);
                echo "</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-eur\" aria-hidden=\"true\"></i> ";
                // line 72
                echo twig_escape_filter($this->env, $this->getAttribute($context["company"], "getLowestPrice", array(), "method"), "html", null, true);
                echo "</h5>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['company'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 80
            echo "                ";
            $this->displayBlock("pagination", $context, $blocks);
            echo "
            ";
        }
        // line 82
        echo "        </div>
    </div>
";
        
        $__internal_3772818930a85ed7c42900fde26741f8cb5202266d0567ebab091ba94ee4b87f->leave($__internal_3772818930a85ed7c42900fde26741f8cb5202266d0567ebab091ba94ee4b87f_prof);

        
        $__internal_70cd3e0b55403b5e0e7633f007a2c2033029a3a915c72b4ab3bf86811caf7796->leave($__internal_70cd3e0b55403b5e0e7633f007a2c2033029a3a915c72b4ab3bf86811caf7796_prof);

    }

    // line 86
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_cbed1e09d3164ea0e77971c2a87f5454f2a8d27347abc973f8f65cb6ad5e7f55 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cbed1e09d3164ea0e77971c2a87f5454f2a8d27347abc973f8f65cb6ad5e7f55->enter($__internal_cbed1e09d3164ea0e77971c2a87f5454f2a8d27347abc973f8f65cb6ad5e7f55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_b6740ddb44d2b045d49f22255092853cd8c494d91c676db00a81980dd2808e68 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6740ddb44d2b045d49f22255092853cd8c494d91c676db00a81980dd2808e68->enter($__internal_b6740ddb44d2b045d49f22255092853cd8c494d91c676db00a81980dd2808e68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_b6740ddb44d2b045d49f22255092853cd8c494d91c676db00a81980dd2808e68->leave($__internal_b6740ddb44d2b045d49f22255092853cd8c494d91c676db00a81980dd2808e68_prof);

        
        $__internal_cbed1e09d3164ea0e77971c2a87f5454f2a8d27347abc973f8f65cb6ad5e7f55->leave($__internal_cbed1e09d3164ea0e77971c2a87f5454f2a8d27347abc973f8f65cb6ad5e7f55_prof);

    }

    // line 89
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_f1c6047503b1ba0890f7de9e1aedde47ae331c4f742d483c5f12592324cfc352 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f1c6047503b1ba0890f7de9e1aedde47ae331c4f742d483c5f12592324cfc352->enter($__internal_f1c6047503b1ba0890f7de9e1aedde47ae331c4f742d483c5f12592324cfc352_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_88a5cf3fa411cbb30fd62e7494be621231923a742a2a10af56abcf6cc20b6704 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88a5cf3fa411cbb30fd62e7494be621231923a742a2a10af56abcf6cc20b6704->enter($__internal_88a5cf3fa411cbb30fd62e7494be621231923a742a2a10af56abcf6cc20b6704_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 90
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_88a5cf3fa411cbb30fd62e7494be621231923a742a2a10af56abcf6cc20b6704->leave($__internal_88a5cf3fa411cbb30fd62e7494be621231923a742a2a10af56abcf6cc20b6704_prof);

        
        $__internal_f1c6047503b1ba0890f7de9e1aedde47ae331c4f742d483c5f12592324cfc352->leave($__internal_f1c6047503b1ba0890f7de9e1aedde47ae331c4f742d483c5f12592324cfc352_prof);

    }

    // line 93
    public function block_pagination($context, array $blocks = array())
    {
        $__internal_3a48ff81432cf713a7edc2d5f4ed3d2d69cad5a71a77133b24b47bf6ea589693 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3a48ff81432cf713a7edc2d5f4ed3d2d69cad5a71a77133b24b47bf6ea589693->enter($__internal_3a48ff81432cf713a7edc2d5f4ed3d2d69cad5a71a77133b24b47bf6ea589693_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "pagination"));

        $__internal_133f01fe246746abbcd971710dd139df31ac3bfe53b671aa25f9ab49f2e5c34e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_133f01fe246746abbcd971710dd139df31ac3bfe53b671aa25f9ab49f2e5c34e->enter($__internal_133f01fe246746abbcd971710dd139df31ac3bfe53b671aa25f9ab49f2e5c34e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "pagination"));

        // line 94
        echo "    <div class=\"row\">
        <div class=\"col-sm-12 text-center\">
            ";
        // line 96
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        echo "
        </div>
    </div>
";
        
        $__internal_133f01fe246746abbcd971710dd139df31ac3bfe53b671aa25f9ab49f2e5c34e->leave($__internal_133f01fe246746abbcd971710dd139df31ac3bfe53b671aa25f9ab49f2e5c34e_prof);

        
        $__internal_3a48ff81432cf713a7edc2d5f4ed3d2d69cad5a71a77133b24b47bf6ea589693->leave($__internal_3a48ff81432cf713a7edc2d5f4ed3d2d69cad5a71a77133b24b47bf6ea589693_prof);

    }

    // line 101
    public function block_resultCount($context, array $blocks = array())
    {
        $__internal_b5183d393e556e4f1198ea3fa8eeb235fdbfcc625b30865b40742325dd1f2fd2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b5183d393e556e4f1198ea3fa8eeb235fdbfcc625b30865b40742325dd1f2fd2->enter($__internal_b5183d393e556e4f1198ea3fa8eeb235fdbfcc625b30865b40742325dd1f2fd2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "resultCount"));

        $__internal_965aa1f669dbcf57c2cb51a5436a8a5376d3098f0c7e102c7e57086c358f12b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_965aa1f669dbcf57c2cb51a5436a8a5376d3098f0c7e102c7e57086c358f12b1->enter($__internal_965aa1f669dbcf57c2cb51a5436a8a5376d3098f0c7e102c7e57086c358f12b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "resultCount"));

        // line 102
        echo "    <div class=\"col-sm-12 text-center\">
        <span>Näytetään ";
        // line 103
        echo twig_escape_filter($this->env, twig_length_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "getItems", array(), "method")), "html", null, true);
        echo "/";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "getTotalItemCount", array()), "html", null, true);
        echo " tulosta</span>
    </div>
";
        
        $__internal_965aa1f669dbcf57c2cb51a5436a8a5376d3098f0c7e102c7e57086c358f12b1->leave($__internal_965aa1f669dbcf57c2cb51a5436a8a5376d3098f0c7e102c7e57086c358f12b1_prof);

        
        $__internal_b5183d393e556e4f1198ea3fa8eeb235fdbfcc625b30865b40742325dd1f2fd2->leave($__internal_b5183d393e556e4f1198ea3fa8eeb235fdbfcc625b30865b40742325dd1f2fd2_prof);

    }

    public function getTemplateName()
    {
        return "Company/search.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  301 => 103,  298 => 102,  289 => 101,  275 => 96,  271 => 94,  262 => 93,  249 => 90,  240 => 89,  223 => 86,  211 => 82,  205 => 80,  191 => 72,  185 => 69,  179 => 66,  173 => 63,  163 => 60,  157 => 57,  151 => 53,  143 => 51,  137 => 49,  135 => 48,  129 => 45,  125 => 43,  121 => 42,  116 => 41,  108 => 35,  106 => 34,  99 => 29,  93 => 26,  90 => 25,  88 => 24,  85 => 23,  81 => 11,  79 => 10,  78 => 8,  72 => 4,  63 => 3,  45 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block title %}Yrityshaku{% endblock %}
{% block body %}
    <div class=\"container-fluid text-center\">
        <div class=\"row\">
            <div class=\"col-sm-12 search-container\">
                <h2>Yrityshaku</h2>
                {{ render(controller(
                    'AppBundle:Company:searchBar',
                    { 'q' : keyword }
                )) }}
                
                {#{% if keyword is not null %} 
                    <div class=\"row\">
                        <div class=\"col-sm-12 text-center\">
                            <label class=\"search-keyword\">{{ keyword }}
                            <a href=\"{{ path('searchCompany') }}\">
                                 <i class=\"fa fa-times\"></i></label>
                            </a>
                        </div>
                    </div>
                {% endif %}#}
            </div>
            {% if pagination is not empty %}
                <div class=\"col-sm-12\">
                    {{ block('resultCount') }}
                </div>
            {% endif %}
        </div>
    </div>

    <div class=\"container-fluid bg-grey\">
        <div class=\"container\">
            {% if pagination is empty %}
                <div class=\"row\">
                    <div class=\"col-sm-12 text-center\">
                        <p>Ei tuloksia</p>
                    </div>
                </div>
            {% else %}
                {{ block('pagination') }}
                {% for company in pagination %}
                    <div class=\"row\">
                        <div class=\"col-sm-8 col-sm-offset-2\">
                            <a href=\"{{ path('viewCompany', {'hashId': url_id_hasher_encode(company.id) }) }}\">
                                <div class=\"row search-result\">
                                    <div class=\"col-sm-4 text-center img-container\">
                                        {% if company.imageName == null %}
                                            <img src=\"{{ asset('bundles/app/img/logo-placeholder.png') }}\" class=\"img-responsive\"></img>
                                        {% else %}
                                            <img src=\"{{ vich_uploader_asset(company, 'imageFile') | imagine_filter('company_thumb') }}\" alt=\"{{ company.name }}\" class=\"img-responsive\" />
                                        {% endif %}
                                    </div>

                                    <div class=\"col-sm-8 search-card-infos\">
                                        <div>
                                            <h3>{{ company.name }} </h3>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-map-marker\" aria-hidden=\"true\"></i> {{ company.address }}, {{ company.postcode }} {{ company.city }}</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-phone\" aria-hidden=\"true\"></i> {{ company.phone }}</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-envelope\" aria-hidden=\"true\"></i> {{ company.email }}</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> {{ company.getCurrentOpeningHours() }}</h5>
                                        </div>
                                        <div>
                                            <h5><i class=\"fa fa-eur\" aria-hidden=\"true\"></i> {{ company.getLowestPrice() }}</h5>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                {% endfor %}
                {{ block('pagination') }}
            {% endif %}
        </div>
    </div>
{% endblock %}

{% block stylesheets %}
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
{% endblock %}

{% block pagination %}
    <div class=\"row\">
        <div class=\"col-sm-12 text-center\">
            {{ knp_pagination_render(pagination) }}
        </div>
    </div>
{% endblock %}

{% block resultCount %}
    <div class=\"col-sm-12 text-center\">
        <span>Näytetään {{ pagination.getItems()|length }}/{{ pagination.getTotalItemCount }} tulosta</span>
    </div>
{% endblock %}", "Company/search.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Company/search.html.twig");
    }
}
