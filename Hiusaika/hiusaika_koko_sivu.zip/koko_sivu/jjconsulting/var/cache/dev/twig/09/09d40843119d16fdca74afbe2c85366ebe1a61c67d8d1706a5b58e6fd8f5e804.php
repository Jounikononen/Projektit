<?php

/* :Dashboard:change_image.html.twig */
class __TwigTemplate_6f91ee3e3acc80141f5531268c5517f065611c1ce014f3df2bba4dc8b6f93709 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Dashboard:change_image.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cbfc38540d2ba1cc7e7a68fce4eb42736d855d92a2d94ca854831a3e5f31b93f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cbfc38540d2ba1cc7e7a68fce4eb42736d855d92a2d94ca854831a3e5f31b93f->enter($__internal_cbfc38540d2ba1cc7e7a68fce4eb42736d855d92a2d94ca854831a3e5f31b93f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Dashboard:change_image.html.twig"));

        $__internal_c62da4bdb014c047f42c3cabf5d2e0cea8a9fd2927b929835052416144d7acca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c62da4bdb014c047f42c3cabf5d2e0cea8a9fd2927b929835052416144d7acca->enter($__internal_c62da4bdb014c047f42c3cabf5d2e0cea8a9fd2927b929835052416144d7acca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Dashboard:change_image.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cbfc38540d2ba1cc7e7a68fce4eb42736d855d92a2d94ca854831a3e5f31b93f->leave($__internal_cbfc38540d2ba1cc7e7a68fce4eb42736d855d92a2d94ca854831a3e5f31b93f_prof);

        
        $__internal_c62da4bdb014c047f42c3cabf5d2e0cea8a9fd2927b929835052416144d7acca->leave($__internal_c62da4bdb014c047f42c3cabf5d2e0cea8a9fd2927b929835052416144d7acca_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_ae1db9571c94750456951fabb99286de7709b0325ce52e8662a70597430bfbe4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae1db9571c94750456951fabb99286de7709b0325ce52e8662a70597430bfbe4->enter($__internal_ae1db9571c94750456951fabb99286de7709b0325ce52e8662a70597430bfbe4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_bfea71e04c3bcd233326a0da5125019d592a67245020bbc9e29d80cf8fed16a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bfea71e04c3bcd233326a0da5125019d592a67245020bbc9e29d80cf8fed16a8->enter($__internal_bfea71e04c3bcd233326a0da5125019d592a67245020bbc9e29d80cf8fed16a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Kuvan vaihto";
        
        $__internal_bfea71e04c3bcd233326a0da5125019d592a67245020bbc9e29d80cf8fed16a8->leave($__internal_bfea71e04c3bcd233326a0da5125019d592a67245020bbc9e29d80cf8fed16a8_prof);

        
        $__internal_ae1db9571c94750456951fabb99286de7709b0325ce52e8662a70597430bfbe4->leave($__internal_ae1db9571c94750456951fabb99286de7709b0325ce52e8662a70597430bfbe4_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_c0d3765f3ac57c5db686c778e0581969a218c6ca72e08ce82770e3d3765793ab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c0d3765f3ac57c5db686c778e0581969a218c6ca72e08ce82770e3d3765793ab->enter($__internal_c0d3765f3ac57c5db686c778e0581969a218c6ca72e08ce82770e3d3765793ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_673d4afb5af612fb7e71b423b64c0aa7cda9b3ca6d2742fac7b5f7d8cfc7f710 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_673d4afb5af612fb7e71b423b64c0aa7cda9b3ca6d2742fac7b5f7d8cfc7f710->enter($__internal_673d4afb5af612fb7e71b423b64c0aa7cda9b3ca6d2742fac7b5f7d8cfc7f710_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container-fluid dashboard-company-info\">
        <div class=\"container text-center\">
            <h2>Vaihda kuva</h2>
            <p>Sallitut tiedostoformaatit ovat JPEG ja PNG. Suositeltu kuvan koko on 300 x 300px.</p>
            <div class=\"row\">
                ";
        // line 9
        if (($this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "imageName", array()) == null)) {
            // line 10
            echo "                    <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/img/logo-placeholder.png"), "html", null, true);
            echo "\" class=\"img-responsive\"></img>
                ";
        } else {
            // line 12
            echo "                    <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Liip\ImagineBundle\Templating\ImagineExtension')->filter($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["company"] ?? $this->getContext($context, "company")), "imageFile"), "company"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["company"] ?? $this->getContext($context, "company")), "name", array()), "html", null, true);
            echo "\" class=\"img-responsive\" />
                ";
        }
        // line 14
        echo "            </div>
            <div class=\"row\">
                ";
        // line 16
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
                    <div class=\"col-sm-12 form-group text-danger image-errors\">
                        ";
        // line 18
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "imageFile", array()), 'errors');
        echo "
                    </div>
                    <div class=\"col-sm-12\">
                        <div class=\"input-group top-buffer image-upload-selector\">
                            <label class=\"input-group-btn\">
                                <span class=\"btn btn-primary\">
                                    Selaa&hellip; ";
        // line 24
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "imageFile", array()), "file", array()), 'widget');
        echo "
                                </span>
                            </label>
                            <input type=\"text\" class=\"form-control\" readonly>
                        </div>
                    </div>
                    ";
        // line 30
        if ($this->getAttribute($this->getAttribute(($context["form"] ?? null), "imageFile", array(), "any", false, true), "delete", array(), "any", true, true)) {
            // line 31
            echo "                        <div class=\"col-sm-12\">
                            <div class=\"checkbox\">
                                <label>
                                    ";
            // line 34
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "imageFile", array()), "delete", array()), 'widget');
            echo " Poista kuva
                                </label>
                            </div>
                        </div>
                    ";
        }
        // line 39
        echo "                    <div class=\"col-sm-12 form-group\">
                        ";
        // line 40
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "submit", array()), 'row');
        echo "
                    </div>
                ";
        // line 42
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12 text-center\"> 
                    <a href=\"";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("dashboard");
        echo "\" class=\"btn btn-default\">Peruuta</a>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_673d4afb5af612fb7e71b423b64c0aa7cda9b3ca6d2742fac7b5f7d8cfc7f710->leave($__internal_673d4afb5af612fb7e71b423b64c0aa7cda9b3ca6d2742fac7b5f7d8cfc7f710_prof);

        
        $__internal_c0d3765f3ac57c5db686c778e0581969a218c6ca72e08ce82770e3d3765793ab->leave($__internal_c0d3765f3ac57c5db686c778e0581969a218c6ca72e08ce82770e3d3765793ab_prof);

    }

    // line 53
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_47ab7d9c55e2c63e22302f1b5e7ea56892fb24b050ff80814264e60404ecab39 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_47ab7d9c55e2c63e22302f1b5e7ea56892fb24b050ff80814264e60404ecab39->enter($__internal_47ab7d9c55e2c63e22302f1b5e7ea56892fb24b050ff80814264e60404ecab39_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_aecb0ab56050092ad9852cc28fc171f31ebe7bce577bf232ebb0f73d8562b13f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aecb0ab56050092ad9852cc28fc171f31ebe7bce577bf232ebb0f73d8562b13f->enter($__internal_aecb0ab56050092ad9852cc28fc171f31ebe7bce577bf232ebb0f73d8562b13f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 54
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/css/dashboard.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
";
        
        $__internal_aecb0ab56050092ad9852cc28fc171f31ebe7bce577bf232ebb0f73d8562b13f->leave($__internal_aecb0ab56050092ad9852cc28fc171f31ebe7bce577bf232ebb0f73d8562b13f_prof);

        
        $__internal_47ab7d9c55e2c63e22302f1b5e7ea56892fb24b050ff80814264e60404ecab39->leave($__internal_47ab7d9c55e2c63e22302f1b5e7ea56892fb24b050ff80814264e60404ecab39_prof);

    }

    // line 57
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_070a37d0612883edd28719fe7afca774485a29749be6c20b6c5531e8f69a377d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_070a37d0612883edd28719fe7afca774485a29749be6c20b6c5531e8f69a377d->enter($__internal_070a37d0612883edd28719fe7afca774485a29749be6c20b6c5531e8f69a377d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_ac13359fc5e0182564b4b5fdd217597ceace24f1c1cc0590432541fcfd200b27 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac13359fc5e0182564b4b5fdd217597ceace24f1c1cc0590432541fcfd200b27->enter($__internal_ac13359fc5e0182564b4b5fdd217597ceace24f1c1cc0590432541fcfd200b27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 58
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/imageUpload.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_ac13359fc5e0182564b4b5fdd217597ceace24f1c1cc0590432541fcfd200b27->leave($__internal_ac13359fc5e0182564b4b5fdd217597ceace24f1c1cc0590432541fcfd200b27_prof);

        
        $__internal_070a37d0612883edd28719fe7afca774485a29749be6c20b6c5531e8f69a377d->leave($__internal_070a37d0612883edd28719fe7afca774485a29749be6c20b6c5531e8f69a377d_prof);

    }

    public function getTemplateName()
    {
        return ":Dashboard:change_image.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  202 => 59,  197 => 58,  188 => 57,  175 => 54,  166 => 53,  150 => 46,  143 => 42,  138 => 40,  135 => 39,  127 => 34,  122 => 31,  120 => 30,  111 => 24,  102 => 18,  97 => 16,  93 => 14,  85 => 12,  79 => 10,  77 => 9,  70 => 4,  61 => 3,  43 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block title %}Kuvan vaihto{% endblock %}
{% block body %}
    <div class=\"container-fluid dashboard-company-info\">
        <div class=\"container text-center\">
            <h2>Vaihda kuva</h2>
            <p>Sallitut tiedostoformaatit ovat JPEG ja PNG. Suositeltu kuvan koko on 300 x 300px.</p>
            <div class=\"row\">
                {% if company.imageName == null %}
                    <img src=\"{{ asset('bundles/app/img/logo-placeholder.png') }}\" class=\"img-responsive\"></img>
                {% else %}
                    <img src=\"{{ vich_uploader_asset(company, 'imageFile') | imagine_filter('company') }}\" alt=\"{{ company.name }}\" class=\"img-responsive\" />
                {% endif %}
            </div>
            <div class=\"row\">
                {{ form_start(form) }}
                    <div class=\"col-sm-12 form-group text-danger image-errors\">
                        {{ form_errors(form.imageFile) }}
                    </div>
                    <div class=\"col-sm-12\">
                        <div class=\"input-group top-buffer image-upload-selector\">
                            <label class=\"input-group-btn\">
                                <span class=\"btn btn-primary\">
                                    Selaa&hellip; {{ form_widget(form.imageFile.file) }}
                                </span>
                            </label>
                            <input type=\"text\" class=\"form-control\" readonly>
                        </div>
                    </div>
                    {% if form.imageFile.delete is defined %}
                        <div class=\"col-sm-12\">
                            <div class=\"checkbox\">
                                <label>
                                    {{ form_widget(form.imageFile.delete) }} Poista kuva
                                </label>
                            </div>
                        </div>
                    {% endif %}
                    <div class=\"col-sm-12 form-group\">
                        {{ form_row(form.submit) }}
                    </div>
                {{ form_end(form) }}
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12 text-center\"> 
                    <a href=\"{{ path('dashboard') }}\" class=\"btn btn-default\">Peruuta</a>
                </div>
            </div>
        </div>
    </div>
{% endblock %}

{% block stylesheets %}
    <link href=\"{{ asset('bundles/app/css/dashboard.css') }}\" rel=\"stylesheet\" />
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
    <script src=\"{{ asset('bundles/app/js/imageUpload.js') }}\"></script>
{% endblock %}", ":Dashboard:change_image.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Dashboard/change_image.html.twig");
    }
}
