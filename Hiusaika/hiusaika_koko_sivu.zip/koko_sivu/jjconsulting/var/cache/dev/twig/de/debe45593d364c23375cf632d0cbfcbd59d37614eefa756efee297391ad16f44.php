<?php

/* FOSUserBundle:Registration:check_email.html.twig */
class __TwigTemplate_830f1372d87c22afa00e32a990156ec48df3b8ab9c08346e1e1a465c3d336570 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Registration:check_email.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5839397b2067dd3bf52cd8df6f2216c3b20ee26924eb146ae1165ac40cc35836 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5839397b2067dd3bf52cd8df6f2216c3b20ee26924eb146ae1165ac40cc35836->enter($__internal_5839397b2067dd3bf52cd8df6f2216c3b20ee26924eb146ae1165ac40cc35836_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:check_email.html.twig"));

        $__internal_4c71832bed7a88bc57311f77c7be1d14b89feba48811c9d94138e98a68a5c39b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c71832bed7a88bc57311f77c7be1d14b89feba48811c9d94138e98a68a5c39b->enter($__internal_4c71832bed7a88bc57311f77c7be1d14b89feba48811c9d94138e98a68a5c39b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:check_email.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5839397b2067dd3bf52cd8df6f2216c3b20ee26924eb146ae1165ac40cc35836->leave($__internal_5839397b2067dd3bf52cd8df6f2216c3b20ee26924eb146ae1165ac40cc35836_prof);

        
        $__internal_4c71832bed7a88bc57311f77c7be1d14b89feba48811c9d94138e98a68a5c39b->leave($__internal_4c71832bed7a88bc57311f77c7be1d14b89feba48811c9d94138e98a68a5c39b_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_d12fb6713985d94fe0b4372e0d5e0b7b31560f0027b0443eef6a4de880732cba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d12fb6713985d94fe0b4372e0d5e0b7b31560f0027b0443eef6a4de880732cba->enter($__internal_d12fb6713985d94fe0b4372e0d5e0b7b31560f0027b0443eef6a4de880732cba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_18c84184ac03f7b856a7242d94b3be625b028afe9e421e1585f1a7774f8b75be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_18c84184ac03f7b856a7242d94b3be625b028afe9e421e1585f1a7774f8b75be->enter($__internal_18c84184ac03f7b856a7242d94b3be625b028afe9e421e1585f1a7774f8b75be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.check_email", array("%email%" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "email", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_18c84184ac03f7b856a7242d94b3be625b028afe9e421e1585f1a7774f8b75be->leave($__internal_18c84184ac03f7b856a7242d94b3be625b028afe9e421e1585f1a7774f8b75be_prof);

        
        $__internal_d12fb6713985d94fe0b4372e0d5e0b7b31560f0027b0443eef6a4de880732cba->leave($__internal_d12fb6713985d94fe0b4372e0d5e0b7b31560f0027b0443eef6a4de880732cba_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:check_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}
    <p>{{ 'registration.check_email'|trans({'%email%': user.email}) }}</p>
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:check_email.html.twig", "/Users/villel/Sites/jjconsulting/vendor/friendsofsymfony/user-bundle/Resources/views/Registration/check_email.html.twig");
    }
}
