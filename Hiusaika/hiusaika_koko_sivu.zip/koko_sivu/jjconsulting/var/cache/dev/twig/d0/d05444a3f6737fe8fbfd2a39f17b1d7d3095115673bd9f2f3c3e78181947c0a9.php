<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_c1d7b8c5ed08852d2841018251c1f11e04bb70ce5e57a06097584362806e031a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1e57e7a8b5bb57227dd83b5f4b7a6d649b959bd43eb357a9f9f57baffde5346c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e57e7a8b5bb57227dd83b5f4b7a6d649b959bd43eb357a9f9f57baffde5346c->enter($__internal_1e57e7a8b5bb57227dd83b5f4b7a6d649b959bd43eb357a9f9f57baffde5346c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        $__internal_60b52b09401a481f056961b63ed5d259fecb4b05e1b0ca9b1790fc2fa6fe3677 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60b52b09401a481f056961b63ed5d259fecb4b05e1b0ca9b1790fc2fa6fe3677->enter($__internal_60b52b09401a481f056961b63ed5d259fecb4b05e1b0ca9b1790fc2fa6fe3677_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php foreach (\$attr as \$k => \$v): ?>
<?php if ('placeholder' === \$k || 'title' === \$k): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$v, array(), \$translation_domain) : \$v)) ?>
<?php elseif (true === \$v): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (false !== \$v): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_1e57e7a8b5bb57227dd83b5f4b7a6d649b959bd43eb357a9f9f57baffde5346c->leave($__internal_1e57e7a8b5bb57227dd83b5f4b7a6d649b959bd43eb357a9f9f57baffde5346c_prof);

        
        $__internal_60b52b09401a481f056961b63ed5d259fecb4b05e1b0ca9b1790fc2fa6fe3677->leave($__internal_60b52b09401a481f056961b63ed5d259fecb4b05e1b0ca9b1790fc2fa6fe3677_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$attr as \$k => \$v): ?>
<?php if ('placeholder' === \$k || 'title' === \$k): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$v, array(), \$translation_domain) : \$v)) ?>
<?php elseif (true === \$v): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (false !== \$v): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/attributes.html.php", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/attributes.html.php");
    }
}
