<?php

/* :Default:index.html.twig */
class __TwigTemplate_ff6217bf1084bb9f2ca529f496ece0bdeade963e84c2b0741e32d9162c11b0ef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Default:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_641559291e6127ed561a3969e48b2914714d1da1d95f84f2c5dbac3a921b7c05 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_641559291e6127ed561a3969e48b2914714d1da1d95f84f2c5dbac3a921b7c05->enter($__internal_641559291e6127ed561a3969e48b2914714d1da1d95f84f2c5dbac3a921b7c05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Default:index.html.twig"));

        $__internal_cfedc7711b45ea23c654bd21b0686e3ada935621aa1e79008a66cd885a56c17e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cfedc7711b45ea23c654bd21b0686e3ada935621aa1e79008a66cd885a56c17e->enter($__internal_cfedc7711b45ea23c654bd21b0686e3ada935621aa1e79008a66cd885a56c17e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_641559291e6127ed561a3969e48b2914714d1da1d95f84f2c5dbac3a921b7c05->leave($__internal_641559291e6127ed561a3969e48b2914714d1da1d95f84f2c5dbac3a921b7c05_prof);

        
        $__internal_cfedc7711b45ea23c654bd21b0686e3ada935621aa1e79008a66cd885a56c17e->leave($__internal_cfedc7711b45ea23c654bd21b0686e3ada935621aa1e79008a66cd885a56c17e_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_1c0c46f17bc404a49ab8ec7e30a083a8f973dfb3ae1dfd4299ed2927bbadc2cf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1c0c46f17bc404a49ab8ec7e30a083a8f973dfb3ae1dfd4299ed2927bbadc2cf->enter($__internal_1c0c46f17bc404a49ab8ec7e30a083a8f973dfb3ae1dfd4299ed2927bbadc2cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_2cba1f3a44961b2df4eb290b88e3ad275a3e749b0130c5ed8502d841631cb981 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2cba1f3a44961b2df4eb290b88e3ad275a3e749b0130c5ed8502d841631cb981->enter($__internal_2cba1f3a44961b2df4eb290b88e3ad275a3e749b0130c5ed8502d841631cb981_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Etusivu";
        
        $__internal_2cba1f3a44961b2df4eb290b88e3ad275a3e749b0130c5ed8502d841631cb981->leave($__internal_2cba1f3a44961b2df4eb290b88e3ad275a3e749b0130c5ed8502d841631cb981_prof);

        
        $__internal_1c0c46f17bc404a49ab8ec7e30a083a8f973dfb3ae1dfd4299ed2927bbadc2cf->leave($__internal_1c0c46f17bc404a49ab8ec7e30a083a8f973dfb3ae1dfd4299ed2927bbadc2cf_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_e0e2ae21f02ee89d3785e4ff941c4e64f29b6a4bcd24cf72816f7c2fb90e9076 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e0e2ae21f02ee89d3785e4ff941c4e64f29b6a4bcd24cf72816f7c2fb90e9076->enter($__internal_e0e2ae21f02ee89d3785e4ff941c4e64f29b6a4bcd24cf72816f7c2fb90e9076_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_4175425033efa019693ab5130e229fca14fa14f194d21a7e008359fb3cb55782 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4175425033efa019693ab5130e229fca14fa14f194d21a7e008359fb3cb55782->enter($__internal_4175425033efa019693ab5130e229fca14fa14f194d21a7e008359fb3cb55782_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"jumbotron text-center\">
        <h2>Hae</h2>
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Company:searchBar"));
        // line 9
        echo "
        <p><a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("searchCompany");
        echo "\" class=\"btn btn-default btn-md\">Näytä kaikki</a></p>
    </div>

    <div id=\"about\" class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-sm-8\">
                <h2>Tietoa meistä</h2><br>
                <h4>tekstiä</h4><br>
                <p>Lisää tekstiä</p>
                <br><a href=\"";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("about");
        echo "\"><button class=\"btn btn-default btn-lg\">Lue lisää</button></a>
            </div>
            <div class=\"col-sm-4\">
                <span class=\"glyphicon glyphicon-flag logo\"></span>
            </div>
        </div>
    </div>

    <div class=\"container-fluid text-center bg-grey\">

        <h2>Asiakkaittemme kommentteja</h2>
        <div id=\"myCarousel\" class=\"carousel slide text-center\" data-ride=\"carousel\">
            <!-- Indikaattorit -->
            <ol class=\"carousel-indicators\">
                <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>
                <li data-target=\"#myCarousel\" data-slide-to=\"1\"></li>
                <li data-target=\"#myCarousel\" data-slide-to=\"2\"></li>
            </ol>

            <!-- Kommentit karusellissa -->
            <div class=\"carousel-inner\" role=\"listbox\">
                <div class=\"item active\">
                    <h4>\"Ihan loistavat sivut!\"<br><span>Jaana, Mikkeli</span></h4>
                </div>
                <div class=\"item\">
                    <h4>\"Tälläistä nettisivua on kaivattu!\"<br><span>Joona, Lappeenranta</span></h4>
                </div>
                <div class=\"item\">
                    <h4>\"Hyvät sivut!\"<br><span>Jouni, Lappeenranta</span></h4>
                </div>
            </div>

            <a class=\"left carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"prev\">
                <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">takaisin</span>
            </a>
            <a class=\"right carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"next\">
                <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">Seuraava</span>
            </a>
        </div>
    </div>

    <div id=\"contact\" class=\"container-fluid\">
        <h2 class=\"text-center\">Lähetä palautetta</h2>
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <p>Vastaamme palautteisiin 24 tunnin kuluessa</p>
                <p><i class=\"fa fa-phone\" aria-hidden=\"true\"></i> 040 778 4649</p>
                <p><i class=\"fa fa-envelope\" aria-hidden=\"true\"></i> jouni.kononen@gmail.com</p>
            </div>
            <div class=\"col-sm-8 slideanim\">
                <div class=\"row\">
                    ";
        // line 72
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["contactForm"] ?? $this->getContext($context, "contactForm")), 'form_start');
        echo "
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 74
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["contactForm"] ?? $this->getContext($context, "contactForm")), "name", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        ";
        // line 77
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["contactForm"] ?? $this->getContext($context, "contactForm")), "email", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-12 form-group\">
                        ";
        // line 80
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["contactForm"] ?? $this->getContext($context, "contactForm")), "message", array()), 'row');
        echo "
                    </div>
                    <div class=\"col-sm-12 form-group\">
                        ";
        // line 83
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["contactForm"] ?? $this->getContext($context, "contactForm")), "submit", array()), 'row');
        echo "
                    </div>
                    ";
        // line 85
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["contactForm"] ?? $this->getContext($context, "contactForm")), 'form_end');
        echo "
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_4175425033efa019693ab5130e229fca14fa14f194d21a7e008359fb3cb55782->leave($__internal_4175425033efa019693ab5130e229fca14fa14f194d21a7e008359fb3cb55782_prof);

        
        $__internal_e0e2ae21f02ee89d3785e4ff941c4e64f29b6a4bcd24cf72816f7c2fb90e9076->leave($__internal_e0e2ae21f02ee89d3785e4ff941c4e64f29b6a4bcd24cf72816f7c2fb90e9076_prof);

    }

    // line 92
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_4d2db79a220c238bdf2b05e1e3ce3ef93be149c81e30f419f73ccc5ec2ba2586 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4d2db79a220c238bdf2b05e1e3ce3ef93be149c81e30f419f73ccc5ec2ba2586->enter($__internal_4d2db79a220c238bdf2b05e1e3ce3ef93be149c81e30f419f73ccc5ec2ba2586_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_cb079ec553298f81dc5ea48bdb79bdb8409b6bf7f26f79045d95b8cd410972a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cb079ec553298f81dc5ea48bdb79bdb8409b6bf7f26f79045d95b8cd410972a0->enter($__internal_cb079ec553298f81dc5ea48bdb79bdb8409b6bf7f26f79045d95b8cd410972a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_cb079ec553298f81dc5ea48bdb79bdb8409b6bf7f26f79045d95b8cd410972a0->leave($__internal_cb079ec553298f81dc5ea48bdb79bdb8409b6bf7f26f79045d95b8cd410972a0_prof);

        
        $__internal_4d2db79a220c238bdf2b05e1e3ce3ef93be149c81e30f419f73ccc5ec2ba2586->leave($__internal_4d2db79a220c238bdf2b05e1e3ce3ef93be149c81e30f419f73ccc5ec2ba2586_prof);

    }

    // line 95
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_a393cc014f82d8a3f734c2f1514204a7b4aa9ef775fdac138e0a538e8d1ec830 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a393cc014f82d8a3f734c2f1514204a7b4aa9ef775fdac138e0a538e8d1ec830->enter($__internal_a393cc014f82d8a3f734c2f1514204a7b4aa9ef775fdac138e0a538e8d1ec830_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_9e95b8531e8b2e9e14b111825525bd849187f3a8e78a1857c733a66696a64914 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e95b8531e8b2e9e14b111825525bd849187f3a8e78a1857c733a66696a64914->enter($__internal_9e95b8531e8b2e9e14b111825525bd849187f3a8e78a1857c733a66696a64914_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 96
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/main.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_9e95b8531e8b2e9e14b111825525bd849187f3a8e78a1857c733a66696a64914->leave($__internal_9e95b8531e8b2e9e14b111825525bd849187f3a8e78a1857c733a66696a64914_prof);

        
        $__internal_a393cc014f82d8a3f734c2f1514204a7b4aa9ef775fdac138e0a538e8d1ec830->leave($__internal_a393cc014f82d8a3f734c2f1514204a7b4aa9ef775fdac138e0a538e8d1ec830_prof);

    }

    public function getTemplateName()
    {
        return ":Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  218 => 96,  209 => 95,  192 => 92,  176 => 85,  171 => 83,  165 => 80,  159 => 77,  153 => 74,  148 => 72,  92 => 19,  80 => 10,  77 => 9,  75 => 7,  70 => 4,  61 => 3,  43 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block title %}Etusivu{% endblock %}
{% block body %}

    <div class=\"jumbotron text-center\">
        <h2>Hae</h2>
        {{ render(controller(
            'AppBundle:Company:searchBar'
        )) }}
        <p><a href=\"{{ path('searchCompany') }}\" class=\"btn btn-default btn-md\">Näytä kaikki</a></p>
    </div>

    <div id=\"about\" class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-sm-8\">
                <h2>Tietoa meistä</h2><br>
                <h4>tekstiä</h4><br>
                <p>Lisää tekstiä</p>
                <br><a href=\"{{ path('about') }}\"><button class=\"btn btn-default btn-lg\">Lue lisää</button></a>
            </div>
            <div class=\"col-sm-4\">
                <span class=\"glyphicon glyphicon-flag logo\"></span>
            </div>
        </div>
    </div>

    <div class=\"container-fluid text-center bg-grey\">

        <h2>Asiakkaittemme kommentteja</h2>
        <div id=\"myCarousel\" class=\"carousel slide text-center\" data-ride=\"carousel\">
            <!-- Indikaattorit -->
            <ol class=\"carousel-indicators\">
                <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>
                <li data-target=\"#myCarousel\" data-slide-to=\"1\"></li>
                <li data-target=\"#myCarousel\" data-slide-to=\"2\"></li>
            </ol>

            <!-- Kommentit karusellissa -->
            <div class=\"carousel-inner\" role=\"listbox\">
                <div class=\"item active\">
                    <h4>\"Ihan loistavat sivut!\"<br><span>Jaana, Mikkeli</span></h4>
                </div>
                <div class=\"item\">
                    <h4>\"Tälläistä nettisivua on kaivattu!\"<br><span>Joona, Lappeenranta</span></h4>
                </div>
                <div class=\"item\">
                    <h4>\"Hyvät sivut!\"<br><span>Jouni, Lappeenranta</span></h4>
                </div>
            </div>

            <a class=\"left carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"prev\">
                <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">takaisin</span>
            </a>
            <a class=\"right carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"next\">
                <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">Seuraava</span>
            </a>
        </div>
    </div>

    <div id=\"contact\" class=\"container-fluid\">
        <h2 class=\"text-center\">Lähetä palautetta</h2>
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <p>Vastaamme palautteisiin 24 tunnin kuluessa</p>
                <p><i class=\"fa fa-phone\" aria-hidden=\"true\"></i> 040 778 4649</p>
                <p><i class=\"fa fa-envelope\" aria-hidden=\"true\"></i> jouni.kononen@gmail.com</p>
            </div>
            <div class=\"col-sm-8 slideanim\">
                <div class=\"row\">
                    {{form_start(contactForm)}}
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(contactForm.name)}}
                    </div>
                    <div class=\"col-sm-6 form-group\">
                        {{form_row(contactForm.email)}}
                    </div>
                    <div class=\"col-sm-12 form-group\">
                        {{form_row(contactForm.message)}}
                    </div>
                    <div class=\"col-sm-12 form-group\">
                        {{form_row(contactForm.submit)}}
                    </div>
                    {{form_end(contactForm)}}
                </div>
            </div>
        </div>
    </div>
{% endblock %}

{% block stylesheets %}
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('bundles/app/js/main.js') }}\"></script>
{% endblock %}
", ":Default:index.html.twig", "/Users/villel/Sites/jjconsulting/app/Resources/views/Default/index.html.twig");
    }
}
