<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_405c586b3333f491f995c05dca25dbaab4ce135a38fa1e85ac1b04cdfedcf3db extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_79087787eaae056701f6b8ac07844f51415df7647c4c4902b0d6de855f623156 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_79087787eaae056701f6b8ac07844f51415df7647c4c4902b0d6de855f623156->enter($__internal_79087787eaae056701f6b8ac07844f51415df7647c4c4902b0d6de855f623156_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_26c4be67decccdd6e096ab8fd67da0e378c88aca27548fd78ecf5d60a9ea1429 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_26c4be67decccdd6e096ab8fd67da0e378c88aca27548fd78ecf5d60a9ea1429->enter($__internal_26c4be67decccdd6e096ab8fd67da0e378c88aca27548fd78ecf5d60a9ea1429_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_79087787eaae056701f6b8ac07844f51415df7647c4c4902b0d6de855f623156->leave($__internal_79087787eaae056701f6b8ac07844f51415df7647c4c4902b0d6de855f623156_prof);

        
        $__internal_26c4be67decccdd6e096ab8fd67da0e378c88aca27548fd78ecf5d60a9ea1429->leave($__internal_26c4be67decccdd6e096ab8fd67da0e378c88aca27548fd78ecf5d60a9ea1429_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_bd42470aa55e0b1556ebca3adc03be7c1d42fc83c789211a6233f76f6568d899 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bd42470aa55e0b1556ebca3adc03be7c1d42fc83c789211a6233f76f6568d899->enter($__internal_bd42470aa55e0b1556ebca3adc03be7c1d42fc83c789211a6233f76f6568d899_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_741122c510dfef92104ce65d249aa332b99e4ff0e04940873740399d169e7cb7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_741122c510dfef92104ce65d249aa332b99e4ff0e04940873740399d169e7cb7->enter($__internal_741122c510dfef92104ce65d249aa332b99e4ff0e04940873740399d169e7cb7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_741122c510dfef92104ce65d249aa332b99e4ff0e04940873740399d169e7cb7->leave($__internal_741122c510dfef92104ce65d249aa332b99e4ff0e04940873740399d169e7cb7_prof);

        
        $__internal_bd42470aa55e0b1556ebca3adc03be7c1d42fc83c789211a6233f76f6568d899->leave($__internal_bd42470aa55e0b1556ebca3adc03be7c1d42fc83c789211a6233f76f6568d899_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_303be12cf22231be885fb613bdac63ba9396db64f2fad76ed3379ee0835b49ce = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_303be12cf22231be885fb613bdac63ba9396db64f2fad76ed3379ee0835b49ce->enter($__internal_303be12cf22231be885fb613bdac63ba9396db64f2fad76ed3379ee0835b49ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_38008dde97a2c986cf9f61146e488c1e3c46869ab9767c29e25418f4524f1ac6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_38008dde97a2c986cf9f61146e488c1e3c46869ab9767c29e25418f4524f1ac6->enter($__internal_38008dde97a2c986cf9f61146e488c1e3c46869ab9767c29e25418f4524f1ac6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_38008dde97a2c986cf9f61146e488c1e3c46869ab9767c29e25418f4524f1ac6->leave($__internal_38008dde97a2c986cf9f61146e488c1e3c46869ab9767c29e25418f4524f1ac6_prof);

        
        $__internal_303be12cf22231be885fb613bdac63ba9396db64f2fad76ed3379ee0835b49ce->leave($__internal_303be12cf22231be885fb613bdac63ba9396db64f2fad76ed3379ee0835b49ce_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_eecc9a41d73cfb3ce5d913653e65c72189dc870c1002d987b8888daffc7f5802 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eecc9a41d73cfb3ce5d913653e65c72189dc870c1002d987b8888daffc7f5802->enter($__internal_eecc9a41d73cfb3ce5d913653e65c72189dc870c1002d987b8888daffc7f5802_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_01a6a24ce6e5a39e565a1c5442e75d5fc195a1ddb31af6bdf27e006a9d0a9343 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_01a6a24ce6e5a39e565a1c5442e75d5fc195a1ddb31af6bdf27e006a9d0a9343->enter($__internal_01a6a24ce6e5a39e565a1c5442e75d5fc195a1ddb31af6bdf27e006a9d0a9343_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_01a6a24ce6e5a39e565a1c5442e75d5fc195a1ddb31af6bdf27e006a9d0a9343->leave($__internal_01a6a24ce6e5a39e565a1c5442e75d5fc195a1ddb31af6bdf27e006a9d0a9343_prof);

        
        $__internal_eecc9a41d73cfb3ce5d913653e65c72189dc870c1002d987b8888daffc7f5802->leave($__internal_eecc9a41d73cfb3ce5d913653e65c72189dc870c1002d987b8888daffc7f5802_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/Users/villel/Sites/jjconsulting/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
